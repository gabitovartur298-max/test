import { strict as assert } from "node:assert";
import { readFile } from "node:fs/promises";
import { test } from "node:test";

let run = 0;
const gameFile = new URL("../src/main.jsx", import.meta.url);
const platformFile = new URL("../src/platform.js", import.meta.url);
const source = await readFile(gameFile, "utf8");
const key = "klevy_ostrov_save_v1";
const clone = (value) => value == null ? value : structuredClone(value);
const advancePromises = async () => { for (let i = 0; i < 20; i++) await Promise.resolve(); };
function installBrowser(sdk, original) {
  const storage = new Map(original ? [[key, JSON.stringify(original)]] : []);
  globalThis.window = {
    YaGames: { init: () => typeof sdk === "function" ? sdk() : Promise.resolve(sdk) },
    addEventListener() {}, setTimeout, setInterval, matchMedia: () => ({ matches: false }),
  };
  globalThis.document = { hidden: false, documentElement: {}, addEventListener() {}, getElementById() {}, hasFocus: () => true };
  globalThis.localStorage = {
    getItem: (id) => storage.get(id) ?? null,
    setItem: (id, value) => storage.set(id, value),
    removeItem: (id) => storage.delete(id),
  };
  return storage;
}
function freshPlatform() {
  const url = new URL(platformFile);
  url.searchParams.set("fixture", String(++run));
  return url.href;
}
async function loadGame() {
  // Use the real game logic without mounting React or instantiating the 3D renderer.
  const code = source.replace('import "./index.css";', "")
    .replace('"./platform.js"', JSON.stringify(freshPlatform()))
    .replace(/^import .* from "(?:react|react-dom\/client|three[^\"]*)";$/gm, "")
    .replace(/createRoot\(document\.getElementById\("root"\)\)\.render\(h\(App\)\);/, "") + `
    export { sanitize, dailyStatus, claimDaily, eggWait, watchFreeEgg, claimQuestDouble,
      refreshPayments, buyPremium, fulfillPurchase, postEarnings, snapshot };
  `;
  const stubs = `
    const React = { createElement: (...args) => args };
    const THREE = { Vector3: class { copy() { return this; } }, Color: class {} };
  `;
  return import("data:text/javascript;base64," + Buffer.from(stubs + code).toString("base64"));
}
function bootMocks(options = {}) {
  let cloud = options.cloud ?? null;
  const writes = [];
  const sold = [];
  const callbacks = {};
  let purchaseList = options.purchases ?? [];
  return {
    writes, sold, callbacks,
    sdk: {
      environment: { i18n: { lang: "en" } },
      deviceInfo: { type: "mobile" },
      on(name, fn) { callbacks[name] = fn; },
      getPlayer: async () => ({
        isAuthorized: () => options.authorized ?? true,
        getData: async () => ({ save: clone(cloud) }),
        setData: async ({ save }, flush) => {
          if (options.failWrite?.()) throw new Error("Unavailable");
          cloud = clone(save);
          writes.push({ save: cloud, flush });
        },
      }),
      getPayments: async () => ({
        getCatalog: async () => ["vip_luck", "auto_forever", "pack_starter", "pack_diamonds"]
          .map((id) => ({ id, price: "10 YAN", priceCurrencyCode: "YAN" })),
        getPurchases: async () => clone(purchaseList),
        purchase: async ({ id }) => {
          const p = { productID: id, purchaseToken: id === "pack_diamonds" ? "direct" : `direct-${id}` };
          purchaseList = [...purchaseList, p];
          return p;
        },
        consumePurchase: async (token) => {
          assert.ok(cloud.pendingReceipts.includes(token), "save receipt before consumption");
          sold.push(token);
          purchaseList = purchaseList.filter((p) => p.purchaseToken !== token);
        },
      }),
      adv: {
        showFullscreenAdv: ({ callbacks: cb }) => { callbacks.fullscreen = cb; },
        showRewardedVideo: ({ callbacks: cb }) => { callbacks.rewarded = cb; },
        showBannerAdv: async () => ({ stickyAdvIsShowing: true }),
        hideBannerAdv: async () => ({ stickyAdvIsShowing: false }),
      },
      ...(options.sdk ?? {}),
    },
  };
}

test("late SDK binds after 3500 ms; fullscreen cooldown only follows successful close", async (t) => {
  t.mock.timers.enable({ apis: ["setTimeout", "Date"], now: 100_000 });
  const mocks = bootMocks();
  let release;
  installBrowser(() => new Promise((resolve) => { release = resolve; }));
  const { YA } = await import(freshPlatform());
  let ready = 0;
  YA.onReady(() => ready++);
  const boot = YA.init();
  await Promise.resolve();
  t.mock.timers.tick(3500);
  await boot;
  assert.equal(YA.available, false);
  release(mocks.sdk);
  await advancePromises();
  assert.equal(YA.available, true);
  assert.equal(ready, 1);
  const first = YA.showInterstitial();
  assert.equal(await YA.showRewarded(), false, "reject overlapping requests");
  mocks.callbacks.fullscreen.onError();
  assert.equal(await first, false);
  const second = YA.showInterstitial();
  mocks.callbacks.fullscreen.onClose(false);
  assert.equal(await second, false);
  const third = YA.showInterstitial();
  mocks.callbacks.fullscreen.onClose(true);
  assert.equal(await third, true);
  t.mock.timers.tick(84_999);
  assert.equal(await YA.showInterstitial(), false);
  t.mock.timers.tick(1);
  const fourth = YA.showInterstitial();
  mocks.callbacks.fullscreen.onClose(true);
  assert.equal(await fourth, true);
  assert.equal(await YA.showBanner(), true);
  assert.equal(await YA.hideBanner(), false);
});

test("v1 save opens; pet limit preserves old pets; VIP and daily rewards are additive", async (t) => {
  const morning = new Date(2026, 3, 5, 9).getTime();
  t.mock.timers.enable({ apis: ["setTimeout", "setInterval", "Date"], now: morning });
  const pets = Array.from({ length: 101 }, (_, i) => ({ id: "tardigrade", uid: `old${i}` }));
  installBrowser(null, { v: 1, savedAt: morning - 100, coins: 324, diamonds: 120, petsOwned: pets, petsEquipped: ["old100"], lang: "en" });
  const game = await loadGame();
  await game.boot();
  const state = game.useGame.getState;
  assert.equal(state().coins, 324);
  assert.equal(state().vipLuck, false);
  assert.equal(state().petsOwned.length, 101);
  assert.deepEqual(state().petsEquipped, ["old100"]);
  assert.equal(game.hatchLunarEgg(), null);
  assert.equal(state().diamonds, 120);
  game.deletePet("old0"); game.deletePet("old1");
  assert.ok(game.hatchLunarEgg());
  assert.equal(state().petsOwned.length, 100);
  assert.equal(state().diamonds, 95);
  const oldLuck = game.getMods().luckMult;
  game.useGame.setState({ vipLuck: true });
  assert.equal(game.getMods().luckMult, oldLuck * 2);
  assert.equal(game.t("releasePet"), "Release pet");
  for (let i = 1; i <= 7; i++) {
    t.mock.timers.setTime(new Date(2026, 3, 4 + i, 9).getTime());
    assert.deepEqual(game.dailyStatus(), { available: true, day: i });
    assert.equal(game.claimDaily(), true);
    assert.equal(game.claimDaily(), false);
  }
  assert.equal(state().diamonds, 120);
  t.mock.timers.setTime(new Date(2026, 3, 13, 9).getTime());
  assert.deepEqual(game.dailyStatus(), { available: true, day: 1 });
  assert.equal(game.snapshot().v, 1);
});

test("quest and egg reward only after confirmation; rare fish can be rescued or expire", async (t) => {
  t.mock.timers.enable({ apis: ["setTimeout", "setInterval", "Date"], now: 100_000 });
  const mocks = bootMocks();
  installBrowser(mocks.sdk);
  const game = await loadGame();
  await game.boot();
  const s = game.useGame.getState;
  const quest = { type: "catch", target: 20, progress: 20, done: true, reward: 150 };
  game.useGame.setState({ quests: [quest] });
  const rejected = game.claimQuestDouble(0, quest);
  mocks.callbacks.rewarded.onClose(false);
  await rejected;
  assert.equal(s().coins, 0);
  const accepted = game.claimQuestDouble(0, quest);
  mocks.callbacks.rewarded.onRewarded();
  mocks.callbacks.rewarded.onClose(true);
  await accepted;
  await game.claimQuestDouble(0, quest);
  assert.equal(s().coins, 300);
  const egg = game.watchFreeEgg();
  mocks.callbacks.rewarded.onRewarded();
  mocks.callbacks.rewarded.onClose(true);
  await egg;
  assert.equal(s().petsOwned.length, 1);
  assert.equal(game.eggWait(), 20 * 60_000);
  await game.watchFreeEgg();
  assert.equal(s().petsOwned.length, 1);
  assert.equal(game.sanitize(game.snapshot()).freeEggAt, 100_000);
  const fishing = new game.Fishing({});
  const prepare = (id) => { fishing.pending = { def: game.FISH_MAP[id], w: 1 }; fishing.setPhase("reeling"); };
  fishing.caught = (rescued) => { if (rescued) game.addCatch(fishing.pending.def, 1, null); fishing.setPhase("caught"); };
  prepare("pike"); fishing.escape();
  assert.equal(s().phase, "rescue");
  const attempt = fishing.resolveRescue(true);
  t.mock.timers.tick(8000);
  assert.equal(s().rescue.pending, true);
  mocks.callbacks.rewarded.onRewarded();
  mocks.callbacks.rewarded.onClose(true);
  await attempt;
  assert.equal(s().stats.caught, 1);
  prepare("pike"); fishing.escape();
  t.mock.timers.tick(5000);
  assert.equal(s().rescue, null);
  assert.equal(s().phase, "reelback");
  assert.equal(s().stats.caught, 1);
  prepare("carp"); fishing.escape();
  assert.equal(s().rescue, null);
});

test("paid reward persists before consume, and retry after a write error does not double it", async (t) => {
  t.mock.timers.enable({ apis: ["setTimeout", "setInterval", "Date"], now: 200_000 });
  let fail = true;
  const warning = t.mock.method(console, "warn", () => {});
  const mocks = bootMocks({ failWrite: () => fail, purchases: [
    { productID: "pack_diamonds", purchaseToken: "restore" },
  ] });
  installBrowser(mocks.sdk);
  const game = await loadGame();
  await game.boot();
  const s = game.useGame.getState;
  game.useGame.setState({ started: true, panel: "shop" });
  await game.refreshPayments();
  assert.equal(s().restoreFailed, true);
  assert.ok(warning.mock.calls.length > 0);
  assert.equal(s().diamonds, 250);
  assert.deepEqual(mocks.sold, []);
  fail = false;
  await game.refreshPayments(true);
  assert.equal(s().restoreFailed, false);
  assert.equal(s().diamonds, 250);
  assert.deepEqual(mocks.sold, ["restore"]);
  assert.ok(mocks.writes.every((w) => w.flush));
  await game.buyPremium("pack_diamonds");
  assert.equal(s().diamonds, 500);
  assert.deepEqual(mocks.sold, ["restore", "direct"]);
  assert.equal(s().shopPurchased, true);
  await game.refreshPayments(true);
  assert.deepEqual(s().pendingReceipts, []);
  await game.buyPremium("vip_luck");
  await game.buyPremium("auto_forever");
  assert.equal(s().vipLuck, true);
  assert.equal(s().autoOwned, true);
  assert.deepEqual(mocks.sold, ["restore", "direct"], "permanent goods are not consumed");
  game.useGame.setState({ islands: ["sunny", "coral"] });
  await game.buyPremium("pack_starter");
  assert.equal(s().coins, 15_000);
  assert.equal(s().luckUntil, 200_000 + 15 * 60_000);
  assert.deepEqual(mocks.sold, ["restore", "direct", "direct-pack_starter"]);
});

test("leaderboard sends each new high after at least 30 seconds; guest scores are skipped", async (t) => {
  t.mock.timers.enable({ apis: ["setTimeout", "setInterval", "Date"], now: 200_000 });
  const sent = [];
  const mocks = bootMocks({ sdk: { getLeaderboards: async () => ({
    getLeaderboardPlayerEntry: async () => ({ score: 100 }),
    setLeaderboardScore: async (name, value) => { sent.push([name, value]); },
  }) } });
  installBrowser(mocks.sdk);
  const game = await loadGame();
  await game.boot();
  const set = game.useGame.setState;
  set({ started: true, authorized: false, stats: { caught: 1, perfect: 0, earned: 120 } });
  await game.postEarnings();
  assert.deepEqual(sent, []);
  set({ authorized: true });
  await game.postEarnings();
  set({ stats: { caught: 2, perfect: 0, earned: 150 } });
  t.mock.timers.setTime(229_999);
  await game.postEarnings();
  assert.deepEqual(sent, [["top_earners", 120]]);
  t.mock.timers.setTime(230_000);
  await game.postEarnings();
  assert.deepEqual(sent, [["top_earners", 120], ["top_earners", 150]]);
});

test("shop and eighth catch request an ad before gameplay resumes", async (t) => {
  t.mock.timers.enable({ apis: ["setTimeout", "setInterval", "Date"], now: 300_000 });
  const mocks = bootMocks();
  installBrowser(mocks.sdk);
  const game = await loadGame();
  await game.boot();
  const state = game.useGame.getState;
  const set = game.useGame.setState;
  set({ started: true, panel: "shop", coins: 1000 });
  game.buyOrEquipRod("bamboo");
  assert.equal(state().shopPurchased, false, "equipping is not buying");
  game.buyOrEquipRod("willow");
  assert.equal(state().shopPurchased, true);
  game.openPanel(null);
  assert.equal(state().panel, "shop");
  assert.equal(state().adBusy, true);
  mocks.callbacks.fullscreen.onClose(true);
  await advancePromises();
  assert.equal(state().panel, null);
  assert.equal(state().adBusy, false);
  t.mock.timers.setTime(385_000);
  const fishing = new game.Fishing({});
  fishing.setPhase("caught");
  set({ stats: { caught: 8, earned: 0, perfect: 0 }, catchInfo: { adBreak: true } });
  fishing.finishCatch();
  assert.equal(state().phase, "idle");
  assert.equal(state().catchInfo, null);
  assert.equal(fishing.canAct(), false);
  mocks.callbacks.fullscreen.onClose(true);
  await advancePromises();
  assert.equal(fishing.canAct(), true);
});

test("late cloud load does not silently overwrite progress already made in this session", async (t) => {
  t.mock.timers.enable({ apis: ["setTimeout", "setInterval", "Date"], now: 400_000 });
  let release;
  const mocks = bootMocks({ cloud: { v: 1, coins: 900, savedAt: 392_000 } });
  installBrowser(() => new Promise((resolve) => { release = resolve; }), { v: 1, coins: 100, savedAt: 391_000 });
  const game = await loadGame();
  const boot = game.boot();
  await Promise.resolve();
  t.mock.timers.tick(3500);
  await boot;
  const state = game.useGame.getState;
  game.startGame();
  game.useGame.setState({ coins: 125 });
  release(mocks.sdk);
  await advancePromises();
  assert.equal(state().coins, 125);
  assert.equal(state().cloudConflict?.coins, 900);
  assert.equal(state().cloudReady, false);
  assert.equal(state().bannerShown, true);
  assert.equal(mocks.writes.length, 0);
});
