// Yandex Games is supplied by the host at /sdk.js, not bundled by Vite.
let ysdk = null;
let initializing;
let player;
let playerPromise;
let leaderboards;
let gameplayActive = false;
let loadingSent = false;
let lastInterstitial = null;
let adInFlight = false;
const readyListeners = new Set();
const pauseListeners = new Set();
const log = (label, error) => console.warn(`[YA] ${label}`, error);

function bindYsdkInstance(inst) {
  if (!inst || ysdk === inst) return;
  ysdk = inst;
  try {
    ysdk.on?.(ysdk.EVENTS?.GAME_API_PAUSE ?? "game_api_pause", () => {
      for (const listener of pauseListeners) listener(true);
    });
    ysdk.on?.(ysdk.EVENTS?.GAME_API_RESUME ?? "game_api_resume", () => {
      for (const listener of pauseListeners) listener(false);
    });
  } catch (error) { log("events", error); }
  for (const listener of readyListeners) listener();
}

function getPlayer() {
  if (!ysdk?.getPlayer) return Promise.reject(new Error("No player API"));
  return playerPromise ??= Promise.resolve().then(() => ysdk.getPlayer({ scopes: false }))
    .then((value) => (player = value)).catch((error) => {
      playerPromise = undefined;
      throw error;
    });
}

function runAd(method, onCallbacks) {
  if (adInFlight || typeof ysdk?.adv?.[method] !== "function") return Promise.resolve(false);
  adInFlight = true;
  return new Promise((resolve) => {
    let done = false;
    const finish = (value) => {
      if (done) return;
      done = true;
      adInFlight = false;
      resolve(value);
    };
    try {
      ysdk.adv[method]({ callbacks: onCallbacks(finish, () => done) });
    } catch { finish(false); }
  });
}

export const YA = {
  get available() { return !!ysdk; },
  get rewardedAvailable() { return typeof ysdk?.adv?.showRewardedVideo === "function"; },

  async init() {
    if (ysdk || typeof window.YaGames?.init !== "function") return;
    // The timeout releases boot; it never cancels the real initialization or binding.
    initializing ??= Promise.resolve().then(() => window.YaGames.init())
      .then(bindYsdkInstance).catch((error) => log("init", error));
    let timer;
    try {
      await Promise.race([initializing, new Promise((resolve) => { timer = setTimeout(resolve, 3500); })]);
    } finally { clearTimeout(timer); }
  },

  onReady(listener) {
    readyListeners.add(listener);
    if (ysdk) listener();
    return () => readyListeners.delete(listener);
  },
  onPause(listener) { pauseListeners.add(listener); },
  lang() { return ysdk?.environment?.i18n?.lang ?? null; },
  isMobile() {
    const type = ysdk?.deviceInfo?.type;
    return type ? type === "mobile" || type === "tablet" : null;
  },
  loadingReady() {
    if (loadingSent || !ysdk?.features?.LoadingAPI) return;
    try {
      ysdk.features.LoadingAPI.ready();
      loadingSent = true;
    } catch (error) { log("LoadingAPI", error); }
  },
  gameplay(active) {
    if (!ysdk?.features?.GameplayAPI || active === gameplayActive) return;
    try {
      ysdk.features.GameplayAPI[active ? "start" : "stop"]();
      gameplayActive = active;
    } catch (error) { log("GameplayAPI", error); }
  },
  now() {
    try {
      const current = ysdk?.serverTime?.();
      if (Number.isFinite(current)) return current;
    } catch { /* Local play can continue. */ }
    return Date.now();
  },
  isAuthorized() {
    try {
      if (typeof player?.isAuthorized === "function") return player.isAuthorized();
      return typeof player?.getMode === "function" && player.getMode() !== "lite";
    } catch { return false; }
  },
  async openAuthDialog() {
    if (!ysdk?.auth?.openAuthDialog) return false;
    try {
      await ysdk.auth.openAuthDialog();
      player = undefined;
      playerPromise = undefined;
      await getPlayer();
      return this.isAuthorized();
    } catch { return false; }
  },
  async loadData() {
    const p = await getPlayer();
    return (await p.getData(["save"]))?.save ?? null;
  },
  async saveData(save, flush = false) {
    const payload = { save };
    if (new TextEncoder().encode(JSON.stringify(payload)).length > 200_000) throw new Error("Save exceeds 200 KB");
    await (await getPlayer()).setData(payload, flush);
  },
  getPayments() { return ysdk?.getPayments?.(); },
  async getLeaderboards() {
    if (!ysdk) return null;
    if (ysdk.leaderboards) return ysdk.leaderboards;
    leaderboards ??= Promise.resolve().then(() => ysdk.getLeaderboards?.())
      .then((old) => old && ({
        getPlayerEntry: (name) => old.getLeaderboardPlayerEntry(name),
        setScore: (name, score) => old.setLeaderboardScore(name, score),
      })).catch((error) => { leaderboards = undefined; throw error; });
    return leaderboards;
  },
  canShowInterstitial(minGapMs = 85_000) {
    return typeof ysdk?.adv?.showFullscreenAdv === "function" && !adInFlight &&
      (lastInterstitial === null || Date.now() - lastInterstitial >= minGapMs);
  },
  showInterstitial(minGapMs = 85_000) {
    if (!this.canShowInterstitial(minGapMs)) return Promise.resolve(false);
    return runAd("showFullscreenAdv", (finish, done) => ({
      onClose(wasShown) {
        if (done()) return;
        if (wasShown === true) lastInterstitial = Date.now();
        finish(wasShown === true);
      },
      onError: () => finish(false),
      onOffline: () => finish(false),
    }));
  },
  showRewarded() {
    return runAd("showRewardedVideo", (finish, done) => {
      let rewarded = false;
      return {
        onRewarded: () => { if (!done()) rewarded = true; },
        onClose: () => finish(rewarded),
        onError: () => finish(rewarded),
        onOffline: () => finish(false),
      };
    });
  },
  async showBanner() {
    try { return (await ysdk?.adv?.showBannerAdv?.())?.stickyAdvIsShowing === true; }
    catch (error) { log("showBannerAdv", error); return false; }
  },
  async hideBanner() {
    try { return (await ysdk?.adv?.hideBannerAdv?.())?.stickyAdvIsShowing === true; }
    catch (error) { log("hideBannerAdv", error); return false; }
  },
};
