import "./index.css";
import { YA } from "./platform.js";
export { YA };
import React, { useEffect, useRef, useState, useMemo, useId, useSyncExternalStore } from "react";
import { createRoot } from "react-dom/client";
import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";

const h = React.createElement;
const cn = (...inputs) => inputs.flat().filter(Boolean).join(" ");

function createStore(initialState) {
  let state = initialState;
  const listeners = new Set();
  const setState = (partial) => {
    const prev = state;
    const next = typeof partial === "function" ? partial(state) : partial;
    if (!next) return;
    state = Object.assign({}, state, next);
    listeners.forEach((l) => l(state, prev));
  };
  const getState = () => state;
  const subscribe = (listener) => {
    listeners.add(listener);
    return () => listeners.delete(listener);
  };
  const useStore = (selector = (s) => s) =>
    useSyncExternalStore(
      subscribe,
      () => selector(state),
      () => selector(state)
    );
  useStore.getState = getState;
  useStore.setState = setState;
  useStore.subscribe = subscribe;
  return useStore;
}

let currentLang = "ru";
export const setLangInternal = (l) => {
  currentLang = l;
  try {
    document.documentElement.lang = l;
    document.title = t("title");
  } catch {
    /* ignore */
  }
};
export const getLang = () => currentLang;
export const tr = (s) => s[currentLang] ?? s.ru;

export function detectLang(sdkLang) {
  const raw = (sdkLang || navigator.language || "ru").toLowerCase();
  const ruLike = ["ru", "be", "kk", "uk", "uz", "ky", "tg", "hy", "az", "ka", "tt", "ba"];
  return ruLike.some((p) => raw.startsWith(p)) ? "ru" : "en";
}

const D = {
  exchAmount: { ru: "Количество бриллиантов 💎 для операции:", en: "Number of diamonds 💎 to exchange:" },
  exchMax: { ru: "Макс ({n})", en: "Max ({n})" },
  releasePet: { ru: "Отпустить", en: "Release pet" },
  sceneUnavailable: { ru: "Не удалось запустить 3D-сцену на этом устройстве 😢", en: "Could not start the 3D scene on this device 😢" },
  petLimit: { ru: "Лимит: {n} питомцев. Отпусти одного, чтобы вылупить яйцо.", en: "Limit: {n} pets. Release one to hatch an egg." },
  freeEgg: { ru: "Бесплатное яйцо за рекламу", en: "Free egg for watching an ad" },
  freeEggWait: { ru: "Следующее бесплатное яйцо через {time}", en: "Next free egg in {time}" },
  claimDouble: { ru: "Удвоить награду за рекламу", en: "Double the reward by watching an ad" },
  rescueTitle: { ru: "Рыба сорвалась!", en: "The fish slipped away!" },
  rescueTimer: { ru: "До ухода рыбы: {n} сек.", en: "Fish escapes in {n} s" },
  rescueWatch: { ru: "Спасти рыбу за рекламу", en: "Save the fish by watching an ad" },
  rescueSkip: { ru: "Отпустить рыбу", en: "Let the fish go" },
  premium: { ru: "Премиум", en: "Premium" },
  vipLuckTitle: { ru: "Вечная удача ×2", en: "Permanent luck ×2" },
  vipLuckDesc: { ru: "Удваивает удачу навсегда и сочетается с временными бонусами.", en: "Doubles luck permanently and stacks with temporary boosts." },
  starterTitle: { ru: "Стартовый набор", en: "Starter pack" },
  starterDesc: { ru: "{n} монет и 15 минут удачи ×2.", en: "{n} coins and 15 minutes of luck ×2." },
  diamondsTitle: { ru: "Набор бриллиантов", en: "Diamond pack" },
  diamondsDesc: { ru: "250 синих бриллиантов.", en: "250 blue diamonds." },
  paymentWait: { ru: "Подожди…", en: "Please wait…" },
  paymentIncomplete: { ru: "Оплата не завершена.", en: "Payment wasn’t completed." },
  restoreNeeded: { ru: "Не удалось подтвердить выдачу покупки. Попробуй восстановить покупки.", en: "Couldn’t confirm delivery. Try restoring your purchases." },
  retryRestore: { ru: "Восстановить покупки", en: "Restore purchases" },
  premiumEmpty: { ru: "В каталоге пока нет доступных товаров.", en: "No products are available in the catalog yet." },
  cloudWaiting: { ru: "Покупки станут доступны после загрузки облачного сохранения.", en: "Purchases unlock after cloud progress has loaded." },
  cloudConflict: { ru: "В облаке есть другой прогресс. Его можно загрузить вместо текущего прогресса на этом устройстве.", en: "There is different progress in the cloud. You can load it instead of the current progress on this device." },
  cloudResolveBeforePurchase: { ru: "Перед покупкой загрузи облачный прогресс в настройках.", en: "Load your cloud progress in Settings before buying." },
  useCloud: { ru: "Заменить прогресс облачным", en: "Replace with cloud progress" },
  dailyTitle: { ru: "Ежедневный бонус", en: "Daily bonus" },
  dailyShort: { ru: "Ежедневно", en: "Daily" },
  dailyRules: { ru: "Забирай награду каждый день. После пропуска серия начинается заново.", en: "Claim a reward each day. Missing a day resets your streak." },
  dailyDay: { ru: "День {n}", en: "Day {n}" },
  dailyLuck: { ru: "🍀 Удача ×2 на {n} мин.", en: "🍀 Luck ×2 for {n} min" },
  dailyTomorrow: { ru: "Следующая награда завтра", en: "Next reward tomorrow" },
  title: { ru: "Клёвый Остров", en: "Bite Island" },
  subtitle: { ru: "3D рыбалка", en: "3D fishing" },
  play: { ru: "Играть", en: "Play" },
  loading: { ru: "Загрузка...", en: "Loading..." },
  hintDesktop: {
    ru: "WASD / Стрелки — ходить · Мышь — камера · Пробел — удочка · E — говорить",
    en: "WASD / Arrows — move · Mouse — camera · Space — rod · E — talk",
  },
  hintMobile: {
    ru: "Джойстик — ходить · Свайп — камера · Кнопка — удочка",
    en: "Joystick — move · Swipe — camera · Button — rod",
  },
  coins: { ru: "Монеты", en: "Coins" },
  bag: { ru: "Сумка", en: "Bag" },
  shop: { ru: "Магазин", en: "Shop" },
  map: { ru: "Карта", en: "Map" },
  collection: { ru: "Коллекция", en: "Index" },
  quests: { ru: "Задания", en: "Quests" },
  bonus: { ru: "Бонусы", en: "Bonus" },
  settings: { ru: "Настройки", en: "Settings" },
  close: { ru: "Закрыть", en: "Close" },
  actCast: { ru: "Заброс", en: "Cast" },
  actRelease: { ru: "Отпусти!", en: "Release!" },
  actReelIn: { ru: "Смотать", en: "Reel in" },
  actHook: { ru: "Подсечь!", en: "Hook!" },
  actPull: { ru: "Тяни!", en: "Pull!" },
  actOk: { ru: "Ура!", en: "Yay!" },
  auto: { ru: "АВТО", en: "AUTO" },
  npcMerchant: { ru: "Торговец", en: "Merchant" },
  npcShop: { ru: "Снасти", en: "Tackle" },
  npcBoat: { ru: "Капитан", en: "Captain" },
  talkMerchant: { ru: "Продать улов", en: "Sell fish" },
  talkShop: { ru: "Магазин снастей", en: "Tackle shop" },
  talkBoat: { ru: "Отплыть", en: "Set sail" },
  npcRocket: { ru: "Ракета на Луну", en: "Moon Rocket" },
  npcEarthRocket: { ru: "Ракета на Землю", en: "Earth Rocket" },
  talkRocket: { ru: "Полететь на Луну", en: "Fly to the Moon" },
  talkEarthRocket: { ru: "Вернуться на Землю", en: "Return to Earth" },
  noFishingHere: {
    ru: "На космодроме нельзя рыбачить! Подойди к ракете в центре 🚀",
    en: "No fishing at the Spaceport! Approach the rocket in the center 🚀",
  },
  spaceportNote: {
    ru: "Рыбалка запрещена · Ракета на Луну в центре острова (1B 🪙)",
    en: "No fishing · Moon Rocket in the center of the island (1B 🪙)",
  },
  needSpaceportRocket: {
    ru: "Запусти ракету в центре Космодрома за 1B монет!",
    en: "Launch the rocket at the Spaceport for 1B coins!",
  },
  planet1: { ru: "Планета 1: Земля", en: "Planet 1: Earth" },
  planet2: { ru: "Планета 2: Луна", en: "Planet 2: Moon" },
  launchMoon: { ru: "В космос!", en: "Launch!" },
  lunarHub: { ru: "Луна", en: "Moon" },
  lunarHubTitle: { ru: "Лунный Центр", en: "Lunar Center" },
  lunarGear: { ru: "Лунные снасти", en: "Lunar Tackle" },
  lunarUpgrades: { ru: "Технологии", en: "Lunar Tech" },
  petsTab: { ru: "Питомцы", en: "Pets" },
  exchangeTab: { ru: "Обменник", en: "Exchange" },
  notEnoughDiamonds: { ru: "Не хватает синих бриллиантов 💎", en: "Not enough blue diamonds 💎" },
  diamonds: { ru: "Бриллианты", en: "Diamonds" },
  exchTitle: { ru: "Галактический Обменник", en: "Galactic Exchange" },
  exchRate: { ru: "Курс: 1 000 000 🪙 = 1 💎", en: "Rate: 1,000,000 🪙 = 1 💎" },
  coinsToDia: { ru: "Монеты → Бриллианты", en: "Coins → Diamonds" },
  diaToCoins: { ru: "Бриллианты → Монеты", en: "Diamonds → Coins" },
  exchanged: { ru: "Обмен выполнен!", en: "Exchange complete!" },
  eggTitle: { ru: "Лунное Инкубатор-Яйцо", en: "Lunar Incubator Egg" },
  eggDesc: {
    ru: "Мгновенно вылупляется космический питомец! Удача влияет на редкость (шанс редких в 2.5 раза сложнее рыбы).",
    en: "Instantly hatches a cosmic pet! Luck affects rarity (2.5x harder than fish).",
  },
  hatchBtn: { ru: "Вылупить яйцо", en: "Hatch Egg" },
  hatched: { ru: "Вылупился питомец!", en: "Pet hatched!" },
  myPets: { ru: "Мои питомцы", en: "My Pets" },
  noPets: { ru: "У вас пока нет питомцев. Купите яйцо выше!", en: "No pets yet. Hatch an egg above!" },
  equipPet: { ru: "Надеть", en: "Equip" },
  unequipPet: { ru: "Снять", en: "Unequip" },
  luSuit: { ru: "Грави-катушка", en: "Gravi-Reel" },
  luSuitDesc: { ru: "Контроль на Луне и Земле: +{a} → +{b}", en: "Control: +{a} → +{b}" },
  luScanner: { ru: "Квантовый визор", en: "Quantum Visor" },
  luScannerDesc: { ru: "Удача: +{a}% → +{b}%", en: "Luck: +{a}% → +{b}%" },
  luExtractor: { ru: "Экстрактор Гелия-3", en: "Helium-3 Extractor" },
  luExtractorDesc: { ru: "Цена продажи (🪙 и 💎): +{a}% → +{b}%", en: "Sell value (🪙 & 💎): +{a}% → +{b}%" },
  luMutagen: { ru: "Лунный облучатель", en: "Lunar Irradiator" },
  luMutagenDesc: { ru: "Шанс мутации: +{a}% → +{b}%", en: "Mutation chance: +{a}% → +{b}%" },
  luIncubator: { ru: "Крио-инкубатор", en: "Cryo-Incubator" },
  luIncubatorDesc: { ru: "Удача яиц: +{a}% → +{b}%", en: "Egg luck: +{a}% → +{b}%" },
  hintFirstCast: {
    ru: "Удерживай кнопку и отпусти в зелёной зоне — заброс!",
    en: "Hold the button and release in the green zone to cast!",
  },
  hintWait: { ru: "Ждём поклёвку...", en: "Waiting for a bite..." },
  hintHook: { ru: "КЛЮЁТ! Жми!", en: "A BITE! Tap!" },
  hintReel: {
    ru: "Жми, когда стрелка в зелёной зоне!",
    en: "Tap when the marker is in the green zone!",
  },
  hintSell: { ru: "Продай улов у торговца или в сумке 🎒", en: "Sell your catch at the merchant or in the bag 🎒" },
  hintCharge: { ru: "Отпусти на максимуме!", en: "Release at max!" },
  aimWater: { ru: "Целься в воду!", en: "Aim at the water!" },
  bagFull: { ru: "Сумка полна! Продай улов", en: "Bag is full! Sell your catch" },
  escaped: { ru: "Рыба сорвалась...", en: "The fish got away..." },
  missedBite: { ru: "Не успел подсечь!", en: "Too slow to hook!" },
  notEnough: { ru: "Не хватает монет", en: "Not enough coins" },
  bought: { ru: "Куплено!", en: "Purchased!" },
  equipped: { ru: "Экипировано", en: "Equipped" },
  sold: { ru: "Продано на {n}", en: "Sold for {n}" },
  nothingToSell: { ru: "Нечего продавать", en: "Nothing to sell" },
  autoOff: { ru: "Автолов выключен", en: "Auto fishing off" },
  autoNeedWater: { ru: "Подойди ближе к воде", en: "Move closer to the water" },
  questDone: { ru: "Задание выполнено!", en: "Quest complete!" },
  hotspot: { ru: "Клёвое место! Удача ↑", en: "Hot spot! Luck ↑" },
  perfectCast: { ru: "ИДЕАЛЬНО!", en: "PERFECT!" },
  greatCast: { ru: "Отлично!", en: "Great!" },
  goodCast: { ru: "Хорошо", en: "Good" },
  okCast: { ru: "Слабо", en: "Weak" },
  mgPerfect: { ru: "ИДЕАЛЬНО!", en: "PERFECT!" },
  mgGood: { ru: "Есть!", en: "Nice!" },
  mgMiss: { ru: "Мимо!", en: "Miss!" },
  adNotReady: { ru: "Реклама сейчас недоступна, попробуйте позже", en: "Ad unavailable right now, try later" },
  rewardLuck: { ru: "Удача ×2 на 5 минут!", en: "Luck ×2 for 5 minutes!" },
  rewardAuto: { ru: "Автолов на 10 минут!", en: "Auto fishing for 10 minutes!" },
  rewardCoins: { ru: "Бонус +{n}", en: "Bonus +{n}" },
  caught: { ru: "Поймана!", en: "Caught!" },
  newFish: { ru: "НОВАЯ!", en: "NEW!" },
  perfectCatch: { ru: "Идеальное вываживание!", en: "Perfect catch!" },
  onLine: { ru: "На крючке", en: "On the line" },
  bagTitle: { ru: "Сумка", en: "Bag" },
  sellAll: { ru: "Продать всё", en: "Sell all" },
  sellX2: { ru: "×2 за рекламу", en: "×2 for Ad" },
  sell: { ru: "Продать", en: "Sell" },
  bagEmpty: { ru: "Сумка пуста. Иди лови рыбу!", en: "Bag is empty. Go fishing!" },
  favHint: { ru: "★ — избранные не продаются", en: "★ — favorites are not sold" },
  total: { ru: "Всего", en: "Total" },
  rods: { ru: "Удочки", en: "Rods" },
  baits: { ru: "Наживка", en: "Bait" },
  upgrades: { ru: "Улучшения", en: "Upgrades" },
  boosts: { ru: "Бонусы", en: "Boosts" },
  buy: { ru: "Купить", en: "Buy" },
  equip: { ru: "Взять", en: "Equip" },
  inUse: { ru: "В руках", en: "In use" },
  luck: { ru: "Удача", en: "Luck" },
  speed: { ru: "Скорость", en: "Speed" },
  control: { ru: "Контроль", en: "Control" },
  mutation: { ru: "Мутации", en: "Mutations" },
  bagUpgrade: { ru: "Большая сумка", en: "Bigger bag" },
  bagUpgradeDesc: { ru: "Вместимость: {a} → {b}", en: "Capacity: {a} → {b}" },
  luckUpgrade: { ru: "Счастливый крючок", en: "Lucky hook" },
  luckUpgradeDesc: { ru: "Удача: +{a}% → +{b}%", en: "Luck: +{a}% → +{b}%" },
  autoUpgrade: { ru: "Автоудочка навсегда", en: "Permanent auto rod" },
  autoUpgradeDesc: { ru: "Автолов без ограничений по времени", en: "Auto fishing without time limit" },
  mutUpgrade: { ru: "Мутагенная прикормка", en: "Mutagen Chum" },
  mutUpgradeDesc: { ru: "Шанс мутации: +{a}% → +{b}%", en: "Mutation chance: +{a}% → +{b}%" },
  priceUpgrade: { ru: "Торговая лицензия", en: "Trade Licence" },
  priceUpgradeDesc: { ru: "Цена продажи: +{a}% → +{b}%", en: "Sell price: +{a}% → +{b}%" },
  ctrlUpgrade: { ru: "Силовая катушка", en: "Power Reel" },
  ctrlUpgradeDesc: { ru: "Контроль: +{a} → +{b} (зона шире)", en: "Control: +{a} → +{b} (wider zone)" },
  spdUpgrade: { ru: "Эхолот", en: "Fish Finder" },
  spdUpgradeDesc: { ru: "Скорость клёва: +{a}% → +{b}%", en: "Bite speed: +{a}% → +{b}%" },
  owned: { ru: "Есть", en: "Owned" },
  maxed: { ru: "Максимум", en: "Maxed" },
  level: { ru: "Ур.", en: "Lv." },
  watchAd: { ru: "За рекламу", en: "Watch Ad" },
  boostLuckTitle: { ru: "Удача ×2", en: "Luck ×2" },
  boostLuckDesc: { ru: "Награда за просмотр рекламы: 5 мин двойной удачи", en: "Ad reward: 5 min of double luck" },
  boostAutoTitle: { ru: "Автолов", en: "Auto fishing" },
  boostAutoDesc: { ru: "Награда за просмотр рекламы: 10 мин автолова", en: "Ad reward: 10 min of auto fishing" },
  boostCoinsTitle: { ru: "Мешок монет", en: "Bag of coins" },
  boostCoinsDesc: { ru: "Награда за просмотр рекламы: +{n} монет", en: "Ad reward: +{n} coins" },
  active: { ru: "Активно", en: "Active" },
  wait: { ru: "Подожди", en: "Wait" },
  mapTitle: { ru: "Карта островов", en: "Island map" },
  sail: { ru: "Плыть", en: "Sail" },
  unlock: { ru: "Открыть", en: "Unlock" },
  youAreHere: { ru: "Вы здесь", en: "You are here" },
  fishCaught: { ru: "Рыб поймано", en: "Fish caught" },
  collectionTitle: { ru: "Коллекция рыб", en: "Fish index" },
  collectReward: { ru: "Собери всех: +10% удачи навсегда", en: "Collect all: +10% luck forever" },
  collectDone: { ru: "Собрано! +10% удачи", en: "Complete! +10% luck" },
  best: { ru: "Рекорд", en: "Best" },
  times: { ru: "×", en: "×" },
  unknown: { ru: "???", en: "???" },
  questsTitle: { ru: "Задания", en: "Quests" },
  claim: { ru: "Забрать", en: "Claim" },
  reward: { ru: "Награда", en: "Reward" },
  qCatch: { ru: "Поймай {n} рыб", en: "Catch {n} fish" },
  qRarity: { ru: "Поймай {n} рыб ({r} или лучше)", en: "Catch {n} fish ({r} or better)" },
  qSell: { ru: "Заработай {n} на продаже", en: "Earn {n} from selling" },
  qPerfect: { ru: "Сделай {n} идеальных забросов", en: "Make {n} perfect casts" },
  qMutation: { ru: "Поймай {n} рыб с мутацией", en: "Catch {n} mutated fish" },
  qIsland: { ru: "Поймай {n} рыб: {i}", en: "Catch {n} fish at {i}" },
  sound: { ru: "Звуки", en: "Sounds" },
  music: { ru: "Музыка", en: "Music" },
  language: { ru: "Язык", en: "Language" },
  graphics: { ru: "Графика", en: "Graphics" },
  gfxHigh: { ru: "Высокая", en: "High" },
  gfxLow: { ru: "Быстрая", en: "Fast" },
  on: { ru: "Вкл", en: "On" },
  off: { ru: "Выкл", en: "Off" },
  stats: { ru: "Статистика", en: "Stats" },
  statCaught: { ru: "Поймано рыб", en: "Fish caught" },
  statEarned: { ru: "Заработано", en: "Earned" },
  statPerfect: { ru: "Идеальных забросов", en: "Perfect casts" },
  statLuck: { ru: "Текущая удача", en: "Current luck" },
  authTitle: { ru: "Облачное сохранение (Яндекс ID)", en: "Cloud Save (Yandex ID)" },
  authDesc: { ru: "Авторизуйтесь, чтобы синхронизировать прогресс между всеми вашими устройствами", en: "Sign in to sync your game progress across all your devices" },
  authBtn: { ru: "Войти", en: "Sign in" },
  authDone: { ru: "Синхронизировано", en: "Synced" },
  evStorm: { ru: "Шторм: удача ×1.5", en: "Storm: luck ×1.5" },
  evStarfall: { ru: "Звездопад: мутации ×3", en: "Starfall: mutations ×3" },
  evFrenzy: { ru: "Жор: клюёт вдвое быстрее", en: "Frenzy: bites twice as fast" },
  evStarted: { ru: "Событие!", en: "Event!" },
  kg: { ru: "кг", en: "kg" },
  t: { ru: "т", en: "t" },
};

export function t(key, vars) {
  let s = D[key][currentLang] ?? D[key].ru;
  if (vars) for (const k of Object.keys(vars)) s = s.split(`{${k}}`).join(String(vars[k]));
  return s;
}

export function fmtNum(n) {
  const a = Math.abs(n);
  if (a >= 1e9) return (n / 1e9).toFixed(a >= 1e10 ? 0 : 1).replace(/\.0$/, "") + "B";
  if (a >= 1e6) return (n / 1e6).toFixed(a >= 1e7 ? 1 : 2).replace(/\.?0+$/, "") + "M";
  if (a >= 1e5) return Math.round(n / 1e3) + "K";
  return Math.round(n)
    .toString()
    .replace(/\B(?=(\d{3})+(?!\d))/g, "\u2009");
}

export function fmtWeight(kg) {
  if (kg >= 1000) return (kg / 1000).toFixed(kg >= 10000 ? 1 : 2) + " " + t("t");
  if (kg >= 100) return kg.toFixed(0) + " " + t("kg");
  if (kg >= 10) return kg.toFixed(1) + " " + t("kg");
  return kg.toFixed(2) + " " + t("kg");
}

export function fmtTime(ms) {
  const s = Math.max(0, Math.ceil(ms / 1000));
  const m = Math.floor(s / 60);
  return `${m}:${String(s % 60).padStart(2, "0")}`;
}

export const RARITIES = [
  { id: "common", idx: 0, name: { ru: "Обычная", en: "Common" }, color: "#c3ccd6", weight: 620, boost: 0, mg: { speed: 0.42, zone: 0.32, hits: 3, drain: 0.014, penalty: 0.08 } },
  { id: "uncommon", idx: 1, name: { ru: "Необычная", en: "Uncommon" }, color: "#5ddc5d", weight: 250, boost: 0.5, mg: { speed: 0.47, zone: 0.3, hits: 3, drain: 0.017, penalty: 0.1 } },
  { id: "rare", idx: 2, name: { ru: "Редкая", en: "Rare" }, color: "#4aa8ff", weight: 90, boost: 1, mg: { speed: 0.52, zone: 0.27, hits: 4, drain: 0.02, penalty: 0.11 } },
  { id: "epic", idx: 3, name: { ru: "Эпическая", en: "Epic" }, color: "#b46cff", weight: 30, boost: 1.5, mg: { speed: 0.57, zone: 0.25, hits: 4, drain: 0.024, penalty: 0.13 } },
  { id: "legendary", idx: 4, name: { ru: "Легендарная", en: "Legendary" }, color: "#ffb02e", weight: 8, boost: 2, mg: { speed: 0.62, zone: 0.23, hits: 5, drain: 0.028, penalty: 0.15 } },
  { id: "mythic", idx: 5, name: { ru: "Мифическая", en: "Mythic" }, color: "#ff4d6d", weight: 0.72, boost: 2.2, mg: { speed: 0.68, zone: 0.21, hits: 6, drain: 0.032, penalty: 0.17 } },
  { id: "secret", idx: 6, name: { ru: "Секретная", en: "Secret" }, color: "#3dfcff", weight: 0.06, boost: 2.5, mg: { speed: 0.75, zone: 0.19, hits: 7, drain: 0.036, penalty: 0.19 } },
];
export const RARITY = Object.fromEntries(RARITIES.map((r) => [r.id, r]));

export const MUTATIONS = [
  { id: "albino", name: { ru: "Альбинос", en: "Albino" }, mult: 1.5, weight: 40, color: "#f4f4f4" },
  { id: "shiny", name: { ru: "Сияющая", en: "Shiny" }, mult: 2, weight: 30, color: "#fff27a" },
  { id: "golden", name: { ru: "Золотая", en: "Golden" }, mult: 3, weight: 15, color: "#ffc400" },
  { id: "ghost", name: { ru: "Призрачная", en: "Ghost" }, mult: 4, weight: 8, color: "#9ff0ff" },
  { id: "crystal", name: { ru: "Кристальная", en: "Crystal" }, mult: 5, weight: 7, color: "#7fd8ff" },
  { id: "galaxy", name: { ru: "Галактическая", en: "Galaxy" }, mult: 6, weight: 5, color: "#9a6aff" },
  { id: "solar", name: { ru: "Солнечная", en: "Solar" }, mult: 8, weight: 3, color: "#ffb02e" },
  { id: "rainbow", name: { ru: "Радужная", en: "Rainbow" }, mult: 10, weight: 2, color: "rainbow" },
  { id: "void", name: { ru: "Пустотная", en: "Void" }, mult: 20, weight: 0.8, color: "#4a1a7a" },
];
export const MUTATION = Object.fromEntries(MUTATIONS.map((m) => [m.id, m]));

const f = (id, ru, en, rarity, island, price, minW, maxW, body, belly, fin, shape, extra = {}) => ({
  id, name: { ru, en }, rarity, island, price, minW, maxW, body, belly, fin, shape, ...extra,
});

export const FISH = [
  // Солнечная Бухта
  f("carp", "Карась", "Crucian Carp", "common", "sunny", 4, 0.2, 1.5, "#c9a227", "#f3e2a0", "#b5651d", "normal"),
  f("goby", "Бычок", "Goby", "common", "sunny", 3, 0.1, 0.6, "#8a7a5a", "#d9cfae", "#6b5a3a", "normal", { pattern: "spots" }),
  f("perch", "Окунь", "Perch", "uncommon", "sunny", 14, 0.3, 2.5, "#7ea83a", "#eee6a0", "#ff6a2b", "normal", { pattern: "stripes", accent: "#2f4a1a" }),
  f("bream", "Лещ", "Bream", "uncommon", "sunny", 16, 0.5, 4, "#b5b39a", "#efeadb", "#807a68", "tall"),
  f("pike", "Щука", "Pike", "rare", "sunny", 48, 1, 15, "#5d7f3a", "#e0e8c0", "#9a7a3a", "long", { pattern: "spots", accent: "#d8e0a0" }),
  f("sunfish", "Солнечник", "Sunfish", "rare", "sunny", 55, 0.4, 3, "#f2b84e", "#fff2c0", "#f27a30", "round"),
  f("trout", "Радужная форель", "Rainbow Trout", "epic", "sunny", 160, 1, 8, "#86aed0", "#f7d6de", "#e07aa0", "normal", { pattern: "spots", accent: "#3a4a6a" }),
  f("salmon", "Королевский лосось", "King Salmon", "legendary", "sunny", 650, 5, 35, "#c95a4a", "#f2c4a8", "#8a3a3a", "normal"),
  f("goldcarp", "Золотой карп удачи", "Golden Fortune Carp", "mythic", "sunny", 2600, 2, 15, "#ffd34d", "#fff3b0", "#ff9d00", "normal", { glow: true }),
  f("sunlev", "Солнечный левиафан", "Sun Leviathan", "secret", "sunny", 14000, 300, 1200, "#ff9a3c", "#ffe08a", "#ff4a1f", "shark", { glow: true }),
  // Коралловый Риф
  f("clown", "Рыба-клоун", "Clownfish", "common", "coral", 12, 0.1, 0.4, "#ff7a1a", "#ffd0a0", "#1a1a1a", "normal", { pattern: "stripes", accent: "#ffffff" }),
  f("tang", "Синий хирург", "Blue Tang", "common", "coral", 10, 0.2, 0.9, "#2a5fd6", "#4a86f0", "#ffd400", "tall"),
  f("angel", "Рыба-ангел", "Angelfish", "uncommon", "coral", 45, 0.3, 1.6, "#ffd23a", "#ffe98a", "#2a7ad6", "tall", { pattern: "stripes", accent: "#2a7ad6" }),
  f("parrot", "Рыба-попугай", "Parrotfish", "uncommon", "coral", 50, 1, 7, "#3ad6a0", "#ff9ac8", "#6a5ad6", "normal"),
  f("puffer", "Рыба-шар", "Pufferfish", "rare", "coral", 140, 0.5, 3, "#e8d07a", "#fff8e0", "#a08a3a", "round", { pattern: "spots", accent: "#6a5a2a" }),
  f("moray", "Мурена", "Moray Eel", "rare", "coral", 160, 2, 18, "#5a8a3a", "#b0d070", "#2a4a2a", "long", { pattern: "spots", accent: "#e8f0a0" }),
  f("sray", "Пятнистый скат", "Spotted Ray", "epic", "coral", 480, 5, 45, "#3a4a6a", "#e6e6f2", "#2a3450", "ray", { pattern: "spots", accent: "#ffffff" }),
  f("swordfish", "Рыба-меч", "Swordfish", "legendary", "coral", 1950, 30, 250, "#3a5a8a", "#c8d6e6", "#2a3a5a", "sword"),
  f("coraldragon", "Коралловый дракон", "Coral Dragon", "mythic", "coral", 7800, 10, 70, "#ff5a8a", "#ffc6d6", "#ff2a6a", "long", { glow: true }),
  f("pearlwhale", "Жемчужный кит", "Pearl Whale", "secret", "coral", 42000, 2000, 9000, "#e8f4ff", "#ffffff", "#a8d4ff", "shark", { glow: true }),
  // Ледяной Фьорд
  f("cod", "Треска", "Cod", "common", "frost", 32, 1, 9, "#8a9a7e", "#e4ece0", "#6a7a60", "normal", { pattern: "spots", accent: "#5a6a50" }),
  f("herring", "Сельдь", "Herring", "common", "frost", 26, 0.2, 0.9, "#5f86b5", "#eef4fa", "#4a6a90", "normal"),
  f("char", "Арктический голец", "Arctic Char", "uncommon", "frost", 115, 1, 7, "#4a6a8a", "#ff7a4a", "#ff9a6a", "normal", { pattern: "spots", accent: "#ffd0b0" }),
  f("halibut", "Палтус", "Halibut", "uncommon", "frost", 130, 5, 70, "#6a5a4a", "#f2f2ea", "#5a4a3a", "ray", { pattern: "spots", accent: "#3a2e24" }),
  f("icefish", "Ледяная рыба", "Icefish", "rare", "frost", 390, 0.5, 3, "#cfe9f2", "#ffffff", "#9ccbe2", "long", { glow: true }),
  f("wolffish", "Морской волк", "Wolffish", "rare", "frost", 420, 3, 22, "#5a6a7a", "#a8b0b8", "#3a4a5a", "long", { pattern: "stripes", accent: "#2a3440" }),
  f("sturgeon", "Северный осётр", "Northern Sturgeon", "epic", "frost", 1300, 20, 160, "#6a7a8a", "#d6dde4", "#4a5a6a", "shark"),
  f("greenshark", "Гренландская акула", "Greenland Shark", "legendary", "frost", 5200, 200, 1100, "#4a5560", "#8e9aa4", "#3a4450", "shark"),
  f("aurora", "Аврора-плавник", "Aurora Fin", "mythic", "frost", 21000, 5, 35, "#4affc0", "#c6a6ff", "#ff6aff", "tall", { glow: true }),
  f("frostkraken", "Ледяной кракен", "Frost Kraken", "secret", "frost", 110000, 600, 3500, "#a6e2ff", "#ffffff", "#5ca0d0", "squid", { glow: true }),
  // Пепельный Вулкан
  f("ashperch", "Пепельный окунь", "Ash Perch", "common", "volcano", 80, 0.5, 3, "#4e4e4e", "#8e8e8e", "#ff5a1a", "normal", { pattern: "stripes", accent: "#222222" }),
  f("coalfish", "Угольная рыба", "Coalfish", "common", "volcano", 70, 1, 6, "#2c2c2c", "#5e5e5e", "#ff8a2a", "normal"),
  f("lavacat", "Лавовый сом", "Lava Catfish", "uncommon", "volcano", 280, 3, 22, "#6a2a1a", "#ff8a4a", "#ff4a1a", "long", { glow: true }),
  f("obsidianpuffer", "Обсидиановый шар", "Obsidian Puffer", "uncommon", "volcano", 300, 0.5, 4, "#1c1c2a", "#4a3a5a", "#ff6a2a", "round", { glow: true }),
  f("magmaeel", "Магмовый угорь", "Magma Eel", "rare", "volcano", 950, 2, 14, "#ff4a1a", "#ffd04a", "#8a1a0a", "long", { glow: true }),
  f("firelion", "Огненная крылатка", "Fire Lionfish", "rare", "volcano", 1050, 0.5, 2.5, "#ff6a3a", "#fff0d0", "#ff2a0a", "tall", { pattern: "stripes", accent: "#fff0d0" }),
  f("basaltshark", "Базальтовая акула", "Basalt Shark", "epic", "volcano", 3200, 100, 650, "#3a3030", "#6a5a5a", "#ff5a2a", "shark", { glow: true }),
  f("phoenix", "Рыба-феникс", "Phoenix Fish", "legendary", "volcano", 13000, 5, 45, "#ff8a1a", "#ffe04a", "#ff3a1a", "tall", { glow: true }),
  f("volcanoheart", "Сердце вулкана", "Volcano Heart", "mythic", "volcano", 52000, 20, 110, "#ff2a00", "#ffaa00", "#ff5500", "round", { glow: true }),
  f("ashserpent", "Пепельный змей", "Ash Serpent", "secret", "volcano", 280000, 1000, 5500, "#2a1a1a", "#ff4a00", "#ff8a00", "long", { glow: true }),
  // Мистическая Бездна
  f("glowfin", "Светоплав", "Glowfin", "common", "abyss", 200, 0.3, 2, "#3a2a7a", "#8a7aff", "#4affff", "normal", { glow: true }),
  f("duskfish", "Сумрачник", "Dusk Fish", "common", "abyss", 180, 0.5, 3, "#2a2a4a", "#6a6a9a", "#9a6aff", "normal"),
  f("angler", "Удильщик", "Anglerfish", "uncommon", "abyss", 700, 1, 9, "#2a2a3a", "#5a5a6a", "#ffff8a", "round", { glow: true }),
  f("crystalfish", "Кристальная рыба", "Crystal Fish", "uncommon", "abyss", 750, 0.5, 4, "#a6f0ff", "#ffffff", "#c6a6ff", "tall", { glow: true }),
  f("phantomray", "Призрачный скат", "Phantom Ray", "rare", "abyss", 2400, 10, 55, "#6a4aff", "#c6b6ff", "#4a2ad0", "ray", { glow: true }),
  f("stareel", "Звёздный угорь", "Star Eel", "rare", "abyss", 2600, 3, 22, "#1a1a4a", "#3a3a7a", "#6a8aff", "long", { pattern: "spots", accent: "#ffffff" }),
  f("runefish", "Рунная рыба", "Rune Fish", "epic", "abyss", 8000, 5, 32, "#3affc0", "#1a4a4a", "#3affc0", "normal", { glow: true, pattern: "stripes", accent: "#0a2a2a" }),
  f("coelacanth", "Древний целакант", "Ancient Coelacanth", "legendary", "abyss", 32000, 50, 220, "#3a4a6a", "#8a9aba", "#6a7a9a", "normal", { pattern: "spots", accent: "#c8d4ee" }),
  f("cosmolev", "Космический левиафан", "Cosmic Leviathan", "mythic", "abyss", 130000, 1000, 8000, "#2a1a6a", "#ff6aff", "#6affff", "shark", { glow: true }),
  f("abysseye", "Глаз Бездны", "Eye of the Abyss", "secret", "abyss", 700000, 5000, 20000, "#0e0a1e", "#ff2a6a", "#8a2aff", "round", { glow: true }),
  // Затонувший Город
  f("ruinperch", "Руинный окунь", "Ruin Perch", "common", "sunken", 900, 0.4, 3, "#6a8a7a", "#cfe0d0", "#4a6a5a", "normal", { pattern: "stripes", accent: "#2f4a3a" }),
  f("silttetra", "Иловая тетра", "Silt Tetra", "common", "sunken", 820, 0.1, 0.8, "#8a9a8a", "#dfe8dc", "#6a7a6a", "tall"),
  f("marblecarp", "Мраморный карп", "Marble Carp", "uncommon", "sunken", 3200, 2, 18, "#e8e4da", "#ffffff", "#9a9488", "normal", { pattern: "spots", accent: "#8a8478" }),
  f("columnfish", "Колонная рыба", "Column Fish", "uncommon", "sunken", 3400, 1, 9, "#d8d0bc", "#f4eee0", "#a89a7a", "long", { pattern: "stripes", accent: "#8a7a5a" }),
  f("amphoraeel", "Амфорный угорь", "Amphora Eel", "rare", "sunken", 11000, 3, 26, "#9a6a3a", "#e0c08a", "#6a4a2a", "long", { pattern: "spots", accent: "#4a3420" }),
  f("mosaicray", "Мозаичный скат", "Mosaic Ray", "rare", "sunken", 12000, 12, 70, "#3a7a8a", "#d8f0f0", "#2a5a6a", "ray", { pattern: "spots", accent: "#ffd23a" }),
  f("templejelly", "Храмовая медуза", "Temple Jelly", "epic", "sunken", 38000, 2, 20, "#7affd0", "#d0fff0", "#3ab0a0", "jelly", { glow: true }),
  f("goldenidol", "Золотой идол", "Golden Idol", "legendary", "sunken", 150000, 8, 60, "#ffcf33", "#fff0a0", "#c89a00", "round", { glow: true }),
  f("livingstatue", "Ожившая статуя", "Living Statue", "mythic", "sunken", 650000, 120, 900, "#8a9a9a", "#cfe0e0", "#4a6a6a", "shark", { glow: true }),
  f("atlantiswyrm", "Змей Атлантиды", "Atlantis Wyrm", "secret", "sunken", 3200000, 2500, 12000, "#1a6a7a", "#7affd0", "#ffd23a", "long", { glow: true }),
  // Грозовой Архипелаг
  f("sparkminnow", "Искровая уклейка", "Spark Minnow", "common", "storm", 4000, 0.1, 0.7, "#cfe0f0", "#ffffff", "#6ac8ff", "normal", { glow: true }),
  f("thunderperch", "Громовой окунь", "Thunder Perch", "common", "storm", 3600, 0.5, 4, "#4a5a7a", "#c0d4ea", "#ffe14d", "normal", { pattern: "stripes", accent: "#ffe14d" }),
  f("galefish", "Шквальная рыба", "Gale Fish", "uncommon", "storm", 14000, 1, 10, "#7a8aa0", "#e0eaf4", "#4a6a90", "tall"),
  f("cloudray", "Облачный скат", "Cloud Ray", "uncommon", "storm", 15000, 10, 80, "#dfe8f2", "#ffffff", "#9ab0c8", "ray", { glow: true }),
  f("stormeel", "Штормовой угорь", "Storm Eel", "rare", "storm", 50000, 4, 34, "#2a3a6a", "#6a8aff", "#ffe14d", "long", { glow: true }),
  f("typhoontuna", "Тайфунный тунец", "Typhoon Tuna", "rare", "storm", 52000, 30, 220, "#2a5a8a", "#d0e4f4", "#6ac8ff", "shark"),
  f("boltmarlin", "Молниевый марлин", "Bolt Marlin", "epic", "storm", 165000, 60, 420, "#1a2a5a", "#8ab0e0", "#ffe14d", "sword", { glow: true }),
  f("thunderbird", "Рыба-громовержец", "Thunderbird Fish", "legendary", "storm", 640000, 20, 150, "#ffe14d", "#fff6c0", "#ff8a1a", "tall", { glow: true }),
  f("tempestkraken", "Буревой кракен", "Tempest Kraken", "mythic", "storm", 2900000, 800, 4500, "#3a4a7a", "#8ab0ff", "#ffe14d", "squid", { glow: true }),
  f("skyserpent", "Небесный змей", "Sky Serpent", "secret", "storm", 14000000, 3000, 16000, "#6a3aff", "#ffffff", "#ffe14d", "long", { glow: true }),
  // Небесное Озеро
  f("starminnow", "Звёздная уклейка", "Star Minnow", "common", "celestial", 18000, 0.1, 0.9, "#fff6c0", "#ffffff", "#ffd23a", "normal", { glow: true }),
  f("moonfry", "Лунный малёк", "Moon Fry", "common", "celestial", 16000, 0.2, 1.6, "#d6dcff", "#ffffff", "#8a9aff", "round", { glow: true }),
  f("cometfish", "Кометная рыба", "Comet Fish", "uncommon", "celestial", 60000, 1, 12, "#8ad0ff", "#ffffff", "#ff9a3c", "long", { glow: true }),
  f("nebulajelly", "Туманная медуза", "Nebula Jelly", "uncommon", "celestial", 62000, 3, 30, "#b46cff", "#ffd0f0", "#6a3aff", "jelly", { glow: true }),
  f("solarray", "Солнечный скат", "Solar Ray", "rare", "celestial", 220000, 25, 180, "#ffb02e", "#fff2a0", "#ff6a1a", "ray", { glow: true }),
  f("auroraeel", "Угорь сияния", "Aurora Eel", "rare", "celestial", 230000, 6, 45, "#3affd0", "#c6a6ff", "#ff6aff", "long", { glow: true }),
  f("constellation", "Созвездная рыба", "Constellation Fish", "epic", "celestial", 730000, 10, 90, "#1a1a5a", "#4a4aa0", "#ffffff", "tall", { glow: true, pattern: "spots", accent: "#ffffff" }),
  f("zodiacwhale", "Зодиакальный кит", "Zodiac Whale", "legendary", "celestial", 2900000, 3000, 18000, "#2a2a7a", "#8a8aff", "#ffd23a", "shark", { glow: true }),
  f("dawnkeeper", "Хранитель рассвета", "Dawn Keeper", "mythic", "celestial", 13000000, 200, 1400, "#ffd6a0", "#fff6e0", "#ff8a3c", "normal", { glow: true }),
  f("infinityfish", "Рыба Бесконечности", "Infinity Fish", "secret", "celestial", 60000000, 10000, 60000, "#ffffff", "#c6a6ff", "#3affd0", "jelly", { glow: true }),
  // Луна (Планета 2) — Кратер Спокойствия (цены в синих бриллиантах 💎)
  f("regolithgoby", "Реголитовый бычок", "Regolith Goby", "common", "lunar_crater", 2, 0.3, 2.2, "#8a92a6", "#d4dce8", "#586074", "normal", { pattern: "spots", accent: "#434a5a", dia: true }),
  f("cratersardine", "Кратерная сардина", "Crater Sardine", "common", "lunar_crater", 2, 0.2, 1.4, "#9bb0c8", "#eef6ff", "#5c7a9e", "normal", { dia: true }),
  f("heliumperch", "Гелиевый окунь", "Helium Perch", "uncommon", "lunar_crater", 6, 1, 9, "#38bdf8", "#e0f2fe", "#0284c7", "tall", { glow: true, pattern: "stripes", accent: "#0369a1", dia: true }),
  f("selenecarp", "Селеновый карп", "Selene Carp", "uncommon", "lunar_crater", 7, 2, 16, "#cbd5e1", "#ffffff", "#94a3b8", "normal", { glow: true, dia: true }),
  f("zerogray", "Невесомый скат", "Zero-G Ray", "rare", "lunar_crater", 22, 15, 120, "#6366f1", "#e0e7ff", "#38bdf8", "ray", { glow: true, pattern: "spots", accent: "#ffffff", dia: true }),
  f("meteoreel", "Метеоритный угорь", "Meteor Eel", "rare", "lunar_crater", 25, 5, 42, "#334155", "#94a3b8", "#f97316", "long", { glow: true, dia: true }),
  f("lunarjelly", "Лунная медуза", "Lunar Jelly", "epic", "lunar_crater", 85, 4, 38, "#7dd3fc", "#f0f9ff", "#38bdf8", "jelly", { glow: true, dia: true }),
  f("eclipsewhale", "Кит Затмения", "Eclipse Whale", "legendary", "lunar_crater", 350, 2500, 15000, "#0f172a", "#38bdf8", "#facc15", "shark", { glow: true, dia: true }),
  f("chronokraken", "Хроно-кракен Приливов", "Tidal Chrono-Kraken", "mythic", "lunar_crater", 1600, 900, 6000, "#1e1b4b", "#818cf8", "#2dd4bf", "squid", { glow: true, dia: true }),
  f("moonmonarch", "Владыка Тёмной Стороны", "Dark Side Monarch", "secret", "lunar_crater", 8500, 8000, 48000, "#090d16", "#38bdf8", "#f43f5e", "sword", { glow: true, dia: true }),
];
export const FISH_MAP = Object.fromEntries(FISH.map((x) => [x.id, x]));

export const RODS = [
  { id: "bamboo", name: { ru: "Бамбуковая удочка", en: "Bamboo Rod" }, price: 0, luck: 0, speed: 0, control: 0, color: "#d8b45a", accent: "#7a5a2a" },
  { id: "willow", name: { ru: "Ивовая удочка", en: "Willow Rod" }, price: 300, luck: 10, speed: 5, control: 4, color: "#8a5a2a", accent: "#d8c08a" },
  { id: "carbon", name: { ru: "Карбоновый спиннинг", en: "Carbon Spinner" }, price: 1800, luck: 22, speed: 12, control: 8, color: "#2a2a2e", accent: "#e03a3a" },
  { id: "coralrod", name: { ru: "Коралловая удочка", en: "Coral Rod" }, price: 6000, luck: 40, speed: 18, control: 13, color: "#ff6a8a", accent: "#ffd0dc" },
  { id: "frostrod", name: { ru: "Морозный спиннинг", en: "Frost Spinner" }, price: 18000, luck: 65, speed: 25, control: 18, color: "#8ad8ff", accent: "#ffffff", glow: true },
  { id: "magmarod", name: { ru: "Магмовая удочка", en: "Magma Rod" }, price: 50000, luck: 95, speed: 32, control: 23, color: "#ff5a1a", accent: "#ffd04a", glow: true },
  { id: "lunar", name: { ru: "Лунная удочка", en: "Lunar Rod" }, price: 140000, luck: 140, speed: 40, control: 28, color: "#d6dcff", accent: "#8a9aff", glow: true },
  { id: "astral", name: { ru: "Звёздная удочка", en: "Astral Rod" }, price: 400000, luck: 210, speed: 48, control: 34, color: "#7a5aff", accent: "#ff9aff", glow: true },
  { id: "trident", name: { ru: "Трезубец глубин", en: "Abyss Trident" }, price: 1000000, luck: 300, speed: 58, control: 40, color: "#2affc0", accent: "#1a6a8a", glow: true },
  { id: "prism", name: { ru: "Призматическая удочка", en: "Prismatic Rod" }, price: 3000000, luck: 450, speed: 72, control: 50, color: "#ffffff", accent: "#ff6aff", glow: true, rainbow: true },
  { id: "abysscall", name: { ru: "Зов Бездны", en: "Abyss Call" }, price: 10000000, luck: 650, speed: 85, control: 58, color: "#1a6a7a", accent: "#7affd0", glow: true },
  { id: "stormbreaker", name: { ru: "Громовержец", en: "Stormbreaker" }, price: 40000000, luck: 900, speed: 100, control: 66, color: "#3a4a8a", accent: "#ffe14d", glow: true },
  { id: "celestialrod", name: { ru: "Небесная ось", en: "Celestial Axis" }, price: 150000000, luck: 1250, speed: 120, control: 75, color: "#ffd6a0", accent: "#8a9aff", glow: true },
  { id: "infinityrod", name: { ru: "Удочка Бесконечности", en: "Infinity Rod" }, price: 600000000, luck: 1800, speed: 145, control: 85, color: "#ffffff", accent: "#3affd0", glow: true, rainbow: true },
  // Лунные удочки (покупаются за синие бриллианты 💎 в Лунном Центре)
  { id: "selenite", lunar: true, name: { ru: "Селенитовый спиннинг", en: "Selenite Spinner" }, price: 120, luck: 2600, speed: 170, control: 95, color: "#38bdf8", accent: "#e0f2fe", glow: true },
  { id: "apollo", lunar: true, name: { ru: "Грави-спиннинг «Аполлон»", en: "Apollo Gravi-Rod" }, price: 550, luck: 3800, speed: 200, control: 108, color: "#f8fafc", accent: "#f59e0b", glow: true },
  { id: "tranquility", lunar: true, name: { ru: "Гарпун Спокойствия", en: "Tranquility Harpoon" }, price: 2400, luck: 5600, speed: 235, control: 122, color: "#0284c7", accent: "#7dd3fc", glow: true },
  { id: "darkside", lunar: true, name: { ru: "Ось Тёмной Стороны", en: "Dark Side Axis" }, price: 11000, luck: 8500, speed: 275, control: 138, color: "#0f172a", accent: "#f43f5e", glow: true },
  { id: "quasar", lunar: true, name: { ru: "Квазарный Лучемет", en: "Quasar Beam Rod" }, price: 50000, luck: 13500, speed: 320, control: 155, color: "#38bdf8", accent: "#ffffff", glow: true, rainbow: true },
];
export const ROD_MAP = Object.fromEntries(RODS.map((x) => [x.id, x]));

export const BAITS = [
  { id: "worm", name: { ru: "Червяк", en: "Worm" }, price: 0, luck: 0, speed: 0, mut: 0, icon: "🐛" },
  { id: "bloodworm", name: { ru: "Мотыль", en: "Bloodworm" }, price: 250, luck: 5, speed: 10, mut: 0, icon: "🔴" },
  { id: "shrimp", name: { ru: "Креветка", en: "Shrimp" }, price: 1500, luck: 12, speed: 12, mut: 0.5, icon: "🦐" },
  { id: "squidbait", name: { ru: "Кальмар", en: "Squid" }, price: 7000, luck: 20, speed: 18, mut: 1, icon: "🦑" },
  { id: "glowbug", name: { ru: "Светлячок", en: "Glow Bug" }, price: 25000, luck: 30, speed: 20, mut: 2, icon: "✨" },
  { id: "goldspoon", name: { ru: "Золотая блесна", en: "Golden Spoon" }, price: 100000, luck: 45, speed: 25, mut: 3, icon: "🥄" },
  { id: "stardust", name: { ru: "Звёздная пыль", en: "Stardust" }, price: 450000, luck: 65, speed: 30, mut: 5, icon: "🌟" },
  { id: "pearl", name: { ru: "Жемчужная приманка", en: "Pearl Lure" }, price: 1800000, luck: 85, speed: 35, mut: 7, icon: "🫧" },
  { id: "voltlure", name: { ru: "Грозовая блесна", en: "Volt Lure" }, price: 7000000, luck: 110, speed: 42, mut: 9, icon: "⚡" },
  { id: "cosmic", name: { ru: "Космический планктон", en: "Cosmic Plankton" }, price: 30000000, luck: 140, speed: 50, mut: 12, icon: "🌌" },
  // Лунные наживки (за синие бриллианты 💎)
  { id: "helium3", lunar: true, name: { ru: "Капсула Гелия-3", en: "Helium-3 Capsule" }, price: 60, luck: 210, speed: 65, mut: 16, icon: "🛰️" },
  { id: "regolithworm", lunar: true, name: { ru: "Реголитовый червь", en: "Regolith Worm" }, price: 280, luck: 340, speed: 85, mut: 21, icon: "🪱" },
  { id: "lunarcore", lunar: true, name: { ru: "Ядро Селены", en: "Selene Core" }, price: 1400, luck: 550, speed: 110, mut: 27, icon: "☄️" },
  { id: "neutronlure", lunar: true, name: { ru: "Нейтронная приманка", en: "Neutron Lure" }, price: 6500, luck: 900, speed: 140, mut: 35, icon: "💠" },
];
export const BAIT_MAP = Object.fromEntries(BAITS.map((x) => [x.id, x]));

export const EGG_PRICE = 25; // в синих бриллиантах 💎
export const PET_MAX_EQUIP = 3;
const PET_LIMIT = 100;
const EGG_COOLDOWN = 20 * 60_000;
export const PETS = [
  { id: "tardigrade", rarity: "common", icon: "🦠", name: { ru: "Лунный тихоход", en: "Lunar Tardigrade" }, luck: 15, speed: 5, mut: 0, val: 5, color: "#94a3b8" },
  { id: "dustcrab", rarity: "common", icon: "🦀", name: { ru: "Пылевой крабик", en: "Dust Crab" }, luck: 20, speed: 8, mut: 0, val: 8, color: "#cbd5e1" },
  { id: "helifly", rarity: "uncommon", icon: "🐝", name: { ru: "Гелиевый светляк", en: "Helium Firefly" }, luck: 45, speed: 12, mut: 0.8, val: 12, color: "#5ddc5d" },
  { id: "craterturtle", rarity: "uncommon", icon: "🐢", name: { ru: "Кратерная черепашка", en: "Crateroid Turtle" }, luck: 55, speed: 15, mut: 1.0, val: 15, color: "#38bdf8" },
  { id: "selenefox", rarity: "rare", icon: "🦊", name: { ru: "Селеновый лис", en: "Selene Fox" }, luck: 130, speed: 25, mut: 2.0, val: 30, color: "#4aa8ff" },
  { id: "ymoonocto", rarity: "rare", icon: "🐙", name: { ru: "Орбитальный осьминог", en: "Orbital Octopus" }, luck: 155, speed: 30, mut: 2.5, val: 35, color: "#818cf8" },
  { id: "astrocat", rarity: "epic", icon: "🐱", name: { ru: "Астро-котик", en: "Astro Cat" }, luck: 360, speed: 45, mut: 4.5, val: 70, color: "#b46cff" },
  { id: "quantumray", rarity: "epic", icon: "🛸", name: { ru: "Квантовый скат", en: "Quantum Ray" }, luck: 420, speed: 55, mut: 5.5, val: 85, color: "#c084fc" },
  { id: "stardrake", rarity: "legendary", icon: "🐲", name: { ru: "Звёздный дракон", en: "Starlight Drake" }, luck: 950, speed: 80, mut: 9.0, val: 160, color: "#ffb02e" },
  { id: "eclipselion", rarity: "legendary", icon: "🦁", name: { ru: "Хранитель Затмения", en: "Eclipse Guardian" }, luck: 1150, speed: 95, mut: 11.0, val: 200, color: "#facc15" },
  { id: "nebulaphoenix", rarity: "mythic", icon: "🦅", name: { ru: "Небула-Феникс", en: "Nebula Phoenix" }, luck: 2800, speed: 135, mut: 18.0, val: 420, color: "#ff4d6d" },
  { id: "singularity", rarity: "secret", icon: "🌌", name: { ru: "Дух Сингулярности", en: "Singularity Spirit" }, luck: 7500, speed: 220, mut: 35.0, val: 1000, color: "#3dfcff" },
];
export const PET_MAP = Object.fromEntries(PETS.map((x) => [x.id, x]));

export const ROCKET_LAUNCH_COST = 1000000000; // 1 миллиард монет
export const EXCHANGE_RATE = 1000000; // 1 000 000 монет = 1 синий бриллиант

export const ISLANDS = [
  {
    id: "sunny", name: { ru: "Солнечная Бухта", en: "Sunny Cove" }, desc: { ru: "Тёплый песок, пальмы и спокойная вода. Идеально для новичков.", en: "Warm sand, palms and calm water. Perfect for beginners." },
    price: 0, mult: 1, icon: "🏝️", gradient: "linear-gradient(135deg,#3f9bff,#35d0d6 60%,#ecd59a)",
    theme: {
      skyTop: "#3f9bff", skyHorizon: "#c4ecff", fog: "#c4ecff", fogNear: 70, fogFar: 270, waterDeep: "#1565b0", waterShallow: "#35d0d6", foam: "#ffffff",
      sun: "#fff4dc", sunIntensity: 2.4, hemiSky: "#cfeaff", hemiGround: "#d8c08a", hemiIntensity: 1.3,
      sand: "#ecd59a", grass: "#6cc24a", rock: "#9a9a9a", wood: "#9a6a3a", leaf: "#3fae3f", leaf2: "#7ad04a", cloud: "#ffffff",
      weather: "none", stars: 0, waveAmp: 1, sunDir: [0.5, 0.75, 0.35],
    },
  },
  {
    id: "coral", name: { ru: "Коралловый Риф", en: "Coral Reef" }, desc: { ru: "Бирюзовая лагуна, полная ярких тропических рыб.", en: "A turquoise lagoon full of bright tropical fish." },
    price: 1000, mult: 3, icon: "🐠", gradient: "linear-gradient(135deg,#2fb0ff,#47f0d4 55%,#ff8ab0)",
    theme: {
      skyTop: "#2fb0ff", skyHorizon: "#d2f8ff", fog: "#d2f8ff", fogNear: 70, fogFar: 270, waterDeep: "#0b89b0", waterShallow: "#47f0d4", foam: "#ffffff",
      sun: "#fff8e8", sunIntensity: 2.4, hemiSky: "#d6f6ff", hemiGround: "#f0d6b0", hemiIntensity: 1.3,
      sand: "#f5e2b8", grass: "#8ad65a", rock: "#c8a888", wood: "#a8743a", leaf: "#2fbf6a", leaf2: "#8ae05a", cloud: "#ffffff",
      weather: "none", stars: 0, waveAmp: 0.9, sunDir: [-0.4, 0.8, 0.4],
    },
  },
  {
    id: "frost", name: { ru: "Ледяной Фьорд", en: "Frost Fjord" }, desc: { ru: "Снег, айсберги и холодные глубины с северными рыбами.", en: "Snow, icebergs and cold depths full of northern fish." },
    price: 7500, mult: 8, icon: "🧊", gradient: "linear-gradient(135deg,#6a8fbf,#dbe6f2 55%,#5d9ec4)",
    theme: {
      skyTop: "#6a8fbf", skyHorizon: "#e2ecf6", fog: "#dbe6f2", fogNear: 45, fogFar: 230, waterDeep: "#183f63", waterShallow: "#5d9ec4", foam: "#f4fbff",
      sun: "#eaf2ff", sunIntensity: 2.0, hemiSky: "#e6f0ff", hemiGround: "#9ab0c8", hemiIntensity: 1.4,
      sand: "#d8e2ea", grass: "#f4f8fc", rock: "#7a8a9a", wood: "#6a4a3a", leaf: "#2a5a4a", leaf2: "#3a6a5a", cloud: "#eef3f8",
      weather: "snow", stars: 0, waveAmp: 0.8, sunDir: [0.4, 0.5, 0.55],
    },
  },
  {
    id: "volcano", name: { ru: "Пепельный Вулкан", en: "Ash Volcano" }, desc: { ru: "Горячие воды у подножия вулкана. Огненные рыбы и пепел.", en: "Hot waters by the volcano. Fiery fish and falling ash." },
    price: 40000, mult: 20, icon: "🌋", gradient: "linear-gradient(135deg,#2a1420,#c8603a 55%,#ff9a3c)",
    theme: {
      skyTop: "#2a1420", skyHorizon: "#c8603a", fog: "#7a3a2e", fogNear: 40, fogFar: 210, waterDeep: "#1e1216", waterShallow: "#6a2e22", foam: "#ffb080",
      sun: "#ffb070", sunIntensity: 2.0, hemiSky: "#ff9a6a", hemiGround: "#3a2020", hemiIntensity: 1.15,
      sand: "#3a3434", grass: "#4a3c38", rock: "#2a2424", wood: "#2a1e1a", leaf: "#4a2a1a", leaf2: "#6a3a1a", cloud: "#5a4a4a",
      weather: "embers", stars: 0, waveAmp: 0.9, sunDir: [-0.5, 0.45, -0.3],
    },
  },
  {
    id: "abyss", name: { ru: "Мистическая Бездна", en: "Mystic Abyss" }, desc: { ru: "Вечная ночь, светящиеся кристаллы и древние тайны глубин.", en: "Eternal night, glowing crystals and ancient secrets of the deep." },
    price: 200000, mult: 50, icon: "🔮", gradient: "linear-gradient(135deg,#120a33,#6a4ac0 55%,#3affd0)",
    theme: {
      skyTop: "#120a33", skyHorizon: "#6a4ac0", fog: "#3e2c7a", fogNear: 40, fogFar: 220, waterDeep: "#0c0930", waterShallow: "#5a3fd0", foam: "#c8b8ff",
      sun: "#c8b0ff", sunIntensity: 1.7, hemiSky: "#8a6aff", hemiGround: "#1a1040", hemiIntensity: 1.25,
      sand: "#5a4a7a", grass: "#3a8a8a", rock: "#3a3060", wood: "#4a3a5a", leaf: "#7a3aff", leaf2: "#3affd0", cloud: "#6a5aa0",
      weather: "fireflies", stars: 1, waveAmp: 0.7, sunDir: [0.3, 0.6, -0.5],
    },
  },
  {
    id: "sunken", name: { ru: "Затонувший Город", en: "Sunken City" }, desc: { ru: "Колонны древнего города торчат из зелёной воды. Кто-то там ещё живёт...", en: "Columns of an ancient city rise from green water. Something still lives there..." },
    price: 600000, mult: 120, icon: "🏛️", gradient: "linear-gradient(135deg,#1d5a52,#49b89a 55%,#e8e0c0)",
    theme: {
      skyTop: "#2a6a72", skyHorizon: "#bfe8da", fog: "#9fd8c6", fogNear: 50, fogFar: 230, waterDeep: "#0d4a44", waterShallow: "#49b89a", foam: "#e8fff4",
      sun: "#f2ffe8", sunIntensity: 2.1, hemiSky: "#cdf0e2", hemiGround: "#8a9a7a", hemiIntensity: 1.3,
      sand: "#d8d0ac", grass: "#6a9a62", rock: "#a8a48c", wood: "#6a6a5a", leaf: "#2f8a5a", leaf2: "#7ac46a", cloud: "#eaf6ee",
      weather: "bubbles", stars: 0, waveAmp: 0.85, sunDir: [0.45, 0.65, 0.4],
    },
  },
  {
    id: "storm", name: { ru: "Грозовой Архипелаг", en: "Storm Archipelago" }, desc: { ru: "Вечная гроза, чёрные волны и рыба, пахнущая молнией.", en: "Endless thunderstorm, black waves and fish that smell of lightning." },
    price: 2500000, mult: 300, icon: "⚡", gradient: "linear-gradient(135deg,#1a2238,#4a5f86 55%,#ffe14d)",
    theme: {
      skyTop: "#161e34", skyHorizon: "#5a6b8e", fog: "#3e4a68", fogNear: 35, fogFar: 195, waterDeep: "#0b1026", waterShallow: "#2e4a7a", foam: "#cfe0ff",
      sun: "#cfe0ff", sunIntensity: 1.7, hemiSky: "#7a8ab0", hemiGround: "#1a2030", hemiIntensity: 1.2,
      sand: "#4a5060", grass: "#44604f", rock: "#3a4252", wood: "#3a3a44", leaf: "#2a5a46", leaf2: "#3a7a5a", cloud: "#4a5468",
      weather: "rain", stars: 0, waveAmp: 1.7, sunDir: [-0.45, 0.55, 0.4],
    },
  },
  {
    id: "celestial", name: { ru: "Небесное Озеро", en: "Celestial Lake" }, desc: { ru: "Озеро парит среди облаков. Здесь ловят созвездия.", en: "A lake floating among the clouds, where you fish for constellations." },
    price: 12000000, mult: 800, icon: "🌌", gradient: "linear-gradient(135deg,#2a1a5a,#8a6aff 50%,#ffd6a0)",
    theme: {
      skyTop: "#231a5e", skyHorizon: "#f0a9c0", fog: "#9a8ad0", fogNear: 55, fogFar: 260, waterDeep: "#2a1a6a", waterShallow: "#7a8aff", foam: "#ffeaf4",
      sun: "#ffd6a0", sunIntensity: 2.2, hemiSky: "#c6b0ff", hemiGround: "#4a3a7a", hemiIntensity: 1.35,
      sand: "#efe0f4", grass: "#b9a6f0", rock: "#8a7ab8", wood: "#6a5a8a", leaf: "#ff9ac8", leaf2: "#a6c8ff", cloud: "#ffd9ea",
      weather: "petals", stars: 0.7, waveAmp: 0.6, sunDir: [-0.35, 0.6, 0.55],
    },
  },
  {
    id: "spaceport", planet: 1, noFishing: true,
    name: { ru: "Космодром «Астра»", en: "Astra Spaceport" },
    desc: { ru: "Научная база и стартовая площадка. Рыбачить здесь нельзя, но ракета в центре доставит на Луну!", en: "Launch facility. No fishing here, but the center rocket flies to the Moon!" },
    price: 30000000, mult: 800, icon: "🚀", gradient: "linear-gradient(135deg,#0f172a,#334155 55%,#f97316)",
    theme: {
      skyTop: "#152c52", skyHorizon: "#7aa2c4", fog: "#6b8fb2", fogNear: 60, fogFar: 260, waterDeep: "#0e3c68", waterShallow: "#2876a8", foam: "#dceeff",
      sun: "#fff6e5", sunIntensity: 2.3, hemiSky: "#b8d8f8", hemiGround: "#64748b", hemiIntensity: 1.3,
      sand: "#64748b", grass: "#475569", rock: "#334155", wood: "#475569", leaf: "#38bdf8", leaf2: "#f97316", cloud: "#e2e8f0",
      weather: "embers", stars: 0.35, waveAmp: 0.75, sunDir: [0.45, 0.7, 0.35],
    },
  },
  {
    id: "lunar_crater", planet: 2,
    name: { ru: "Кратер Спокойствия", en: "Crater of Tranquility" },
    desc: { ru: "Первый остров на Луне! Лунный реголит, кратеры, научная база и рыба за синие бриллианты 💎.", en: "First island on the Moon! Lunar regolith, craters, science base and diamond fish 💎." },
    price: ROCKET_LAUNCH_COST, mult: 2500, icon: "🌕", gradient: "linear-gradient(135deg,#05070e,#334155 55%,#94a3b8)",
    theme: {
      skyTop: "#020308", skyHorizon: "#0b101d", fog: "#0b101d", fogNear: 65, fogFar: 280, waterDeep: "#091526", waterShallow: "#1e3a5f", foam: "#cbd5e1",
      sun: "#ffffff", sunIntensity: 2.45, hemiSky: "#cbd5e1", hemiGround: "#334155", hemiIntensity: 1.2,
      sand: "#64748b", grass: "#94a3b8", rock: "#475569", wood: "#64748b", leaf: "#94a3b8", leaf2: "#64748b", cloud: "#0b101d",
      weather: "none", stars: 1, waveAmp: 0.35, sunDir: [-0.5, 0.7, 0.4],
    },
  },
];
export const ISLAND_MAP = Object.fromEntries(ISLANDS.map((x) => [x.id, x]));

export const EVENTS = [
  { id: "storm", icon: "⛈️", duration: 100 },
  { id: "starfall", icon: "🌠", duration: 100 },
  { id: "frenzy", icon: "🐟", duration: 90 },
];

export const bagCapacity = (lvl) => 40 + lvl * 20;
export const BAG_MAX_LVL = 16;
export const bagUpgradeCost = (lvl) => Math.round((250 * Math.pow(2.1, lvl)) / 10) * 10;
export const LUCK_MAX_LVL = 20;
export const LUCK_PER_LVL = 4;
export const luckUpgradeCost = (lvl) => Math.round((400 * Math.pow(2.2, lvl)) / 10) * 10;
export const AUTO_PRICE = 25000;

export const MUT_MAX_LVL = 12;
export const MUT_PER_LVL = 0.4;
export const mutUpgradeCost = (lvl) => Math.round((5000 * Math.pow(2.3, lvl)) / 10) * 10;
export const PRICE_MAX_LVL = 12;
export const PRICE_PER_LVL = 5;
export const priceUpgradeCost = (lvl) => Math.round((8000 * Math.pow(2.35, lvl)) / 10) * 10;
export const CTRL_MAX_LVL = 12;
export const CTRL_PER_LVL = 3;
export const ctrlUpgradeCost = (lvl) => Math.round((6000 * Math.pow(2.3, lvl)) / 10) * 10;
export const SPD_MAX_LVL = 12;
export const SPD_PER_LVL = 6;
export const spdUpgradeCost = (lvl) => Math.round((4000 * Math.pow(2.25, lvl)) / 10) * 10;

// Лунные технологии (за синие бриллианты 💎)
export const LU_SUIT_MAX = 15;
export const LU_SUIT_PER = 6; // +контроль
export const luSuitCost = (lvl) => Math.round(15 * Math.pow(1.9, lvl));
export const LU_SCAN_MAX = 20;
export const LU_SCAN_PER = 40; // +% удачи
export const luScanCost = (lvl) => Math.round(20 * Math.pow(1.95, lvl));
export const LU_EXTR_MAX = 15;
export const LU_EXTR_PER = 12; // +% цена продажи (🪙 и 💎)
export const luExtrCost = (lvl) => Math.round(25 * Math.pow(2.0, lvl));
export const LU_MUT_MAX = 15;
export const LU_MUT_PER = 1.2; // +% шанс мутации
export const luMutCost = (lvl) => Math.round(30 * Math.pow(2.05, lvl));
export const LU_INC_MAX = 10;
export const LU_INC_PER = 25; // +% удача яиц питомцев
export const luIncCost = (lvl) => Math.round(40 * Math.pow(2.1, lvl));

export const isFishLunar = (defOrId) => {
  const def = typeof defOrId === "string" ? FISH_MAP[defOrId] : defOrId;
  return !!(def && (def.dia || (ISLAND_MAP[def.island]?.planet ?? 1) === 2));
};

export function fishPrice(def, w, mut) {
  const span = Math.max(0.0001, def.maxW - def.minW);
  const wn = Math.min(1, Math.max(0, (w - def.minW) / span));
  const m = mut ? MUTATION[mut]?.mult ?? 1 : 1;
  return Math.max(1, Math.round(def.price * (0.7 + 0.8 * wn) * m));
}

export function fishDisplayLength(w) {
  return Math.min(2.6, Math.max(0.55, 0.5 + Math.log10(1 + w) * 0.5));
}

const mtof = (m) => 440 * Math.pow(2, (m - 69) / 12);

class AudioEngine {
  constructor() {
    this.ctx = null;
    this.soundOn = true;
    this.musicOn = true;
    this.paused = false;
    this.step = 0;
    this.nextTime = 0;
    this.timer = null;
  }

  init() {
    if (this.paused) return;
    if (this.ctx) {
      if (this.ctx.state !== "running") void this.ctx.resume().catch(() => {});
      return;
    }
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    const ctx = new AC();
    this.ctx = ctx;
    this.master = ctx.createGain();
    this.master.gain.value = 0.9;
    this.master.connect(ctx.destination);
    this.sfxBus = ctx.createGain();
    this.sfxBus.connect(this.master);
    this.musicBus = ctx.createGain();
    this.musicBus.connect(this.master);
    this.ambBus = ctx.createGain();
    this.ambBus.connect(this.master);

    const len = ctx.sampleRate * 2;
    this.noise = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = this.noise.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;

    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    src.loop = true;
    const lp = ctx.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = 480;
    const ambGain = ctx.createGain();
    ambGain.gain.value = 0.55;
    src.connect(lp).connect(ambGain).connect(this.ambBus);
    const lfo = ctx.createOscillator();
    lfo.frequency.value = 0.11;
    this.lfoDepth = ctx.createGain();
    this.lfoDepth.gain.value = 0.35;
    lfo.connect(this.lfoDepth).connect(ambGain.gain);
    src.start();
    lfo.start();

    this.nextTime = ctx.currentTime + 0.2;
    this.timer = window.setInterval(() => this.schedule(), 90);
    this.apply();
    if (this.paused) void ctx.suspend().catch(() => {});
    else void ctx.resume().catch(() => {});
  }

  setSound(on) {
    this.soundOn = on;
    this.apply();
  }
  setMusic(on) {
    this.musicOn = on;
    this.apply();
  }
  setPaused(p) {
    this.paused = p;
    if (!this.ctx) return;
    if (p) {
      this.master.gain.setTargetAtTime(0, this.ctx.currentTime, 0.015);
      void this.ctx.suspend().catch(() => {});
    } else {
      void this.ctx.resume().catch(() => {});
      this.master.gain.setTargetAtTime(0.9, this.ctx.currentTime, 0.04);
      this.apply();
    }
  }

  apply() {
    if (!this.ctx) return;
    const t0 = this.ctx.currentTime;
    this.sfxBus.gain.setTargetAtTime(this.soundOn && !this.paused ? 0.9 : 0, t0, 0.04);
    this.ambBus.gain.setTargetAtTime(this.soundOn && !this.paused ? 0.16 : 0, t0, 0.15);
    this.musicBus.gain.setTargetAtTime(this.musicOn && !this.paused ? 0.17 : 0, t0, 0.15);
  }

  tone(freq, dur, type = "sine", vol = 0.3, when = 0, slideTo, bus) {
    const ctx = this.ctx;
    if (!ctx || this.paused) return;
    const t0 = ctx.currentTime + when;
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = type;
    o.frequency.setValueAtTime(freq, t0);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g).connect(bus ?? this.sfxBus);
    o.start(t0);
    o.stop(t0 + dur + 0.05);
  }

  noiseBurst(dur, freq, q, vol, type, when = 0, sweepTo) {
    const ctx = this.ctx;
    if (!ctx || this.paused) return;
    const t0 = ctx.currentTime + when;
    const src = ctx.createBufferSource();
    src.buffer = this.noise;
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(freq, t0);
    if (sweepTo) f.frequency.exponentialRampToValueAtTime(sweepTo, t0 + dur);
    f.Q.value = q;
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(vol, t0 + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(f).connect(g).connect(this.sfxBus);
    src.start(t0, Math.random() * 1.4);
    src.stop(t0 + dur + 0.05);
  }

  play(s) {
    if (!this.ctx || !this.soundOn || this.paused) return;
    switch (s) {
      case "cast": this.noiseBurst(0.38, 500, 1.4, 0.35, "bandpass", 0, 2800); break;
      case "whoosh": this.noiseBurst(0.9, 260, 0.9, 0.3, "bandpass", 0, 1900); break;
      case "splash":
        this.noiseBurst(0.5, 2200, 0.7, 0.42, "lowpass", 0, 280);
        this.tone(240, 0.2, "sine", 0.22, 0, 90);
        break;
      case "nibble": this.tone(720, 0.06, "sine", 0.1, 0, 520); break;
      case "bite":
        this.tone(880, 0.08, "square", 0.09);
        this.tone(1320, 0.12, "square", 0.09, 0.08);
        this.noiseBurst(0.3, 1600, 0.7, 0.3, "lowpass", 0, 300);
        break;
      case "charge": this.tone(300, 0.08, "triangle", 0.05, 0, 340); break;
      case "hit": this.tone(660, 0.11, "triangle", 0.24, 0, 990); break;
      case "perfect":
        this.tone(880, 0.1, "triangle", 0.22);
        this.tone(1175, 0.1, "triangle", 0.22, 0.06);
        this.tone(1568, 0.22, "triangle", 0.22, 0.12);
        break;
      case "miss": this.tone(220, 0.2, "sawtooth", 0.1, 0, 110); break;
      case "catch": [523, 659, 784, 1047].forEach((f, i) => this.tone(f, 0.22, "triangle", 0.2, i * 0.08)); break;
      case "rare":
        [784, 988, 1175, 1568, 1976].forEach((f, i) => this.tone(f, 0.35, "triangle", 0.18, i * 0.085));
        [1568, 2093, 2637].forEach((f, i) => this.tone(f, 1.1, "sine", 0.08, 0.45 + i * 0.12));
        break;
      case "escape":
        this.tone(500, 0.25, "triangle", 0.18, 0, 250);
        this.tone(330, 0.32, "triangle", 0.18, 0.2, 140);
        break;
      case "coin":
        this.tone(1320, 0.07, "square", 0.08);
        this.tone(1760, 0.2, "square", 0.08, 0.07);
        break;
      case "click": this.tone(950, 0.04, "triangle", 0.12); break;
      case "buy":
        this.tone(1320, 0.07, "square", 0.07);
        this.tone(1760, 0.18, "square", 0.07, 0.07);
        this.tone(523, 0.35, "triangle", 0.15, 0.12);
        this.tone(784, 0.35, "triangle", 0.15, 0.12);
        this.tone(1047, 0.4, "triangle", 0.12, 0.2);
        break;
      case "error": this.tone(170, 0.2, "square", 0.08, 0, 120); break;
      case "quest": [523, 659, 784, 1047, 1319].forEach((f, i) => this.tone(f, 0.25, "triangle", 0.18, i * 0.07)); break;
    }
  }

  schedule() {
    const ctx = this.ctx;
    if (!ctx || this.paused) return;
    const eighth = 60 / 96 / 2;
    if (this.nextTime < ctx.currentTime - 1) this.nextTime = ctx.currentTime + 0.05;
    while (this.nextTime < ctx.currentTime + 0.3) {
      if (this.musicOn) this.musicStep(this.step, this.nextTime - ctx.currentTime);
      this.nextTime += eighth;
      this.step++;
    }
  }

  musicStep(step, when) {
    const chords = [
      [60, 64, 67],
      [67, 71, 74],
      [69, 72, 76],
      [65, 69, 72],
    ];
    const bar = Math.floor(step / 8);
    const s = step % 8;
    const chord = chords[bar % 4];
    const patterns = [
      [1, 0, 1, 1, 0, 1, 0, 1],
      [1, 1, 0, 1, 0, 1, 1, 0],
      [1, 0, 0, 1, 1, 0, 1, 0],
    ];
    const pat = patterns[Math.floor(bar / 4) % 3];
    if (s === 0 || s === 4) this.tone(mtof(chord[0] - 24), 0.5, "sine", 0.22, when, undefined, this.musicBus);
    if (pat[s]) {
      const idx = (s * 2 + bar) % 3;
      const oct = (s + bar) % 5 === 0 ? 24 : 12;
      const f = mtof(chord[idx] + oct - 12);
      this.tone(f, 0.32, "sine", 0.16, when, undefined, this.musicBus);
      this.tone(f * 2, 0.12, "triangle", 0.04, when, undefined, this.musicBus);
    }
  }
}

export const audio = new AudioEngine();
export function vibrate(ms) {
  try {
    navigator.vibrate?.(ms);
  } catch {
    /* ignore */
  }
}

const defaultPersist = () => ({
  coins: 0,
  diamonds: 0,
  rodsOwned: ["bamboo"],
  rod: "bamboo",
  baitsOwned: ["worm"],
  bait: "worm",
  islands: ["sunny"],
  island: "sunny",
  bag: [],
  bagLevel: 0,
  luckLevel: 0,
  mutLevel: 0,
  priceLevel: 0,
  ctrlLevel: 0,
  spdLevel: 0,
  luSuitLevel: 0,
  luScanLevel: 0,
  luExtrLevel: 0,
  luMutLevel: 0,
  luIncLevel: 0,
  petsOwned: [],
  petsEquipped: [],
  autoOwned: false,
  vipLuck: false,
  freeEggAt: 0,
  daily: { lastDay: null, streak: 0 },
  pendingReceipts: [],
  collection: {},
  quests: [],
  questSeq: 0,
  stats: { caught: 0, earned: 0, perfect: 0 },
  sound: true,
  music: true,
  lang: null,
  luckUntil: 0,
  autoUntil: 0,
  x2At: 0,
  coinsAt: 0,
  lowGfx: false,
});

const PERSIST_KEYS = Object.keys(defaultPersist());

export const useGame = createStore({
  ...defaultPersist(),
  saveLoaded: false,
  engineReady: false,
  started: false,
  panel: null,
  shopTab: "rods",
  lunarTab: "gear",
  colTab: "sunny",
  toasts: [],
  catchInfo: null,
  hatchedPet: null,
  phase: "idle",
  nearNpc: null,
  autoOn: false,
  fade: false,
  adBusy: false,
  rewardAvailable: false,
  shopPurchased: false,
  rescue: null,
  products: null,
  paymentBusy: false,
  restoreFailed: false,
  cloudReady: false,
  cloudConflict: null,
  bannerShown: false,
  hidden: false,
  sdkPaused: false,
  event: null,
  now: Date.now(),
  isMobile: false,
  curLang: "ru",
  castLabel: null,
  inHotspot: false,
  authorized: false,
});

const S = () => useGame.getState();
const set = useGame.setState;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function completedIslands(s = S()) {
  return ISLANDS.filter((isl) => !isl.noFishing && FISH.filter((f) => f.island === isl.id).every((f) => !!s.collection[f.id])).map((i) => i.id);
}

export function highestMult(s = S()) {
  let m = 1;
  for (const id of s.islands) m = Math.max(m, ISLAND_MAP[id]?.mult ?? 1);
  return m;
}

export function getPetBonuses(s = S()) {
  let luck = 0, speed = 0, mut = 0, val = 0;
  const eq = new Set(s.petsEquipped || []);
  for (const p of s.petsOwned || []) {
    if (!eq.has(p.uid)) continue;
    const def = PET_MAP[p.id];
    if (!def) continue;
    luck += def.luck;
    speed += def.speed;
    mut += def.mut;
    val += def.val;
  }
  return { luck, speed, mut, val };
}

export function getMods(s = S(), now = Date.now()) {
  const rod = ROD_MAP[s.rod] ?? RODS[0];
  const bait = BAIT_MAP[s.bait] ?? BAITS[0];
  const pet = getPetBonuses(s);
  const colBonus = completedIslands(s).length * 10;
  const luckPct = rod.luck + bait.luck + s.luckLevel * LUCK_PER_LVL + (s.luScanLevel || 0) * LU_SCAN_PER + pet.luck + colBonus;
  const luckBoost = s.luckUntil > now;
  const ev = s.event && s.event.until > now ? s.event.id : null;
  const luckMult = (1 + luckPct / 100) * (luckBoost ? 2 : 1) * (s.vipLuck ? 2 : 1) * (ev === "storm" ? 1.5 : 1);
  const speedMult = (1 + (rod.speed + bait.speed + s.spdLevel * SPD_PER_LVL + pet.speed) / 100) * (ev === "frenzy" ? 2 : 1);
  const mutChance = Math.min(0.85, ((3 + bait.mut + s.mutLevel * MUT_PER_LVL + (s.luMutLevel || 0) * LU_MUT_PER + pet.mut) / 100) * (ev === "starfall" ? 3 : 1));
  const control = rod.control + s.ctrlLevel * CTRL_PER_LVL + (s.luSuitLevel || 0) * LU_SUIT_PER;
  const priceMult = 1 + (s.priceLevel * PRICE_PER_LVL + (s.luExtrLevel || 0) * LU_EXTR_PER + pet.val) / 100;
  return { rod, bait, pet, luckPct, luckMult, speedMult, control, mutChance, priceMult, luckBoost, ev, colBonus };
}

export const sellValue = (p, s = S()) => {
  const pet = getPetBonuses(s);
  return Math.max(1, Math.round(p * (1 + (s.priceLevel * PRICE_PER_LVL + (s.luExtrLevel || 0) * LU_EXTR_PER + pet.val) / 100)));
};
export const autoAvailable = (s = S()) => s.autoOwned || s.autoUntil > Date.now();
export const isBagFull = (s = S()) => s.bag.length >= bagCapacity(s.bagLevel);
export const coinReward = (s = S()) => 300 * highestMult(s);

let toastId = 1;
export function toast(text, color) {
  const id = toastId++;
  set((s) => ({ toasts: [...s.toasts.slice(-3), { id, text, color }] }));
  setTimeout(() => set((s) => ({ toasts: s.toasts.filter((x) => x.id !== id) })), 2300);
}

const niceRound = (n) => {
  const p = Math.pow(10, Math.max(0, Math.floor(Math.log10(Math.max(1, n))) - 1));
  return Math.round(n / p) * p;
};

function genQuest(s, existing) {
  const mult = highestMult(s);
  const lvl = s.islands.length;
  const all = ["catch", "rarity", "sell", "perfect", "mutation", "island"];
  const used = new Set(existing.map((q) => q.type));
  const pool = all.filter((x) => !used.has(x));
  const type = pool[Math.floor(Math.random() * pool.length)] ?? "catch";
  const r = Math.random();
  switch (type) {
    case "catch": {
      const n = 10 + 5 * Math.floor(r * 4);
      return { type, target: n, progress: 0, reward: niceRound(n * 8 * mult) };
    }
    case "rarity": {
      const rar = lvl >= 7 ? "legendary" : lvl >= 5 ? "epic" : "rare";
      const n = rar === "rare" ? 2 + Math.floor(r * 3) : 1 + Math.floor(r * 2);
      const per = rar === "legendary" ? 1400 : rar === "epic" ? 420 : 140;
      return { type, target: n, progress: 0, reward: niceRound(n * per * mult), param: rar };
    }
    case "sell": {
      const n = niceRound(500 * mult * (1 + r));
      return { type, target: n, progress: 0, reward: niceRound(n * 0.35) };
    }
    case "perfect": {
      const n = 3 + Math.floor(r * 4);
      return { type, target: n, progress: 0, reward: niceRound(n * 55 * mult) };
    }
    case "mutation":
      return { type, target: 1, progress: 0, reward: niceRound(650 * mult) };
    case "island": {
      const fishable = s.islands.filter((id) => !ISLAND_MAP[id]?.noFishing);
      const id = !ISLAND_MAP[s.island]?.noFishing ? s.island : (fishable[fishable.length - 1] ?? "sunny");
      const n = 8 + 4 * Math.floor(r * 3);
      return { type, target: n, progress: 0, reward: niceRound(n * 11 * (ISLAND_MAP[id]?.mult ?? 1)), param: id };
    }
  }
}

function ensureQuests() {
  const s = S();
  const qs = [...s.quests];
  while (qs.length < 3) qs.push(genQuest(s, qs));
  if (qs.length !== s.quests.length) set({ quests: qs });
}

function questProgress(match) {
  const s = S();
  let changed = false;
  let completed = false;
  const qs = s.quests.map((q) => {
    if (q.done) return q;
    const add = match(q);
    if (!add) return q;
    changed = true;
    const progress = Math.min(q.target, q.progress + add);
    const done = progress >= q.target;
    if (done) completed = true;
    return { ...q, progress, done };
  });
  if (changed) set({ quests: qs });
  if (completed) {
    toast("📜 " + t("questDone"), "#ffe066");
    audio.play("quest");
  }
}

export function claimQuest(i, multiplier = 1, expected = S().quests[i]) {
  const s = S();
  const q = s.quests[i];
  if (!q || !q.done || q !== expected) return;
  const reward = q.reward * multiplier;
  const rest = s.quests.filter((_, k) => k !== i);
  const nq = genQuest(s, rest);
  const qs = [...s.quests];
  qs[i] = nq;
  set({ coins: s.coins + reward, quests: qs, questSeq: s.questSeq + 1 });
  audio.play("buy");
  toast(`+${fmtNum(reward)} 🪙`, "#ffe066");
  flushSave(true);
}

async function claimQuestDouble(i, quest) {
  if (!quest?.done || S().quests[i] !== quest) return;
  if (await askRewarded()) claimQuest(i, 2, quest);
}

export function addCatch(def, w, m) {
  const s = S();
  const dia = isFishLunar(def);
  const item = { uid: Math.random().toString(36).slice(2, 10), id: def.id, w: Math.round(w * 100) / 100, m, p: fishPrice(def, w, m), dia };
  const prev = s.collection[def.id];
  const isNew = !prev;
  const entry = prev ? { n: prev.n + 1, best: Math.max(prev.best, item.w), muts: [...prev.muts] } : { n: 1, best: item.w, muts: [] };
  if (m && !entry.muts.includes(m)) entry.muts.push(m);
  set({
    bag: [item, ...s.bag],
    collection: { ...s.collection, [def.id]: entry },
    stats: { ...s.stats, caught: s.stats.caught + 1 },
  });
  const rIdx = RARITY[def.rarity].idx;
  questProgress((q) => {
    if (q.type === "catch") return 1;
    if (q.type === "rarity" && q.param && rIdx >= RARITY[q.param].idx) return 1;
    if (q.type === "mutation" && m) return 1;
    if (q.type === "island" && q.param === def.island) return 1;
    return 0;
  });
  flushSave(true);
  return { item, isNew };
}

export function notePerfectCast() {
  const s = S();
  set({ stats: { ...s.stats, perfect: s.stats.perfect + 1 } });
  questProgress((q) => (q.type === "perfect" ? 1 : 0));
}

export function sellAll(mult = 1) {
  const s = S();
  const sellable = s.bag.filter((f) => !f.fav);
  if (!sellable.length) {
    toast(t("nothingToSell"));
    audio.play("error");
    return 0;
  }
  let totalCoins = 0;
  let totalDias = 0;
  for (const f of sellable) {
    const v = Math.round(sellValue(f.p, s) * mult);
    if (f.dia || isFishLunar(f.id)) totalDias += v;
    else totalCoins += v;
  }
  set({
    bag: s.bag.filter((f) => f.fav),
    coins: s.coins + totalCoins,
    diamonds: (s.diamonds || 0) + totalDias,
    stats: { ...s.stats, earned: s.stats.earned + totalCoins + totalDias * EXCHANGE_RATE },
  });
  questProgress((q) => (q.type === "sell" ? totalCoins + totalDias * EXCHANGE_RATE : 0));
  audio.play("coin");
  const parts = [];
  if (totalCoins > 0) parts.push(`${fmtNum(totalCoins)} 🪙`);
  if (totalDias > 0) parts.push(`${fmtNum(totalDias)} 💎`);
  toast("💰 " + t("sold", { n: parts.join(" + ") }), totalDias > 0 ? "#38bdf8" : "#ffe066");
  flushSave(true);
  return totalCoins + totalDias;
}

export function sellOne(uid) {
  const s = S();
  const f = s.bag.find((x) => x.uid === uid);
  if (!f) return;
  const v = sellValue(f.p, s);
  const isDia = !!(f.dia || isFishLunar(f.id));
  set({
    bag: s.bag.filter((x) => x.uid !== uid),
    coins: isDia ? s.coins : s.coins + v,
    diamonds: isDia ? (s.diamonds || 0) + v : (s.diamonds || 0),
    stats: { ...s.stats, earned: s.stats.earned + (isDia ? v * EXCHANGE_RATE : v) },
  });
  questProgress((q) => (q.type === "sell" ? (isDia ? v * EXCHANGE_RATE : v) : 0));
  audio.play("coin");
  flushSave(true);
}

export function toggleFav(uid) {
  set((s) => ({ bag: s.bag.map((x) => (x.uid === uid ? { ...x, fav: !x.fav } : x)) }));
  audio.play("click");
  flushSave(false);
}

function spend(n) {
  const s = S();
  if (s.coins < n) {
    toast(t("notEnough"), "#ff8a8a");
    audio.play("error");
    return false;
  }
  set({ coins: s.coins - n });
  return true;
}

function spendDiamonds(n) {
  const s = S();
  if ((s.diamonds || 0) < n) {
    toast(t("notEnoughDiamonds"), "#38bdf8");
    audio.play("error");
    return false;
  }
  set({ diamonds: (s.diamonds || 0) - n });
  return true;
}

export function exchangeCoinsToDiamonds(diaCount) {
  const count = Math.max(1, Math.floor(Number(diaCount) || 0));
  const cost = count * EXCHANGE_RATE;
  if (!spend(cost)) return false;
  set((s) => ({ diamonds: (s.diamonds || 0) + count }));
  audio.play("buy");
  toast(`💎 +${fmtNum(count)}`, "#38bdf8");
  flushSave(true);
  return true;
}

export function exchangeDiamondsToCoins(diaCount) {
  const count = Math.max(1, Math.floor(Number(diaCount) || 0));
  if (!spendDiamonds(count)) return false;
  const gain = count * EXCHANGE_RATE;
  set((s) => ({ coins: s.coins + gain }));
  audio.play("coin");
  toast(`🪙 +${fmtNum(gain)}`, "#ffe066");
  flushSave(true);
  return true;
}

export function buyOrEquipRod(id) {
  const s = S();
  const rod = ROD_MAP[id];
  if (!rod) return;
  if (s.rodsOwned.includes(id)) {
    set({ rod: id });
    audio.play("click");
    flushSave(true);
    return;
  }
  if (rod.lunar ? !spendDiamonds(rod.price) : !spend(rod.price)) return;
  set({ rodsOwned: [...S().rodsOwned, id], rod: id });
  markShopPurchase();
  audio.play("buy");
  toast("🎣 " + t("bought"), rod.lunar ? "#38bdf8" : "#7ef07e");
  flushSave(true);
}

export function buyOrEquipBait(id) {
  const s = S();
  const b = BAIT_MAP[id];
  if (!b) return;
  if (s.baitsOwned.includes(id)) {
    set({ bait: id });
    audio.play("click");
    flushSave(true);
    return;
  }
  if (b.lunar ? !spendDiamonds(b.price) : !spend(b.price)) return;
  set({ baitsOwned: [...S().baitsOwned, id], bait: id });
  markShopPurchase();
  audio.play("buy");
  toast(b.icon + " " + t("bought"), b.lunar ? "#38bdf8" : "#7ef07e");
  flushSave(true);
}

export function upgradeBag() {
  const s = S();
  if (s.bagLevel >= BAG_MAX_LVL) return;
  if (!spend(bagUpgradeCost(s.bagLevel))) return;
  set({ bagLevel: S().bagLevel + 1 });
  markShopPurchase();
  audio.play("buy");
  flushSave(true);
}

export function upgradeLuck() {
  const s = S();
  if (s.luckLevel >= LUCK_MAX_LVL) return;
  if (!spend(luckUpgradeCost(s.luckLevel))) return;
  set({ luckLevel: S().luckLevel + 1 });
  markShopPurchase();
  audio.play("buy");
  flushSave(true);
}

const UPGRADES = {
  mut: { key: "mutLevel", max: MUT_MAX_LVL, cost: mutUpgradeCost },
  price: { key: "priceLevel", max: PRICE_MAX_LVL, cost: priceUpgradeCost },
  ctrl: { key: "ctrlLevel", max: CTRL_MAX_LVL, cost: ctrlUpgradeCost },
  spd: { key: "spdLevel", max: SPD_MAX_LVL, cost: spdUpgradeCost },
};

export function upgradeStat(id) {
  const u = UPGRADES[id];
  const lvl = S()[u.key];
  if (lvl >= u.max) return;
  if (!spend(u.cost(lvl))) return;
  set({ [u.key]: S()[u.key] + 1 });
  markShopPurchase();
  audio.play("buy");
  flushSave(true);
}

const LUNAR_UPGRADES = {
  suit: { key: "luSuitLevel", max: LU_SUIT_MAX, cost: luSuitCost },
  scan: { key: "luScanLevel", max: LU_SCAN_MAX, cost: luScanCost },
  extr: { key: "luExtrLevel", max: LU_EXTR_MAX, cost: luExtrCost },
  mut: { key: "luMutLevel", max: LU_MUT_MAX, cost: luMutCost },
  inc: { key: "luIncLevel", max: LU_INC_MAX, cost: luIncCost },
};

export function upgradeLunarStat(id) {
  const u = LUNAR_UPGRADES[id];
  if (!u) return;
  const lvl = S()[u.key] || 0;
  if (lvl >= u.max) return;
  if (!spendDiamonds(u.cost(lvl))) return;
  set({ [u.key]: (S()[u.key] || 0) + 1 });
  markShopPurchase();
  audio.play("buy");
  flushSave(true);
}

// Расчёт весов редкости для питомцев (в ~2.5 раза сложнее выбить хорошую редкость, чем у рыбы, но удача также влияет)
export function getPetRarityWeights(s = S()) {
  const mods = getMods(s);
  const incBonus = 1 + ((s.luIncLevel || 0) * LU_INC_PER) / 100;
  // Эффективная удача для питомцев ослаблена в 2.5 раза относительно рыбалки
  const lm = Math.max(1, (1 + (mods.luckMult - 1) / 2.5) * incBonus);
  return RARITIES.map((r) => {
    if (r.idx === 0) return (r.weight * 1.45) / Math.pow(lm, 0.55);
    if (r.idx === 1) return (r.weight * 0.85) / Math.pow(lm, 0.15);
    return (r.weight / 2.5) * Math.pow(lm, r.boost * 0.62);
  });
}

export function hatchLunarEgg(free = false) {
  if (S().petsOwned.length >= PET_LIMIT) {
    toast(t("petLimit", { n: PET_LIMIT }), "#ff8a8a");
    return null;
  }
  if (free ? eggWait() > 0 : !spendDiamonds(EGG_PRICE)) return null;
  const s = S();
  const weights = getPetRarityWeights(s);
  let roll = Math.random() * weights.reduce((a, b) => a + b, 0);
  let idx = 0;
  for (; idx < weights.length - 1; idx++) {
    roll -= weights[idx];
    if (roll <= 0) break;
  }
  const rarId = RARITIES[idx].id;
  let pool = PETS.filter((p) => p.rarity === rarId);
  if (!pool.length) pool = PETS;
  const def = pool[Math.floor(Math.random() * pool.length)];
  const petItem = { uid: Math.random().toString(36).slice(2, 10), id: def.id };
  const owned = [petItem, ...(s.petsOwned || [])];
  const eq = [...(s.petsEquipped || [])];
  if (eq.length < PET_MAX_EQUIP) eq.push(petItem.uid);
  set({ petsOwned: owned, petsEquipped: eq, hatchedPet: { pet: petItem, key: Date.now() },
    ...(free ? { freeEggAt: YA.now() } : {}) });
  if (!free) markShopPurchase();
  audio.play(idx >= 3 ? "rare" : "catch");
  toast(`🥚 ${t("hatched")} ${def.icon} ${tr(def.name)}`, RARITY[def.rarity].color);
  flushSave(true);
  return petItem;
}

function eggWait(at = S().freeEggAt, now = YA.now()) {
  return at > 0 ? Math.max(0, at + EGG_COOLDOWN - now) : 0;
}

async function watchFreeEgg() {
  if (S().petsOwned.length >= PET_LIMIT || eggWait() > 0) return;
  if (await askRewarded()) hatchLunarEgg(true);
}

export function toggleEquipPet(uid) {
  const s = S();
  const eq = [...(s.petsEquipped || [])];
  const idx = eq.indexOf(uid);
  if (idx >= 0) {
    eq.splice(idx, 1);
  } else {
    if (eq.length >= PET_MAX_EQUIP) eq.shift();
    eq.push(uid);
  }
  set({ petsEquipped: eq });
  audio.play("click");
  flushSave(true);
}

export function deletePet(uid) {
  const s = S();
  set({
    petsOwned: (s.petsOwned || []).filter((p) => p.uid !== uid),
    petsEquipped: (s.petsEquipped || []).filter((id) => id !== uid),
  });
  audio.play("click");
  flushSave(true);
}

export function buyAuto() {
  if (S().autoOwned) return;
  if (!spend(AUTO_PRICE)) return;
  set({ autoOwned: true, autoOn: true });
  markShopPurchase();
  audio.play("buy");
  flushSave(true);
}

export async function showInterstitial() {
  if (!YA.canShowInterstitial() || S().adBusy || S().paymentBusy || S().hidden || S().sdkPaused || document.hidden) return;
  set({ adBusy: true });
  try {
    await YA.showInterstitial();
  } finally {
    set({ adBusy: false });
  }
}

export async function travelTo(id) {
  const s = S();
  if (s.fade || s.island === id) return;
  const isl = ISLAND_MAP[id];
  if (!isl) return;
  if (!s.islands.includes(id)) {
    if (!spend(isl.price)) return;
    set({ islands: [...S().islands, id] });
    audio.play("buy");
    flushSave(true);
  }
  set({ panel: null, fade: true, autoOn: false });
  audio.play("whoosh");
  await sleep(480);
  set({
    island: id,
    colTab: isl.noFishing ? S().colTab : id,
  });
  flushSave(true);
  await sleep(200);
  await showInterstitial();
  set({ fade: false });
}

export async function launchRocketToMoon() {
  const s = S();
  if (s.fade) return;
  if (!s.islands.includes("lunar_crater")) {
    if (!spend(ROCKET_LAUNCH_COST)) return;
  }
  const unlocked = s.islands.includes("lunar_crater") ? s.islands : [...s.islands, "lunar_crater"];
  set({ islands: unlocked, panel: null, fade: true, autoOn: false });
  audio.play("buy");
  audio.play("whoosh");
  toast("🚀 " + t("launchMoon"), "#38bdf8");
  await sleep(550);
  set({ island: "lunar_crater", colTab: "lunar_crater" });
  flushSave(true);
  await sleep(220);
  await showInterstitial();
  set({ fade: false });
}

async function askRewarded() {
  if (S().adBusy || S().paymentBusy || S().hidden || S().sdkPaused) return false;
  if (!YA.rewardedAvailable) {
    toast(t("adNotReady"), "#ff8a8a");
    return false;
  }
  set({ adBusy: true });
  try {
    const ok = await YA.showRewarded();
    if (!ok) toast(t("adNotReady"), "#ff8a8a");
    return ok;
  } finally { set({ adBusy: false }); }
}

export async function watchRewarded(kind) {
  if (!await askRewarded()) return false;
  const now = Date.now();
  const s = S();
  if (kind === "luck") {
    set({ luckUntil: Math.max(now, s.luckUntil) + 5 * 60000 });
    toast("🍀 " + t("rewardLuck"), "#7ef07e");
  } else if (kind === "auto") {
    set({ autoUntil: Math.max(now, s.autoUntil) + 10 * 60000, autoOn: true });
    toast("🤖 " + t("rewardAuto"), "#7ef07e");
  } else if (kind === "coins") {
    const n = coinReward(s);
    set({ coins: s.coins + n, coinsAt: now });
    toast("💰 " + t("rewardCoins", { n: fmtNum(n) }), "#ffe066");
  } else if (kind === "x2") {
    set({ x2At: now });
    sellAll(2);
  }
  audio.play("buy");
  flushSave(true);
  return true;
}

function markShopPurchase() {
  if (S().panel === "shop" || S().panel === "lunar") set({ shopPurchased: true });
}

export function openPanel(p, tab) {
  const s = S();
  if (s.adBusy || s.paymentBusy || s.phase === "rescue") return;
  if (p && (s.phase === "reeling" || s.phase === "bite" || s.phase === "charging" || s.catchInfo?.adBreak)) return;
  const shopExit = p !== s.panel && (s.panel === "shop" || s.panel === "lunar");
  if (shopExit && s.shopPurchased) {
    set({ shopPurchased: false });
    if (!p) {
      void showInterstitial().finally(() => set({ panel: null }));
      audio.play("click");
      return;
    }
  }
  set(tab ? { panel: p, shopTab: tab } : { panel: p });
  if (p === "shop" && s.products === null) void refreshPayments();
  audio.play("click");
}

const DAILY_REWARDS = [
  { coins: 250 }, { minutes: 5 }, { coins: 500 }, { minutes: 10 },
  { coins: 1000 }, { minutes: 15 }, { diamonds: 25 },
];

function calendarDay(now = YA.now()) {
  const date = new Date(now);
  return Math.floor(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()) / 86_400_000);
}

function dailyStatus(s = S(), today = calendarDay()) {
  const { lastDay, streak } = s.daily;
  if (lastDay !== null && today <= lastDay) return { available: false, day: streak };
  return { available: true, day: lastDay === today - 1 ? streak % 7 + 1 : 1 };
}

function claimDaily() {
  const today = calendarDay();
  const s = S();
  const { available, day } = dailyStatus(s, today);
  if (!available || s.adBusy || s.paymentBusy) return false;
  const reward = DAILY_REWARDS[day - 1];
  set({
    daily: { lastDay: today, streak: day },
    coins: s.coins + (reward.coins ?? 0) * highestMult(s),
    diamonds: s.diamonds + (reward.diamonds ?? 0),
    luckUntil: reward.minutes ? Math.max(Date.now(), s.luckUntil) + reward.minutes * 60_000 : s.luckUntil,
  });
  audio.play("buy");
  flushSave(true);
  return true;
}

export function setLanguage(l) {
  setLangInternal(l);
  set({ lang: l, curLang: l });
  flushSave(true);
}

export function toggleSound() {
  const v = !S().sound;
  set({ sound: v });
  audio.setSound(v);
  audio.play("click");
  flushSave(true);
}

export function toggleGfx() {
  set({ lowGfx: !S().lowGfx });
  audio.play("click");
  flushSave(true);
}

export function toggleMusic() {
  const v = !S().music;
  set({ music: v });
  audio.setMusic(v);
  audio.play("click");
  flushSave(true);
}

const SAVE_KEY = "klevy_ostrov_save_v1";

function snapshot() {
  const s = S();
  const out = { v: 1, savedAt: Date.now() };
  for (const k of PERSIST_KEYS) out[k] = s[k];
  return out;
}

const isArr = (v) => Array.isArray(v);
const num = (v, d) => (typeof v === "number" && isFinite(v) ? v : d);

function sanitize(raw) {
  const d = defaultPersist();
  const strArr = (v, valid, base) => {
    const arr = isArr(v) ? v.filter((x) => typeof x === "string" && valid(x)) : [];
    for (const b of base) if (!arr.includes(b)) arr.unshift(b);
    return arr;
  };
  const rodsOwned = strArr(raw.rodsOwned, (x) => !!ROD_MAP[x], d.rodsOwned);
  const baitsOwned = strArr(raw.baitsOwned, (x) => !!BAIT_MAP[x], d.baitsOwned);
  const islands = strArr(raw.islands, (x) => !!ISLAND_MAP[x], d.islands);
  const bag = isArr(raw.bag) ? raw.bag.filter((f) => f && typeof f === "object" && FISH_MAP[f.id] && typeof f.p === "number") : [];
  const collection = {};
  if (raw.collection && typeof raw.collection === "object") {
    for (const [k, v] of Object.entries(raw.collection)) {
      if (FISH_MAP[k] && v && typeof v.n === "number") collection[k] = { n: v.n, best: num(v.best, 0), muts: isArr(v.muts) ? v.muts : [] };
    }
  }
  const quests = isArr(raw.quests) ? raw.quests.filter((q) => q && typeof q.target === "number").slice(0, 3) : [];
  const st = raw.stats ?? {};
  const rod = typeof raw.rod === "string" && rodsOwned.includes(raw.rod) ? raw.rod : d.rod;
  const bait = typeof raw.bait === "string" && baitsOwned.includes(raw.bait) ? raw.bait : d.bait;
  const island = typeof raw.island === "string" && islands.includes(raw.island) ? raw.island : d.island;
  const petsOwned = isArr(raw.petsOwned)
    ? raw.petsOwned.filter((p) => p && typeof p === "object" && PET_MAP[p.id] && typeof p.uid === "string")
    : [];
  const ownedUids = new Set(petsOwned.map((p) => p.uid));
  const petsEquipped = isArr(raw.petsEquipped)
    ? raw.petsEquipped.filter((u) => typeof u === "string" && ownedUids.has(u)).slice(0, PET_MAX_EQUIP)
    : [];
  return {
    coins: Math.max(0, num(raw.coins, 0)),
    diamonds: Math.max(0, num(raw.diamonds, 0)),
    rodsOwned, rod, baitsOwned, bait, islands, island, bag, collection, quests,
    bagLevel: Math.min(BAG_MAX_LVL, Math.max(0, num(raw.bagLevel, 0))),
    luckLevel: Math.min(LUCK_MAX_LVL, Math.max(0, num(raw.luckLevel, 0))),
    mutLevel: Math.min(MUT_MAX_LVL, Math.max(0, num(raw.mutLevel, 0))),
    priceLevel: Math.min(PRICE_MAX_LVL, Math.max(0, num(raw.priceLevel, 0))),
    ctrlLevel: Math.min(CTRL_MAX_LVL, Math.max(0, num(raw.ctrlLevel, 0))),
    spdLevel: Math.min(SPD_MAX_LVL, Math.max(0, num(raw.spdLevel, 0))),
    luSuitLevel: Math.min(LU_SUIT_MAX, Math.max(0, num(raw.luSuitLevel, 0))),
    luScanLevel: Math.min(LU_SCAN_MAX, Math.max(0, num(raw.luScanLevel, 0))),
    luExtrLevel: Math.min(LU_EXTR_MAX, Math.max(0, num(raw.luExtrLevel, 0))),
    luMutLevel: Math.min(LU_MUT_MAX, Math.max(0, num(raw.luMutLevel, 0))),
    luIncLevel: Math.min(LU_INC_MAX, Math.max(0, num(raw.luIncLevel, 0))),
    petsOwned,
    petsEquipped,
    autoOwned: raw.autoOwned === true,
    vipLuck: raw.vipLuck === true,
    freeEggAt: Math.max(0, num(raw.freeEggAt, 0)),
    daily: Number.isInteger(raw.daily?.lastDay) && Number.isInteger(raw.daily?.streak) && raw.daily.streak >= 1 && raw.daily.streak <= 7
      ? { lastDay: raw.daily.lastDay, streak: raw.daily.streak } : d.daily,
    pendingReceipts: isArr(raw.pendingReceipts)
      ? [...new Set(raw.pendingReceipts.filter((token) => typeof token === "string" && token.length > 0))] : [],
    questSeq: num(raw.questSeq, 0),
    stats: { caught: num(st.caught, 0), earned: num(st.earned, 0), perfect: num(st.perfect, 0) },
    sound: raw.sound !== false,
    music: raw.music !== false,
    lang: raw.lang === "ru" || raw.lang === "en" ? raw.lang : null,
    luckUntil: num(raw.luckUntil, 0),
    autoUntil: num(raw.autoUntil, 0),
    x2At: num(raw.x2At, 0),
    coinsAt: num(raw.coinsAt, 0),
    lowGfx: raw.lowGfx === true,
  };
}

function persistLocal(snap = snapshot()) {
  try { localStorage.setItem(SAVE_KEY, JSON.stringify(snap)); }
  catch { /* Local storage can be unavailable in the iframe. */ }
  return snap;
}

const CONFLICT_KEY = SAVE_KEY + "_cloud_conflict";
function flagConflict(active) {
  try {
    if (active) localStorage.setItem(CONFLICT_KEY, "1");
    else localStorage.removeItem(CONFLICT_KEY);
  } catch { /* The in-memory conflict still blocks upload. */ }
}

function applySave(raw) {
  if (raw) {
    const clean = sanitize(raw);
    set({ ...clean, autoOn: false, colTab: ISLAND_MAP[clean.island]?.noFishing ? "sunny" : clean.island });
  }
  ensureQuests();
  const s = S();
  const lang = s.lang ?? detectLang(YA.lang());
  setLangInternal(lang);
  set({ curLang: lang });
  audio.setSound(s.sound);
  audio.setMusic(s.music);
}

let baseline;
let localSaveTime = 0;
let cloudSync;
let cloudQueue = Promise.resolve();
let cloudScheduled;
let lastCloud = 0;
let saveTimer;

function loadLocalSave() {
  let raw;
  try { raw = JSON.parse(localStorage.getItem(SAVE_KEY)); } catch { /* New player. */ }
  localSaveTime = num(raw?.savedAt, 0);
  applySave(raw);
  baseline = S();
}

function syncCloudSave() {
  if (!YA.available || S().cloudReady || S().cloudConflict) return Promise.resolve();
  return cloudSync ??= (async () => {
    try {
      const cloud = await YA.loadData();
      const changed = PERSIST_KEYS.some((key) => S()[key] !== baseline[key]);
      let flagged = false;
      try { flagged = localStorage.getItem(CONFLICT_KEY) === "1"; } catch { /* Ignore. */ }
      if (cloud && (flagged || num(cloud.savedAt, 0) > localSaveTime)) {
        if ((S().started && changed) || flagged) {
          flagConflict(true);
          set({ cloudConflict: cloud, authorized: YA.isAuthorized() });
          if (S().started && !S().paymentBusy) void refreshPayments();
          return;
        }
        applySave(cloud);
        persistLocal(cloud);
      }
      flagConflict(false);
      set({ cloudReady: true, authorized: YA.isAuthorized() });
      if (S().started && !S().paymentBusy) void refreshPayments();
    } catch (error) { console.warn("[YA] getData", error); }
  })().finally(() => { cloudSync = undefined; });
}

function useCloudProgress() {
  if (!S().cloudConflict || S().paymentBusy || S().adBusy) return;
  runtime.engine?.fishing.cancel();
  const cloud = S().cloudConflict;
  applySave(cloud);
  persistLocal(cloud);
  flagConflict(false);
  set({ cloudConflict: null, cloudReady: true });
  void refreshPayments();
}

function writeCloudNow() {
  const write = cloudQueue.then(async () => {
    if (!S().cloudReady) throw new Error("Cloud save is not ready");
    lastCloud = Date.now();
    await YA.saveData(snapshot(), true);
  });
  cloudQueue = write.catch((error) => console.warn("[YA] setData", error));
  return write;
}

export function flushSave(forceCloud = false) {
  if (!S().saveLoaded) return;
  persistLocal();
  if (!S().cloudReady || cloudScheduled) return;
  const minInterval = 5000;
  const wait = Math.max(0, minInterval - (Date.now() - lastCloud));
  cloudScheduled = setTimeout(() => {
    cloudScheduled = undefined;
    if (S().cloudReady) void writeCloudNow().catch(() => {});
  }, forceCloud ? wait : Math.max(wait, 600));
}

export function startAutoSave() {
  useGame.subscribe((s, prev) => {
    if (!s.saveLoaded || !PERSIST_KEYS.some((k) => s[k] !== prev[k])) return;
    clearTimeout(saveTimer);
    saveTimer = setTimeout(flushSave, 600);
  });
  setInterval(() => {
    if (YA.available && S().saveLoaded && !S().cloudReady && !S().cloudConflict && !S().paymentBusy) void syncCloudSave();
    flushSave();
  }, 20_000);
}

const PREMIUM_ITEMS = {
  vip_luck: { title: "vipLuckTitle", desc: "vipLuckDesc", icon: "🍀" },
  auto_forever: { title: "autoUpgrade", desc: "autoUpgradeDesc", icon: "🤖" },
  pack_starter: { title: "starterTitle", desc: "starterDesc", icon: "🎁", consumable: true },
  pack_diamonds: { title: "diamondsTitle", desc: "diamondsDesc", icon: "💎", consumable: true },
};
let payments;
let restoredPurchases = false;

async function boundedRead(read) {
  let timer;
  try {
    return await Promise.race([Promise.resolve().then(read), new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error("SDK read timed out")), 8000);
    })]);
  } finally { clearTimeout(timer); }
}

function ownsPremium(id, state = S()) {
  return id === "vip_luck" ? state.vipLuck : id === "auto_forever" ? state.autoOwned : false;
}

async function fulfillPurchase(purchase) {
  const id = purchase?.productID;
  if (!Object.hasOwn(PREMIUM_ITEMS, id)) return;
  const item = PREMIUM_ITEMS[id];
  if (!item.consumable) {
    if (!ownsPremium(id)) {
      set(id === "vip_luck" ? { vipLuck: true } : { autoOwned: true });
      persistLocal();
      await writeCloudNow();
    }
    return;
  }
  const token = purchase.purchaseToken;
  if (typeof token !== "string" || !token) throw new Error("Missing purchase token");
  const s = S();
  if (!s.pendingReceipts.includes(token)) {
    const grant = id === "pack_diamonds" ? { diamonds: s.diamonds + 250 } : {
      coins: s.coins + 5000 * highestMult(s),
      luckUntil: Math.max(Date.now(), s.luckUntil) + 15 * 60_000,
    };
    set({ ...grant, pendingReceipts: [...s.pendingReceipts, token] });
    persistLocal();
  }
  // The token and balances must be durable together before irreversible consumption.
  await writeCloudNow();
  await payments.consumePurchase(token);
  // Keep the receipt until an authoritative getPurchases confirms it is gone.
}

async function refreshPayments(retry = false) {
  const s = S();
  if (!YA.available || !s.started || s.paymentBusy || (restoredPurchases && s.products !== null && !retry)) return;
  set({ paymentBusy: true, restoreFailed: false });
  try {
    payments ??= await boundedRead(() => YA.getPayments());
    if (!payments) return;
    let catalog = S().products;
    if (catalog === null || retry) {
      try {
        catalog = (await boundedRead(() => payments.getCatalog())).filter((item) => Object.hasOwn(PREMIUM_ITEMS, item.id));
        set({ products: catalog });
      } catch (error) { console.warn("[YA] getCatalog", error); }
    }
    if (!S().cloudReady) return;
    const purchases = await boundedRead(() => payments.getPurchases());
    const outstanding = new Set(purchases.map((purchase) => purchase.purchaseToken));
    const current = S().pendingReceipts;
    const pending = current.filter((token) => outstanding.has(token));
    if (pending.length !== current.length) {
      set({ pendingReceipts: pending });
      persistLocal();
    }
    let hasFailures = false;
    for (const purchase of purchases) {
      try { await fulfillPurchase(purchase); }
      catch (error) { hasFailures = true; console.warn("[YA] fulfill purchase", error); }
    }
    restoredPurchases = !hasFailures;
    set({ restoreFailed: hasFailures });
  } catch (error) {
    console.warn("[YA] restore purchases", error);
    set({ restoreFailed: !!payments });
  } finally { set({ paymentBusy: false }); }
}

async function buyPremium(id) {
  const s = S();
  if (!payments || !s.cloudReady || !restoredPurchases || s.adBusy || s.paymentBusy || ownsPremium(id) || !s.products?.some((p) => p.id === id)) return;
  set({ paymentBusy: true });
  let paid = false;
  try {
    const purchase = await payments.purchase({ id });
    paid = true;
    if (purchase?.productID !== id) throw new Error("Unexpected purchased product");
    await fulfillPurchase(purchase);
    markShopPurchase();
    toast(t("bought"), "#7ef07e");
  } catch (error) {
    if (paid) {
      restoredPurchases = false;
      set({ restoreFailed: true });
    }
    toast(t(paid ? "restoreNeeded" : "paymentIncomplete"), "#ff8a8a");
    console.warn("[YA] purchase", error);
  } finally { set({ paymentBusy: false }); }
}

const LEADERBOARD = "top_earners";
let scoreAttempt = -Infinity;
let bestSent;
let scorePosting = false;
async function postEarnings() {
  const s = S();
  if (!s.started || !s.cloudReady || !s.authorized || s.paymentBusy || scorePosting || !YA.isAuthorized()) return;
  const score = Math.max(0, Math.min(Number.MAX_SAFE_INTEGER, Math.floor(s.stats.earned)));
  const now = Date.now();
  if (!score || (bestSent !== undefined && score <= bestSent) || now - scoreAttempt < 30_000) return;
  scoreAttempt = now;
  scorePosting = true;
  try {
    const board = await YA.getLeaderboards();
    if (!board) return;
    if (bestSent === undefined && typeof board.getPlayerEntry === "function") {
      try { bestSent = (await board.getPlayerEntry(LEADERBOARD))?.score ?? 0; }
      catch (error) {
        if (error?.code !== "LEADERBOARD_PLAYER_NOT_PRESENT") throw error;
        bestSent = 0;
      }
    }
    if (!YA.isAuthorized() || !S().cloudReady || S().paymentBusy || score <= (bestSent ?? 0)) return;
    await board.setScore(LEADERBOARD, score);
    bestSent = score;
  } catch (error) { console.warn("[YA] leaderboard", error); }
  finally { scorePosting = false; }
}

export function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t0 = Math.imul(a ^ (a >>> 15), 1 | a);
    t0 = (t0 + Math.imul(t0 ^ (t0 >>> 7), 61 | t0)) ^ t0;
    return ((t0 ^ (t0 >>> 14)) >>> 0) / 4294967296;
  };
}

export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
export const lerp = (a, b, t0) => a + (b - a) * t0;
export const smoothstep = (e0, e1, x) => {
  const t0 = clamp((x - e0) / (e1 - e0), 0, 1);
  return t0 * t0 * (3 - 2 * t0);
};
export const damp = (cur, target, lambda, dt) => lerp(cur, target, 1 - Math.exp(-lambda * dt));
export function lerpAngle(a, b, t0) {
  let d = (b - a) % (Math.PI * 2);
  if (d > Math.PI) d -= Math.PI * 2;
  if (d < -Math.PI) d += Math.PI * 2;
  return a + d * t0;
}

const matCache = new Map();
export function mat(color, o = {}) {
  const key = `${color}|${o.emissive ?? ""}|${o.ei ?? 0}|${o.opacity ?? 1}|${o.side ?? 0}|${o.vc ? 1 : 0}`;
  let m = matCache.get(key);
  if (!m) {
    m = new THREE.MeshLambertMaterial({ color, flatShading: true, vertexColors: !!o.vc });
    if (o.emissive) {
      m.emissive = new THREE.Color(o.emissive);
      m.emissiveIntensity = o.ei ?? 1;
    }
    if (o.opacity !== undefined && o.opacity < 1) {
      m.transparent = true;
      m.opacity = o.opacity;
      m.depthWrite = false;
    }
    if (o.side !== undefined) m.side = o.side;
    matCache.set(key, m);
  }
  return m;
}

export function jitter(geo, amt, seed = 1, yAmt = amt, keepY0 = false) {
  const pos = geo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const y = pos.getY(i);
    const z = pos.getZ(i);
    const hash = Math.abs(Math.round(x * 97) * 73856093 ^ Math.round(y * 97) * 19349663 ^ Math.round(z * 97) * 83492791 ^ (seed * 2654435761));
    const r = mulberry32(hash);
    const ny = keepY0 && Math.abs(y) < 1e-4 ? y : y + (r() - 0.5) * 2 * yAmt;
    pos.setXYZ(i, x + (r() - 0.5) * 2 * amt, ny, z + (r() - 0.5) * 2 * amt);
  }
  geo.computeVertexNormals();
  return geo;
}

export function tintVerts(geo, color, variance = 0.08, seed = 3) {
  const pos = geo.attributes.position;
  const c = new THREE.Color(color);
  const arr = new Float32Array(pos.count * 3);
  const r = mulberry32(seed);
  for (let i = 0; i < pos.count; i++) {
    const k = 1 + (r() - 0.5) * 2 * variance;
    arr[i * 3] = c.r * k;
    arr[i * 3 + 1] = c.g * k;
    arr[i * 3 + 2] = c.b * k;
  }
  geo.setAttribute("color", new THREE.BufferAttribute(arr, 3));
  return geo;
}

export function mesh(geo, material, x = 0, y = 0, z = 0, cast = true, receive = false) {
  const m = new THREE.Mesh(geo, material);
  m.position.set(x, y, z);
  m.castShadow = cast;
  m.receiveShadow = receive;
  return m;
}

export function makeLabel(text, bg = "rgba(8,30,60,0.78)", fg = "#ffffff", scale = 1) {
  const c = document.createElement("canvas");
  c.width = 512;
  c.height = 128;
  const ctx = c.getContext("2d");
  ctx.font = "800 54px system-ui, sans-serif";
  const w = Math.min(500, ctx.measureText(text).width + 64);
  const x0 = (512 - w) / 2;
  ctx.fillStyle = bg;
  ctx.beginPath();
  if (typeof ctx.roundRect === "function") ctx.roundRect(x0, 18, w, 92, 40);
  else ctx.rect(x0, 18, w, 92);
  ctx.fill();
  ctx.lineWidth = 6;
  ctx.strokeStyle = "rgba(255,255,255,0.55)";
  ctx.stroke();
  ctx.fillStyle = fg;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(text, 256, 66);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false }));
  s.scale.set(3.4 * scale, 0.85 * scale, 1);
  return s;
}

export function makeExclaim() {
  const c = document.createElement("canvas");
  c.width = c.height = 128;
  const ctx = c.getContext("2d");
  ctx.fillStyle = "#ffd23a";
  ctx.strokeStyle = "#7a3a00";
  ctx.lineWidth = 8;
  ctx.beginPath();
  ctx.arc(64, 64, 54, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = "#e0262a";
  ctx.font = "900 92px system-ui, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("!", 64, 70);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, depthTest: false, transparent: true }));
  s.renderOrder = 999;
  s.scale.set(1.1, 1.1, 1);
  return s;
}

export const SHORE_R = 17.4;

export function waveHeight(x, z, t0, amp) {
  const d = Math.sqrt(x * x + z * z);
  const calm = 0.25 + 0.75 * smoothstep(SHORE_R, SHORE_R + 25, d);
  const h0 =
    Math.sin(x * 0.16 + t0 * 1.1) * 0.22 +
    Math.sin(z * 0.21 - t0 * 0.9) * 0.18 +
    Math.sin((x + z) * 0.33 + t0 * 1.6) * 0.09 +
    Math.sin((x - z * 0.7) * 0.52 - t0 * 2.1) * 0.05;
  return h0 * amp * calm;
}

const waterVert = /* glsl */ `
uniform float uTime; uniform float uAmp; uniform float uShore;
varying vec3 vWorld; varying float vH;
float waveH(vec2 p, float t){
  return sin(p.x*0.16 + t*1.1)*0.22 + sin(p.y*0.21 - t*0.9)*0.18
       + sin((p.x+p.y)*0.33 + t*1.6)*0.09 + sin((p.x - p.y*0.7)*0.52 - t*2.1)*0.05;
}
void main(){
  vec4 w = modelMatrix * vec4(position, 1.0);
  float d = length(w.xz);
  float calm = 0.25 + 0.75 * smoothstep(uShore, uShore + 25.0, d);
  float h = waveH(w.xz, uTime) * uAmp * calm;
  w.y += h;
  vWorld = w.xyz; vH = h;
  gl_Position = projectionMatrix * viewMatrix * w;
}`;

const waterFrag = /* glsl */ `
uniform vec3 uDeep; uniform vec3 uShallow; uniform vec3 uFoam; uniform vec3 uSky;
uniform vec3 uSunDir; uniform vec3 uSunColor; uniform vec3 uFogColor;
uniform float uFogNear; uniform float uFogFar; uniform float uTime; uniform float uShore;
varying vec3 vWorld; varying float vH;
void main(){
  vec3 n = normalize(cross(dFdx(vWorld), dFdy(vWorld)));
  if (n.y < 0.0) n = -n;
  float d = length(vWorld.xz);
  float shallow = 1.0 - smoothstep(uShore - 1.0, uShore + 18.0, d);
  vec3 col = mix(uDeep, uShallow, shallow * 0.9);
  vec3 V = normalize(cameraPosition - vWorld);
  float diff = max(dot(n, uSunDir), 0.0);
  col *= 0.72 + 0.42 * diff;
  float fres = pow(1.0 - max(dot(n, V), 0.0), 4.0);
  col = mix(col, uSky, fres * 0.5);
  vec3 H = normalize(uSunDir + V);
  float spec = pow(max(dot(n, H), 0.0), 90.0);
  col += uSunColor * spec * 0.85;
  float ang = atan(vWorld.z, vWorld.x);
  float edge = uShore + 0.5 + sin(uTime * 1.3 + ang * 7.0) * 0.35 + sin(uTime * 0.7 - ang * 3.0) * 0.25;
  float foam = 1.0 - smoothstep(0.0, 1.7, abs(d - edge));
  foam *= 0.6 + 0.4 * sin(d * 4.0 - uTime * 2.5);
  col = mix(col, uFoam, clamp(foam, 0.0, 1.0) * 0.8);
  col += uFoam * smoothstep(0.2, 0.42, vH) * 0.16;
  float dist = length(cameraPosition - vWorld);
  float fog = smoothstep(uFogNear, uFogFar, dist);
  col = mix(col, uFogColor, fog);
  gl_FragColor = vec4(col, 1.0);
  #include <colorspace_fragment>
}`;

export class Water {
  constructor(segments = 150) {
    this.u = {
      uTime: { value: 0 },
      uAmp: { value: 1 },
      uShore: { value: SHORE_R },
      uDeep: { value: new THREE.Color() },
      uShallow: { value: new THREE.Color() },
      uFoam: { value: new THREE.Color() },
      uSky: { value: new THREE.Color() },
      uSunDir: { value: new THREE.Vector3(0.5, 0.7, 0.3).normalize() },
      uSunColor: { value: new THREE.Color("#ffffff") },
      uFogColor: { value: new THREE.Color() },
      uFogNear: { value: 60 },
      uFogFar: { value: 260 },
    };
    const geo = new THREE.PlaneGeometry(540, 540, segments, segments);
    geo.rotateX(-Math.PI / 2);
    const m = new THREE.ShaderMaterial({ uniforms: this.u, vertexShader: waterVert, fragmentShader: waterFrag });
    this.mesh = new THREE.Mesh(geo, m);
    this.mesh.frustumCulled = false;
  }
}

const skyVert = /* glsl */ `
varying vec3 vDir;
void main(){
  vDir = normalize(position);
  gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
}`;
const skyFrag = /* glsl */ `
uniform vec3 uTop; uniform vec3 uHorizon; uniform vec3 uSunDir; uniform vec3 uSunColor; uniform float uStars; uniform float uTime;
varying vec3 vDir;
void main(){
  vec3 d = normalize(vDir);
  float h = d.y;
  vec3 col = mix(uHorizon, uTop, pow(smoothstep(-0.02, 0.65, h), 0.75));
  float s = max(dot(d, normalize(uSunDir)), 0.0);
  col += uSunColor * (pow(s, 600.0) * 1.6 + pow(s, 14.0) * 0.22);
  if (uStars > 0.001) {
    vec3 cell = floor(d * 160.0);
    float r = fract(sin(dot(cell, vec3(12.9898, 78.233, 45.164))) * 43758.5453);
    float tw = 0.6 + 0.4 * sin(uTime * 2.0 + r * 60.0);
    col += step(0.9975, r) * uStars * tw * smoothstep(0.02, 0.25, h);
  }
  gl_FragColor = vec4(col, 1.0);
  #include <colorspace_fragment>
}`;

export class Sky {
  constructor() {
    this.u = {
      uTop: { value: new THREE.Color() },
      uHorizon: { value: new THREE.Color() },
      uSunDir: { value: new THREE.Vector3(0.5, 0.7, 0.3) },
      uSunColor: { value: new THREE.Color("#ffffff") },
      uStars: { value: 0 },
      uTime: { value: 0 },
    };
    const m = new THREE.ShaderMaterial({
      uniforms: this.u, vertexShader: skyVert, fragmentShader: skyFrag,
      side: THREE.BackSide, depthWrite: false, depthTest: false,
    });
    this.mesh = new THREE.Mesh(new THREE.SphereGeometry(400, 32, 16), m);
    this.mesh.frustumCulled = false;
    this.mesh.renderOrder = -100;
  }
}

const ptVert = /* glsl */ `
attribute vec3 aColor; attribute float aSize; attribute float aAlpha;
uniform float uScale;
varying vec3 vColor; varying float vAlpha;
void main(){
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  gl_Position = projectionMatrix * mv;
  gl_PointSize = aSize * uScale / max(0.2, -mv.z);
  vColor = aColor; vAlpha = aAlpha;
}`;
const ptFrag = /* glsl */ `
varying vec3 vColor; varying float vAlpha;
void main(){
  vec2 c = gl_PointCoord - 0.5;
  float d = length(c);
  if (d > 0.5 || vAlpha < 0.003) discard;
  float a = smoothstep(0.5, 0.12, d) * vAlpha;
  gl_FragColor = vec4(vColor, a);
  #include <colorspace_fragment>
}`;

function pointsMaterial(additive, scale) {
  return new THREE.ShaderMaterial({
    uniforms: { uScale: scale },
    vertexShader: ptVert,
    fragmentShader: ptFrag,
    transparent: true,
    depthWrite: false,
    blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
  });
}

export const pointScale = { value: 400 };

export class Particles {
  constructor(max, additive) {
    this.max = max;
    this.pos = new Float32Array(max * 3).fill(0);
    for (let i = 0; i < max; i++) this.pos[i * 3 + 1] = -999;
    this.col = new Float32Array(max * 3);
    this.size = new Float32Array(max);
    this.alpha = new Float32Array(max);
    this.vel = new Float32Array(max * 3);
    this.life = new Float32Array(max);
    this.maxLife = new Float32Array(max);
    this.grav = new Float32Array(max);
    this.drag = new Float32Array(max);
    this.base = new Float32Array(max);
    this.cursor = 0;
    this.tmp = new THREE.Color();
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    geo.setAttribute("aColor", new THREE.BufferAttribute(this.col, 3).setUsage(THREE.DynamicDrawUsage));
    geo.setAttribute("aSize", new THREE.BufferAttribute(this.size, 1).setUsage(THREE.DynamicDrawUsage));
    geo.setAttribute("aAlpha", new THREE.BufferAttribute(this.alpha, 1).setUsage(THREE.DynamicDrawUsage));
    this.points = new THREE.Points(geo, pointsMaterial(additive, pointScale));
    this.points.frustumCulled = false;
    this.points.renderOrder = 5;
  }

  emit(x, y, z, o) {
    const n = o.count ?? 10;
    const c = typeof o.color === "string" ? new THREE.Color(o.color) : o.color;
    for (let k = 0; k < n; k++) {
      const i = this.cursor;
      this.cursor = (this.cursor + 1) % this.max;
      const a = Math.random() * Math.PI * 2;
      const sp = (o.speed ?? 3) * (0.4 + Math.random() * 0.6);
      const spread = o.spread ?? 1;
      this.pos[i * 3] = x + (Math.random() - 0.5) * 0.3;
      this.pos[i * 3 + 1] = y;
      this.pos[i * 3 + 2] = z + (Math.random() - 0.5) * 0.3;
      this.vel[i * 3] = Math.cos(a) * sp * spread;
      this.vel[i * 3 + 1] = (o.up ?? 4) * (0.6 + Math.random() * 0.5);
      this.vel[i * 3 + 2] = Math.sin(a) * sp * spread;
      const v = o.colorVar ?? 0.1;
      this.tmp.copy(c).offsetHSL((Math.random() - 0.5) * v, 0, (Math.random() - 0.5) * v);
      this.col[i * 3] = this.tmp.r;
      this.col[i * 3 + 1] = this.tmp.g;
      this.col[i * 3 + 2] = this.tmp.b;
      this.base[i] = (o.size ?? 0.25) * (0.6 + Math.random() * 0.7);
      this.maxLife[i] = (o.life ?? 0.9) * (0.6 + Math.random() * 0.6);
      this.life[i] = this.maxLife[i];
      this.grav[i] = o.gravity ?? -9;
      this.drag[i] = o.drag ?? 0.5;
    }
  }

  update(dt) {
    for (let i = 0; i < this.max; i++) {
      if (this.life[i] <= 0) {
        if (this.alpha[i] !== 0) {
          this.alpha[i] = 0;
          this.pos[i * 3 + 1] = -999;
        }
        continue;
      }
      this.life[i] -= dt;
      const k = Math.max(0, 1 - this.drag[i] * dt);
      this.vel[i * 3] *= k;
      this.vel[i * 3 + 2] *= k;
      this.vel[i * 3 + 1] = this.vel[i * 3 + 1] * k + this.grav[i] * dt;
      this.pos[i * 3] += this.vel[i * 3] * dt;
      this.pos[i * 3 + 1] += this.vel[i * 3 + 1] * dt;
      this.pos[i * 3 + 2] += this.vel[i * 3 + 2] * dt;
      const t0 = this.life[i] / this.maxLife[i];
      this.alpha[i] = Math.min(1, t0 * 2.2);
      this.size[i] = this.base[i] * (0.5 + 0.5 * t0);
    }
    const g = this.points.geometry;
    g.attributes.position.needsUpdate = true;
    g.attributes.aColor.needsUpdate = true;
    g.attributes.aSize.needsUpdate = true;
    g.attributes.aAlpha.needsUpdate = true;
  }
}

export class WeatherFX {
  constructor() {
    this.type = "none";
    this.n = 650;
    this.intensity = 0;
    const n = this.n;
    this.pos = new Float32Array(n * 3);
    this.col = new Float32Array(n * 3);
    this.size = new Float32Array(n);
    this.alpha = new Float32Array(n);
    this.ph = new Float32Array(n);
    for (let i = 0; i < n; i++) {
      this.ph[i] = Math.random() * 100;
      this.pos[i * 3] = (Math.random() - 0.5) * 60;
      this.pos[i * 3 + 1] = Math.random() * 24;
      this.pos[i * 3 + 2] = (Math.random() - 0.5) * 60;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(this.pos, 3).setUsage(THREE.DynamicDrawUsage));
    geo.setAttribute("aColor", new THREE.BufferAttribute(this.col, 3));
    geo.setAttribute("aSize", new THREE.BufferAttribute(this.size, 1));
    geo.setAttribute("aAlpha", new THREE.BufferAttribute(this.alpha, 1).setUsage(THREE.DynamicDrawUsage));
    this.mat = pointsMaterial(false, pointScale);
    this.points = new THREE.Points(geo, this.mat);
    this.points.frustumCulled = false;
    this.points.renderOrder = 6;
  }

  setType(type) {
    if (type === this.type) return;
    this.type = type;
    const additive = type === "embers" || type === "fireflies" || type === "stars" || type === "bubbles";
    this.mat.blending = additive ? THREE.AdditiveBlending : THREE.NormalBlending;
    this.mat.needsUpdate = true;
    const c = new THREE.Color();
    for (let i = 0; i < this.n; i++) {
      let s = 0.15;
      switch (type) {
        case "snow": c.set("#ffffff"); s = 0.16 + Math.random() * 0.12; break;
        case "rain": c.set("#cfe3ff"); s = 0.07 + Math.random() * 0.04; break;
        case "embers": c.set(Math.random() < 0.5 ? "#ff7a1a" : "#ffb23a"); s = 0.1 + Math.random() * 0.1; break;
        case "fireflies": c.set(Math.random() < 0.5 ? "#7affd8" : "#c6a6ff"); s = 0.14 + Math.random() * 0.1; break;
        case "stars": c.set(Math.random() < 0.5 ? "#fff6c0" : "#bfe0ff"); s = 0.2 + Math.random() * 0.15; break;
        case "bubbles": c.set(Math.random() < 0.5 ? "#d8fff4" : "#a6e8d8"); s = 0.12 + Math.random() * 0.14; break;
        case "petals": c.set(Math.random() < 0.5 ? "#ffc6e0" : "#c6b0ff"); s = 0.16 + Math.random() * 0.12; break;
        default: break;
      }
      this.col[i * 3] = c.r;
      this.col[i * 3 + 1] = c.g;
      this.col[i * 3 + 2] = c.b;
      this.size[i] = s;
    }
    this.points.geometry.attributes.aColor.needsUpdate = true;
    this.points.geometry.attributes.aSize.needsUpdate = true;
  }

  update(dt, cam, t0) {
    const target = this.type === "none" ? 0 : 1;
    this.intensity += (target - this.intensity) * Math.min(1, dt * 1.5);
    this.points.visible = this.intensity > 0.01;
    if (!this.points.visible) return;
    const R = 30;
    for (let i = 0; i < this.n; i++) {
      const ix = i * 3;
      let x = this.pos[ix], y = this.pos[ix + 1], z = this.pos[ix + 2];
      const p = this.ph[i];
      let a = 1;
      switch (this.type) {
        case "snow": y -= dt * (1.6 + (p % 1)); x += Math.sin(t0 * 0.8 + p) * dt * 0.8; z += Math.cos(t0 * 0.6 + p) * dt * 0.5; a = 0.9; break;
        case "rain": y -= dt * 26; x += dt * 3; a = 0.55; break;
        case "embers": y += dt * (1.2 + (p % 1.5)); x += Math.sin(t0 * 1.5 + p) * dt * 0.7; a = 0.55 + 0.45 * Math.sin(t0 * 6 + p); break;
        case "fireflies": x += Math.sin(t0 * 0.7 + p) * dt * 0.9; y += Math.sin(t0 * 1.1 + p * 1.7) * dt * 0.5; z += Math.cos(t0 * 0.5 + p) * dt * 0.9; a = Math.max(0, Math.sin(t0 * 2 + p)); break;
        case "stars": y -= dt * 9; x += dt * 7; a = 0.9; break;
        case "bubbles": y += dt * (1.1 + (p % 1.2)); x += Math.sin(t0 * 2 + p) * dt * 0.5; z += Math.cos(t0 * 1.7 + p) * dt * 0.5; a = 0.55; break;
        case "petals": y -= dt * 1.3; x += Math.sin(t0 * 1.1 + p) * dt * 1.6; z += Math.cos(t0 * 0.8 + p) * dt * 1.2; a = 0.85; break;
        default: break;
      }
      if (y < -0.5) y += 24;
      if (y > 24) y -= 24;
      if (x - cam.x > R) x -= 2 * R;
      if (x - cam.x < -R) x += 2 * R;
      if (z - cam.z > R) z -= 2 * R;
      if (z - cam.z < -R) z += 2 * R;
      this.pos[ix] = x;
      this.pos[ix + 1] = y;
      this.pos[ix + 2] = z;
      this.alpha[i] = a * this.intensity;
    }
    this.points.geometry.attributes.position.needsUpdate = true;
    this.points.geometry.attributes.aAlpha.needsUpdate = true;
  }
}

export function shade(hex, amt) {
  const c = new THREE.Color(hex);
  const hsl = { h: 0, s: 0, l: 0 };
  c.getHSL(hsl);
  c.setHSL(hsl.h, hsl.s, Math.min(1, Math.max(0, hsl.l + amt)));
  return "#" + c.getHexString();
}

function buildRod(rig) {
  const main = new THREE.MeshLambertMaterial({ color: "#d8b45a", flatShading: true });
  const accent = new THREE.MeshLambertMaterial({ color: "#7a5a2a", flatShading: true });
  const rod = new THREE.Group();
  rod.position.set(0, -0.74, 0.06);
  rod.rotation.x = 1.66;
  rig.armR.add(rod);
  rod.add(mesh(new THREE.CylinderGeometry(0.055, 0.065, 0.5, 8).translate(0, -0.05, 0), accent));
  const reel = mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.08, 10), accent, 0, 0.12, -0.11);
  reel.rotation.z = Math.PI / 2;
  rod.add(reel);
  const lens = [0.95, 0.85, 0.8];
  const radii = [[0.034, 0.046], [0.022, 0.034], [0.01, 0.022]];
  let parent = rod;
  for (let i = 0; i < 3; i++) {
    const piv = new THREE.Group();
    if (i > 0) piv.position.y = lens[i - 1];
    parent.add(piv);
    const g = new THREE.CylinderGeometry(radii[i][0], radii[i][1], lens[i], 6).translate(0, lens[i] / 2, 0);
    piv.add(mesh(g, main));
    if (i < 2) piv.add(mesh(new THREE.TorusGeometry(0.035, 0.008, 4, 8), accent, 0, lens[i] - 0.02, -0.03, false));
    rig.rodPivots.push(piv);
    parent = piv;
  }
  const tip = new THREE.Object3D();
  tip.position.y = lens[2];
  parent.add(tip);
  rig.rod = rod;
  rig.rodTip = tip;
  rig.rodMain = main;
  rig.rodAccent = accent;
}

export function createCharacter(o) {
  const root = new THREE.Group();
  const body = new THREE.Group();
  root.add(body);
  const boots = o.boots ?? "#4a3426";

  const legGeo = new THREE.BoxGeometry(0.36, 0.8, 0.4).translate(0, -0.4, 0);
  const bootGeo = new THREE.BoxGeometry(0.4, 0.22, 0.48).translate(0, -0.7, 0.03);
  const mkLeg = (x) => {
    const g = new THREE.Group();
    g.position.set(x, 0.82, 0);
    g.add(mesh(legGeo, mat(o.pants)), mesh(bootGeo, mat(boots)));
    body.add(g);
    return g;
  };
  const legL = mkLeg(-0.2);
  const legR = mkLeg(0.2);

  body.add(mesh(new THREE.BoxGeometry(0.86, 0.86, 0.46), mat(o.shirt), 0, 1.24, 0));
  body.add(mesh(new THREE.BoxGeometry(0.88, 0.1, 0.48), mat("#3a2a1e"), 0, 0.86, 0));
  body.add(mesh(new THREE.BoxGeometry(0.22, 0.18, 0.02), mat(shade(o.shirt, -0.12)), 0.2, 1.32, 0.235, false));

  const armGeo = new THREE.BoxGeometry(0.3, 0.78, 0.34).translate(0, -0.33, 0);
  const handGeo = new THREE.BoxGeometry(0.26, 0.2, 0.3).translate(0, -0.78, 0);
  const mkArm = (x) => {
    const g = new THREE.Group();
    g.position.set(x, 1.6, 0);
    g.add(mesh(armGeo, mat(o.shirt)), mesh(handGeo, mat(o.skin)));
    body.add(g);
    return g;
  };
  const armL = mkArm(-0.6);
  const armR = mkArm(0.6);

  const head = new THREE.Group();
  head.position.set(0, 1.67, 0);
  head.add(mesh(new THREE.BoxGeometry(0.58, 0.58, 0.58), mat(o.skin), 0, 0.31, 0));
  const eyeGeo = new THREE.BoxGeometry(0.08, 0.12, 0.03);
  head.add(mesh(eyeGeo, mat("#1a1a1a"), -0.13, 0.37, 0.295, false), mesh(eyeGeo, mat("#1a1a1a"), 0.13, 0.37, 0.295, false));
  head.add(mesh(new THREE.BoxGeometry(0.2, 0.05, 0.03), mat("#6a2a1a"), 0, 0.2, 0.295, false));
  const cheek = new THREE.BoxGeometry(0.08, 0.05, 0.02);
  head.add(mesh(cheek, mat("#f08a8a"), -0.2, 0.25, 0.295, false), mesh(cheek, mat("#f08a8a"), 0.2, 0.25, 0.295, false));
  if (o.hatType === "bucket") {
    head.add(mesh(new THREE.CylinderGeometry(0.33, 0.37, 0.26, 10), mat(o.hat), 0, 0.7, 0));
    head.add(mesh(new THREE.CylinderGeometry(0.58, 0.58, 0.05, 14), mat(o.hat), 0, 0.58, 0));
    head.add(mesh(new THREE.CylinderGeometry(0.375, 0.375, 0.07, 10), mat(shade(o.hat, -0.25)), 0, 0.62, 0, false));
  } else if (o.hatType === "cap") {
    head.add(mesh(new THREE.BoxGeometry(0.62, 0.2, 0.62), mat(o.hat), 0, 0.68, 0));
    head.add(mesh(new THREE.BoxGeometry(0.56, 0.05, 0.32), mat(o.hat), 0, 0.6, 0.44));
  } else if (o.hatType === "captain") {
    head.add(mesh(new THREE.CylinderGeometry(0.4, 0.34, 0.24, 12), mat("#ffffff"), 0, 0.7, 0));
    head.add(mesh(new THREE.CylinderGeometry(0.345, 0.345, 0.08, 12), mat("#1a2a4a"), 0, 0.62, 0, false));
    head.add(mesh(new THREE.BoxGeometry(0.42, 0.05, 0.26), mat("#1a1a1a"), 0, 0.6, 0.34));
    head.add(mesh(new THREE.BoxGeometry(0.12, 0.08, 0.02), mat("#ffd23a", { emissive: "#6a4a00", ei: 0.5 }), 0, 0.72, 0.38, false));
  }
  body.add(head);

  const hold = new THREE.Object3D();
  hold.position.set(0, 1.95, 0.9);
  root.add(hold);

  const rig = { root, body, head, armL, armR, legL, legR, rod: null, rodPivots: [], rodTip: null, rodMain: null, rodAccent: null, hold };
  if (o.withRod) buildRod(rig);
  root.traverse((c) => {
    if (c.isMesh) c.castShadow = true;
  });
  return rig;
}

export function setRodLook(rig, rod) {
  if (!rig.rodMain || !rig.rodAccent) return;
  rig.rodMain.color.set(rod.color);
  rig.rodAccent.color.set(rod.accent);
  if (rod.glow) {
    rig.rodMain.emissive.set(rod.color);
    rig.rodMain.emissiveIntensity = 0.55;
  } else {
    rig.rodMain.emissive.set("#000000");
    rig.rodMain.emissiveIntensity = 0;
  }
}

export function createBobber() {
  const g = new THREE.Group();
  g.add(mesh(new THREE.SphereGeometry(0.15, 12, 6, 0, Math.PI * 2, 0, Math.PI / 2), mat("#e8302a")));
  g.add(mesh(new THREE.SphereGeometry(0.15, 12, 6, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), mat("#ffffff")));
  g.add(mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.22, 5), mat("#ffffff"), 0, 0.22, 0));
  return g;
}

const SHAPES = {
  normal: { bx: 1, by: 0.42, bz: 0.24, taper: 0.55, tail: "fork", dorsal: "tri" },
  long: { bx: 1.35, by: 0.2, bz: 0.17, taper: 0.5, tail: "thin", dorsal: "long" },
  round: { bx: 0.75, by: 0.62, bz: 0.55, taper: 0.35, tail: "round", dorsal: "tri" },
  tall: { bx: 0.75, by: 0.66, bz: 0.16, taper: 0.5, tail: "fork", dorsal: "tall", ventral: true },
  shark: { bx: 1.3, by: 0.34, bz: 0.3, taper: 0.65, tail: "crescent", dorsal: "shark" },
  ray: { bx: 0.8, by: 0.12, bz: 0.95, taper: 0.4, tail: "whip", dorsal: "none" },
  sword: { bx: 1.15, by: 0.36, bz: 0.24, taper: 0.6, tail: "crescent", dorsal: "shark" },
};

function mutColors(def, mut) {
  const base = { body: def.body, belly: def.belly, fin: def.fin, accent: def.accent ?? shade(def.fin, -0.15) };
  switch (mut) {
    case "albino": return { body: "#f6f2f0", belly: "#ffffff", fin: "#ffc8d0", accent: "#ffe0e6" };
    case "golden": return { body: "#ffcf33", belly: "#fff0a0", fin: "#ffb300", accent: "#ffe680" };
    case "galaxy": return { body: "#2a1a6a", belly: "#6a3aff", fin: "#ff6aff", accent: "#ffffff" };
    case "ghost": {
      const g = (h0) => "#" + new THREE.Color(h0).lerp(new THREE.Color("#a6f4ff"), 0.6).getHexString();
      return { body: g(base.body), belly: g(base.belly), fin: g(base.fin), accent: g(base.accent) };
    }
    case "rainbow": return { body: "#ffffff", belly: "#f0f0f0", fin: "#ffffff", accent: "#dddddd" };
    case "crystal": return { body: "#9fe8ff", belly: "#eafaff", fin: "#c6b0ff", accent: "#ffffff" };
    case "solar": return { body: "#ffb02e", belly: "#fff2a0", fin: "#ff6a1a", accent: "#fff6d0" };
    case "void": return { body: "#1a0a2a", belly: "#3a1a5a", fin: "#8a2aff", accent: "#c66aff" };
    default: return base;
  }
}

function tailShape(kind) {
  const s = new THREE.Shape();
  switch (kind) {
    case "fork":
      s.moveTo(0.06, 0); s.lineTo(-0.45, 0.4); s.lineTo(-0.32, 0); s.lineTo(-0.45, -0.4); s.lineTo(0.06, 0);
      break;
    case "round":
      s.moveTo(0.04, 0); s.quadraticCurveTo(-0.5, 0.5, -0.46, 0); s.quadraticCurveTo(-0.5, -0.5, 0.04, 0);
      break;
    case "crescent":
      s.moveTo(0.06, 0.05); s.quadraticCurveTo(-0.2, 0.22, -0.42, 0.58); s.quadraticCurveTo(-0.3, 0.12, -0.27, 0);
      s.quadraticCurveTo(-0.3, -0.12, -0.38, -0.4); s.quadraticCurveTo(-0.18, -0.15, 0.06, -0.05);
      break;
    case "thin":
      s.moveTo(0.06, 0.07); s.lineTo(-0.62, 0); s.lineTo(0.06, -0.07);
      break;
    case "whip":
      s.moveTo(0.05, 0.03); s.lineTo(-1.3, 0); s.lineTo(0.05, -0.03);
      break;
  }
  return s;
}

function dorsalShape(kind) {
  const s = new THREE.Shape();
  switch (kind) {
    case "tri": s.moveTo(-0.38, 0); s.lineTo(0.22, 0); s.lineTo(-0.22, 0.32); break;
    case "long": s.moveTo(-1.15, 0); s.lineTo(0.75, 0); s.lineTo(0.6, 0.11); s.lineTo(-1.05, 0.13); break;
    case "tall": s.moveTo(-0.45, 0); s.lineTo(0.25, 0); s.lineTo(-0.38, 0.62); break;
    case "shark": s.moveTo(-0.26, 0); s.lineTo(0.26, 0); s.quadraticCurveTo(0.02, 0.22, -0.22, 0.48); break;
    case "none": return null;
  }
  return s;
}

function bodyVertexColors(geo, cols, def, mut) {
  const pos = geo.attributes.position;
  const cBody = new THREE.Color(cols.body);
  const cBelly = new THREE.Color(cols.belly);
  const cAcc = new THREE.Color(cols.accent);
  const out = new Float32Array(pos.count * 3);
  const c = new THREE.Color();
  const pattern = mut === "galaxy" ? "spots" : def.pattern;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    c.copy(cBelly).lerp(cBody, smoothstep(-0.35, 0.25, y));
    if (pattern === "stripes" && Math.sin(x * 11 + 1) > 0.55 && y > -0.35) c.lerp(cAcc, 0.8);
    if (pattern === "spots") {
      const h0 = Math.abs(Math.sin(Math.round(x * 6) * 12.9898 + Math.round(y * 6) * 78.233 + Math.round(z * 6) * 37.719) * 43758.5453) % 1;
      if (h0 > 0.8 && y > -0.4) c.lerp(cAcc, 0.85);
    }
    out[i * 3] = c.r;
    out[i * 3 + 1] = c.g;
    out[i * 3 + 2] = c.b;
  }
  geo.setAttribute("color", new THREE.BufferAttribute(out, 3));
}

export function createFishMesh(def, mut, length) {
  const g = new THREE.Group();
  const cols = mutColors(def, mut);
  const emissive = new THREE.Color(0x000000);
  let ei = 0;
  if (def.glow) {
    emissive.set(cols.fin);
    ei = 0.45;
  }
  const phong = { vertexColors: true, flatShading: true, shininess: 50, specular: new THREE.Color("#333333") };
  if (mut === "golden") {
    phong.specular = new THREE.Color("#ffe9a0");
    phong.shininess = 90;
    emissive.set("#6a4a00");
    ei = 0.45;
  } else if (mut === "shiny") {
    emissive.set(cols.body);
    ei = 0.4;
  } else if (mut === "ghost") {
    phong.transparent = true;
    phong.opacity = 0.55;
    phong.depthWrite = false;
    emissive.set("#60d0ff");
    ei = 0.4;
  } else if (mut === "galaxy") {
    emissive.set("#4a1aa0");
    ei = 0.55;
  }
  const bodyMat = new THREE.MeshPhongMaterial({ ...phong, emissive, emissiveIntensity: ei });
  const finMat = new THREE.MeshPhongMaterial({
    color: cols.fin, flatShading: true, side: THREE.DoubleSide, emissive, emissiveIntensity: ei,
    transparent: !!phong.transparent, opacity: phong.opacity ?? 1, depthWrite: !phong.transparent,
  });
  const eyeWhite = mat("#ffffff");
  const pupil = mat(mut === "albino" ? "#e0263a" : "#111111");
  const tail = new THREE.Group();
  let matsOut = null;

  if (def.shape === "jelly") {
    const bellGeo = new THREE.SphereGeometry(0.62, 14, 8, 0, Math.PI * 2, 0, Math.PI * 0.62);
    bellGeo.scale(1, 0.95, 1);
    bellGeo.rotateZ(-Math.PI / 2);
    bodyVertexColors(bellGeo, cols, def, mut);
    const bellMat = new THREE.MeshPhongMaterial({
      ...phong, emissive, emissiveIntensity: Math.max(ei, 0.3), side: THREE.DoubleSide,
      transparent: true, opacity: mut === "ghost" ? 0.4 : 0.72, depthWrite: false,
    });
    g.add(mesh(bellGeo, bellMat, 0.25, 0, 0));
    const rimGeo = new THREE.TorusGeometry(0.6, 0.055, 5, 18);
    rimGeo.rotateY(Math.PI / 2);
    g.add(mesh(rimGeo, finMat, 0.25, 0, 0, false));
    for (const s of [-1, 1]) {
      g.add(mesh(new THREE.SphereGeometry(0.075, 7, 5), eyeWhite, 0.5, 0.02, 0.22 * s, false));
      g.add(mesh(new THREE.SphereGeometry(0.042, 6, 5), pupil, 0.55, 0.02, 0.26 * s, false));
    }
    tail.position.x = 0.2;
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * Math.PI * 2;
      const len = 0.75 + (i % 3) * 0.3;
      const tg = new THREE.CylinderGeometry(0.022, 0.045, len, 5);
      tg.rotateZ(Math.PI / 2);
      tg.translate(-len / 2, 0, 0);
      const tm = mesh(tg, finMat, 0, Math.sin(a) * 0.34, Math.cos(a) * 0.34);
      tm.rotation.y = Math.cos(a) * 0.18;
      tm.rotation.z = Math.sin(a) * 0.18;
      tail.add(tm);
    }
    g.add(tail);
    bodyMat.dispose();
    matsOut = [bellMat, finMat];
  } else if (def.shape === "squid") {
    const mantleGeo = new THREE.ConeGeometry(0.36, 1.3, 8, 3);
    mantleGeo.rotateZ(-Math.PI / 2);
    bodyVertexColors(mantleGeo, cols, def, mut);
    g.add(mesh(mantleGeo, bodyMat, 0.45, 0, 0));
    const headGeo = new THREE.SphereGeometry(0.32, 10, 8);
    bodyVertexColors(headGeo, cols, def, mut);
    g.add(mesh(headGeo, bodyMat, -0.35, 0, 0));
    for (const s of [-1, 1]) {
      g.add(mesh(new THREE.SphereGeometry(0.09, 8, 6), eyeWhite, -0.3, 0.08, 0.27 * s, false));
      g.add(mesh(new THREE.SphereGeometry(0.05, 6, 5), pupil, -0.27, 0.08, 0.34 * s, false));
    }
    const finGeo = new THREE.ShapeGeometry(tailShape("round"));
    const fin = mesh(finGeo, finMat, 1.05, 0, 0);
    fin.rotation.y = Math.PI;
    fin.rotation.x = Math.PI / 2;
    g.add(fin);
    tail.position.x = -0.55;
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      const tg = new THREE.ConeGeometry(0.05, 1.0, 5);
      tg.rotateZ(Math.PI / 2);
      const tm = mesh(tg, finMat, -0.5, Math.sin(a) * 0.14, Math.cos(a) * 0.14);
      tm.rotation.y = Math.cos(a) * 0.25;
      tm.rotation.z = Math.sin(a) * 0.25;
      tail.add(tm);
    }
    g.add(tail);
  } else {
    const cfg = SHAPES[def.shape];
    const geo = new THREE.SphereGeometry(1, 14, 10);
    const pos = geo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      let y = pos.getY(i);
      let z = pos.getZ(i);
      const k = x < 0 ? 1 - cfg.taper * Math.pow(-x, 1.3) : 1 - 0.2 * x * x;
      y *= k;
      z *= k;
      pos.setXYZ(i, x * cfg.bx, y * cfg.by, z * cfg.bz);
    }
    geo.computeVertexNormals();
    bodyVertexColors(geo, cols, def, mut);
    g.add(mesh(geo, bodyMat));

    tail.position.x = -cfg.bx * 0.9;
    const tScale = def.shape === "ray" ? 1 : Math.max(0.32, cfg.by) * 1.45;
    const tGeo = new THREE.ShapeGeometry(tailShape(cfg.tail));
    const tm = mesh(tGeo, finMat);
    tm.scale.setScalar(tScale);
    tail.add(tm);
    g.add(tail);

    const ds = dorsalShape(cfg.dorsal);
    if (ds) {
      const dm = mesh(new THREE.ShapeGeometry(ds), finMat, def.shape === "shark" || def.shape === "sword" ? 0.1 : 0, cfg.by * 0.86, 0);
      dm.scale.setScalar(def.shape === "long" ? 1 : Math.max(0.6, cfg.by * 1.9));
      g.add(dm);
      if (cfg.ventral) {
        const vm = dm.clone();
        vm.position.y = -cfg.by * 0.86;
        vm.scale.y *= -0.8;
        g.add(vm);
      }
    }
    if (def.shape !== "ray") {
      const ps = new THREE.Shape();
      ps.moveTo(0, 0); ps.lineTo(-0.3, 0.1); ps.lineTo(-0.24, -0.13);
      const pg = new THREE.ShapeGeometry(ps);
      for (const s of [-1, 1]) {
        const pm = mesh(pg, finMat, cfg.bx * 0.35, -cfg.by * 0.3, cfg.bz * 0.82 * s);
        pm.rotation.y = 0.6 * s;
        pm.scale.setScalar(Math.max(0.7, cfg.by * 2));
        g.add(pm);
      }
    }
    if (def.shape === "sword") {
      const ng = new THREE.ConeGeometry(0.035, 1.0, 6);
      ng.rotateZ(-Math.PI / 2);
      g.add(mesh(ng, bodyMat, cfg.bx + 0.45, 0.02, 0));
    }
    const eyeR = Math.min(0.13, Math.max(0.06, cfg.by * 0.22));
    const ex = cfg.bx * 0.62;
    const ey = def.shape === "ray" ? cfg.by * 0.7 : cfg.by * 0.22;
    const ez = def.shape === "ray" ? cfg.bz * 0.25 : cfg.bz * 0.62;
    for (const s of [-1, 1]) {
      g.add(mesh(new THREE.SphereGeometry(eyeR, 8, 6), eyeWhite, ex, ey, ez * s, false));
      g.add(mesh(new THREE.SphereGeometry(eyeR * 0.55, 6, 5), pupil, ex + eyeR * 0.25, ey, (ez + eyeR * 0.6) * s, false));
    }
  }

  const box = new THREE.Box3().setFromObject(g);
  const size = box.max.x - box.min.x;
  const k = length / Math.max(0.01, size);
  g.scale.setScalar(k);
  g.traverse((c) => {
    if (c.isMesh) c.castShadow = true;
  });
  const sparkleMuts = ["shiny", "galaxy", "rainbow", "golden", "crystal", "solar", "void"];
  g.userData = {
    tail,
    mats: matsOut ?? [bodyMat, finMat],
    rainbow: mut === "rainbow",
    sparkle: !!mut && sparkleMuts.includes(mut),
  };
  return g;
}

export function disposeFish(g) {
  const d = g.userData;
  d?.mats?.forEach((m) => m.dispose());
  g.traverse((c) => {
    if (c.isMesh) c.geometry.dispose();
  });
}

export const WALK_R = 16.2;
export const PIER = { x0: 12.2, x1: 31, hw: 1.45, y: 0.95 };
export const SPAWN = { x: 8.5, z: 0, heading: Math.PI / 2 };

export function terrainHeight(r) {
  if (r < 13) return 1.2;
  if (r < 14.73) return 1.2 - ((r - 13) / 1.73) * 0.8;
  return 0.4;
}
export const onPier = (x, z, pad = 0) => x >= PIER.x0 - pad && x <= PIER.x1 + pad && Math.abs(z) <= PIER.hw + pad;
export function groundHeight(x, z) {
  const r = Math.hypot(x, z);
  let h0 = terrainHeight(Math.min(r, WALK_R + 1));
  if (onPier(x, z)) h0 = Math.max(h0, PIER.y);
  return h0;
}
export const isWalkable = (x, z) => Math.hypot(x, z) <= WALK_R || onPier(x, z);
export const isWater = (x, z) => Math.hypot(x, z) > 18.3 && !onPier(x, z, 0.6);

function palm(th, r) {
  const g = new THREE.Group();
  const lean = 0.12 + r() * 0.12;
  let x = 0, y = 0;
  for (let i = 0; i < 6; i++) {
    const seg = mesh(new THREE.CylinderGeometry(0.17 - i * 0.01, 0.21 - i * 0.01, 0.78, 7), mat(i % 2 ? th.wood : shade(th.wood, 0.06)), x, y + 0.39, 0);
    seg.rotation.z = -lean * (i / 5);
    g.add(seg);
    x += Math.sin(lean * (i / 5)) * 0.78;
    y += Math.cos(lean * (i / 5)) * 0.74;
  }
  const leafGeo = new THREE.BoxGeometry(0.75, 0.05, 2.6, 1, 1, 6);
  const lp = leafGeo.attributes.position;
  for (let i = 0; i < lp.count; i++) {
    const z = lp.getZ(i) + 1.3;
    lp.setZ(i, z);
    lp.setY(i, lp.getY(i) - z * z * 0.13);
    lp.setX(i, lp.getX(i) * (1 - (z / 2.6) * 0.7));
  }
  leafGeo.computeVertexNormals();
  const n = 7;
  for (let i = 0; i < n; i++) {
    const leaf = mesh(leafGeo, mat(i % 2 ? th.leaf : th.leaf2), x, y + 0.05, 0);
    leaf.rotation.order = "YXZ";
    leaf.rotation.y = (i / n) * Math.PI * 2 + r() * 0.3;
    leaf.rotation.x = -0.15 + r() * 0.2;
    g.add(leaf);
  }
  for (let i = 0; i < 3; i++) g.add(mesh(new THREE.SphereGeometry(0.16, 6, 5), mat("#6a4a2a"), x + Math.cos(i * 2.1) * 0.22, y - 0.15, Math.sin(i * 2.1) * 0.22));
  return g;
}

function pine(th, snow, r) {
  const g = new THREE.Group();
  const s = 0.85 + r() * 0.5;
  g.add(mesh(new THREE.CylinderGeometry(0.16, 0.22, 1.2, 6), mat(th.wood), 0, 0.6, 0));
  for (let i = 0; i < 3; i++) {
    const rad = (1.5 - i * 0.38) * s;
    const yy = 1.2 + i * 1.0 * s;
    g.add(mesh(jitter(new THREE.ConeGeometry(rad, 1.6 * s, 8), 0.06, i + 3), mat(i % 2 ? th.leaf : th.leaf2), 0, yy + 0.5 * s, 0));
    if (snow) g.add(mesh(new THREE.ConeGeometry(rad * 0.55, 0.6 * s, 8), mat("#ffffff"), 0, yy + 1.05 * s, 0));
  }
  return g;
}

function blossom(th, r) {
  const g = new THREE.Group();
  const s = 0.85 + r() * 0.45;
  g.add(mesh(new THREE.CylinderGeometry(0.14 * s, 0.24 * s, 2.3 * s, 6), mat(th.wood), 0, 1.15 * s, 0));
  for (let i = 0; i < 3; i++) {
    const a = (i / 3) * Math.PI * 2 + r();
    const br = mesh(new THREE.CylinderGeometry(0.07 * s, 0.11 * s, 1.3 * s, 5), mat(th.wood), Math.cos(a) * 0.4 * s, 2.0 * s, Math.sin(a) * 0.4 * s);
    br.rotation.z = -Math.cos(a) * 0.6;
    br.rotation.x = Math.sin(a) * 0.6;
    g.add(br);
  }
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2 + r() * 0.5;
    const rad = (0.6 + r() * 0.7) * s;
    const col = i % 2 ? th.leaf : th.leaf2;
    g.add(mesh(new THREE.IcosahedronGeometry(rad, 0), mat(col, { emissive: col, ei: 0.3 }), Math.cos(a) * 0.9 * s, (2.5 + r() * 0.9) * s, Math.sin(a) * 0.9 * s));
  }
  return g;
}

function deadTree(th, r) {
  const g = new THREE.Group();
  g.add(mesh(new THREE.CylinderGeometry(0.12, 0.25, 3, 6), mat(th.wood), 0, 1.5, 0));
  for (let i = 0; i < 3; i++) {
    const b = mesh(new THREE.CylinderGeometry(0.05, 0.1, 1.3, 5), mat(th.wood), 0, 1.6 + i * 0.5, 0);
    b.rotation.z = (i % 2 ? 1 : -1) * (0.7 + r() * 0.4);
    b.rotation.y = r() * Math.PI * 2;
    b.position.x = Math.sin(b.rotation.z) * -0.45;
    g.add(b);
  }
  return g;
}

function mushroom(th, r) {
  const g = new THREE.Group();
  const s = 0.8 + r() * 0.8;
  g.add(mesh(new THREE.CylinderGeometry(0.2 * s, 0.32 * s, 2.2 * s, 7), mat("#e8e0f0"), 0, 1.1 * s, 0));
  const cap = mesh(new THREE.SphereGeometry(1.2 * s, 10, 6, 0, Math.PI * 2, 0, Math.PI / 2), mat(r() < 0.5 ? th.leaf : th.leaf2, { emissive: r() < 0.5 ? th.leaf : th.leaf2, ei: 0.35 }), 0, 2.1 * s, 0);
  cap.scale.y = 0.6;
  g.add(cap);
  for (let i = 0; i < 4; i++) {
    const a = r() * Math.PI * 2;
    g.add(mesh(new THREE.SphereGeometry(0.12 * s, 5, 4), mat("#ffffff", { emissive: "#ffffff", ei: 0.6 }), Math.cos(a) * 0.7 * s, 2.45 * s, Math.sin(a) * 0.7 * s, false));
  }
  return g;
}

function crystal(color, r, scale = 1) {
  const g = new THREE.Group();
  const n = 3 + Math.floor(r() * 3);
  for (let i = 0; i < n; i++) {
    const h0 = (0.8 + r() * 1.6) * scale;
    const c = mesh(new THREE.OctahedronGeometry(0.4 * scale, 0), mat(color, { emissive: color, ei: 0.75, opacity: 0.9 }), (r() - 0.5) * 0.8 * scale, h0 * 0.5, (r() - 0.5) * 0.8 * scale);
    c.scale.y = h0 / (0.8 * scale);
    c.rotation.z = (r() - 0.5) * 0.6;
    c.rotation.x = (r() - 0.5) * 0.6;
    g.add(c);
  }
  return g;
}

function rock(color, size, seed) {
  const m = mesh(jitter(new THREE.DodecahedronGeometry(size, 0), size * 0.18, seed), mat(color), 0, 0, 0, true, true);
  m.scale.y = 0.7;
  return m;
}

function bush(th, r) {
  const g = new THREE.Group();
  for (let i = 0; i < 3; i++) g.add(mesh(new THREE.IcosahedronGeometry(0.5 + r() * 0.3, 0), mat(i % 2 ? th.leaf : th.leaf2), (r() - 0.5) * 0.9, 0.35 + r() * 0.2, (r() - 0.5) * 0.9));
  return g;
}

function stall(roofA, roofB, wood, label) {
  const g = new THREE.Group();
  g.add(mesh(new THREE.BoxGeometry(3.2, 1.0, 1.0), mat(wood), 0, 0.5, 0, true, true));
  g.add(mesh(new THREE.BoxGeometry(3.4, 0.12, 1.25), mat(shade(wood, 0.12)), 0, 1.06, 0.05, true, true));
  for (const x of [-1.55, 1.55]) for (const z of [0.5, -1.45]) g.add(mesh(new THREE.BoxGeometry(0.14, 2.8, 0.14), mat(shade(wood, -0.05)), x, 1.4, z));
  for (let i = 0; i < 6; i++) {
    const s = mesh(new THREE.BoxGeometry(0.6, 0.1, 2.7), mat(i % 2 ? roofA : roofB), -1.5 + i * 0.6, 2.85, -0.45);
    s.rotation.x = 0.2;
    g.add(s);
    const v = mesh(new THREE.ConeGeometry(0.3, 0.35, 3), mat(i % 2 ? roofA : roofB), -1.5 + i * 0.6, 2.38, 0.92, false);
    v.rotation.x = Math.PI;
    g.add(v);
  }
  const lbl = makeLabel(label);
  lbl.position.set(0, 3.8, -0.3);
  g.add(lbl);
  return g;
}

function npc(shirt, hat, hatType, pants = "#3a3a4a") {
  return createCharacter({ shirt, pants, skin: "#e8b890", hat, hatType });
}

function boat(color, wood) {
  const g = new THREE.Group();
  const hull = new THREE.BoxGeometry(4.2, 0.9, 1.8, 6, 1, 2);
  const p = hull.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i);
    let z = p.getZ(i);
    if (x > 0.9) z *= Math.max(0.08, 1 - (x - 0.9) / 1.2);
    if (y < 0) z *= 0.62;
    p.setZ(i, z);
  }
  hull.computeVertexNormals();
  g.add(mesh(hull, mat(color), 0, 0.25, 0));
  g.add(mesh(new THREE.BoxGeometry(3.0, 0.08, 1.3), mat(wood), -0.25, 0.62, 0));
  g.add(mesh(new THREE.BoxGeometry(4.25, 0.12, 0.06), mat("#ffffff"), 0, 0.55, 0.88, false));
  g.add(mesh(new THREE.BoxGeometry(4.25, 0.12, 0.06), mat("#ffffff"), 0, 0.55, -0.88, false));
  g.add(mesh(new THREE.BoxGeometry(0.35, 0.15, 1.4), mat(shade(wood, 0.1)), 0.7, 0.75, 0));
  const mast = mesh(new THREE.CylinderGeometry(0.06, 0.08, 3.2, 6), mat(wood), 0.3, 2.2, 0);
  g.add(mast);
  const sail = new THREE.Shape();
  sail.moveTo(0, 0); sail.lineTo(0, 2.4); sail.lineTo(1.5, 0.2);
  const sm = mesh(new THREE.ShapeGeometry(sail), mat("#fff8ea", { side: THREE.DoubleSide }), 0.38, 0.95, 0);
  g.add(sm);
  return g;
}

function starfish(color) {
  const s = new THREE.Shape();
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2;
    const rr = i % 2 ? 0.12 : 0.32;
    if (i === 0) s.moveTo(Math.cos(a) * rr, Math.sin(a) * rr);
    else s.lineTo(Math.cos(a) * rr, Math.sin(a) * rr);
  }
  const g = new THREE.ExtrudeGeometry(s, { depth: 0.06, bevelEnabled: false });
  g.rotateX(-Math.PI / 2);
  return mesh(g, mat(color), 0, 0, 0, false);
}

function mergeStatic(root) {
  root.updateMatrixWorld(true);
  const buckets = new Map();
  const remove = [];
  const visit = (o) => {
    if (o.userData.dynamic) return;
    for (const c of o.children) visit(c);
    const m = o;
    if (!m.isMesh || m.isInstancedMesh || Array.isArray(m.material)) return;
    const material = m.material;
    const g = m.geometry.index ? m.geometry.toNonIndexed() : m.geometry.clone();
    g.applyMatrix4(m.matrixWorld);
    for (const name of Object.keys(g.attributes)) if (name !== "position" && name !== "normal" && name !== "color") g.deleteAttribute(name);
    if (!material.vertexColors && g.attributes.color) g.deleteAttribute("color");
    if (material.vertexColors && !g.attributes.color) return;
    if (!g.attributes.normal) g.computeVertexNormals();
    g.clearGroups();
    const key = `${material.uuid}|${m.castShadow ? 1 : 0}|${m.receiveShadow ? 1 : 0}`;
    let b = buckets.get(key);
    if (!b) {
      b = { mat: material, geos: [], cast: m.castShadow, receive: m.receiveShadow };
      buckets.set(key, b);
    }
    b.geos.push(g);
    remove.push(m);
  };
  visit(root);
  const merged = [];
  for (const b of buckets.values()) {
    const geo = b.geos.length === 1 ? b.geos[0] : mergeGeometries(b.geos, false);
    if (!geo) continue;
    const mm = new THREE.Mesh(geo, b.mat);
    mm.castShadow = b.cast;
    mm.receiveShadow = b.receive;
    merged.push(mm);
    if (b.geos.length > 1) b.geos.forEach((g) => g.dispose());
  }
  const mergedMats = new Set(merged.map((m) => m.material));
  for (const m of remove) if (mergedMats.has(m.material)) m.parent?.remove(m);
  merged.forEach((m) => root.add(m));
}

export function buildIsland(def, labels) {
  const th = def.theme;
  const seed = def.id.split("").reduce((a, c) => a * 31 + c.charCodeAt(0), 7) >>> 0;
  const r = mulberry32(seed);
  const group = new THREE.Group();
  const colliders = [];
  const npcs = [];
  const smoke = [];
  const ups = [];

  // Основной рельеф острова
  const baseGeo = tintVerts(jitter(new THREE.CylinderGeometry(17, 22.5, 6, 40, 3), 0.42, seed, 0.1), th.sand, 0.07, seed);
  group.add(mesh(baseGeo, mat("#ffffff", { vc: true }), 0, -2.6, 0, false, true));
  const topGeo = tintVerts(jitter(new THREE.CylinderGeometry(13, 15.6, 1.2, 36, 1), 0.3, seed + 1, 0.04), th.grass, 0.06, seed + 1);
  group.add(mesh(topGeo, mat("#ffffff", { vc: true }), 0, 0.6, 0, false, true));

  const dummy = new THREE.Object3D();
  if (def.id !== "spaceport" && def.id !== "lunar_crater") {
    const tuftGeo = new THREE.ConeGeometry(0.1, 0.35, 4);
    const tufts = new THREE.InstancedMesh(tuftGeo, mat(def.id === "frost" ? "#dfe9f2" : th.leaf2), 46);
    for (let i = 0; i < 46; i++) {
      const a = r() * Math.PI * 2, rr = 2 + r() * 10.5;
      dummy.position.set(Math.cos(a) * rr, 1.33, Math.sin(a) * rr);
      dummy.rotation.set((r() - 0.5) * 0.4, r() * 3, (r() - 0.5) * 0.4);
      dummy.scale.setScalar(0.7 + r() * 0.8);
      dummy.updateMatrix();
      tufts.setMatrixAt(i, dummy.matrix);
    }
    group.add(tufts);
  }

  // Каменная дорожка к пирсу
  for (let i = 0; i < 6; i++) {
    const st = mesh(new THREE.CylinderGeometry(0.55, 0.6, 0.1, 7), mat(shade(th.rock, 0.15)), 4.2 + i * 1.5, 1.22, i % 2 ? 0.25 : -0.25, false, true);
    st.rotation.y = r() * 3;
    group.add(st);
  }

  // Пирс
  const plankMat = new THREE.MeshLambertMaterial({ color: "#ffffff", flatShading: true });
  const nPl = Math.floor((PIER.x1 - PIER.x0) / 0.62) + 1;
  const planks = new THREE.InstancedMesh(new THREE.BoxGeometry(0.56, 0.12, PIER.hw * 2 + 0.1), plankMat, nPl);
  const wc = new THREE.Color();
  for (let i = 0; i < nPl; i++) {
    dummy.position.set(PIER.x0 + i * 0.62, PIER.y - 0.06, (r() - 0.5) * 0.06);
    dummy.rotation.set(0, (r() - 0.5) * 0.03, 0);
    dummy.scale.set(1, 1, 1);
    dummy.updateMatrix();
    planks.setMatrixAt(i, dummy.matrix);
    planks.setColorAt(i, wc.set(th.wood).multiplyScalar(0.85 + r() * 0.3));
  }
  planks.castShadow = true;
  planks.receiveShadow = true;
  group.add(planks);
  for (let x = 13; x <= PIER.x1; x += 3) {
    for (const z of [-PIER.hw + 0.1, PIER.hw - 0.1]) {
      group.add(mesh(new THREE.CylinderGeometry(0.15, 0.17, 4.2, 6), mat(shade(th.wood, -0.1)), x, -1.2, z));
    }
  }
  group.add(mesh(new THREE.BoxGeometry(0.12, 1.7, 0.12), mat(shade(th.wood, -0.1)), PIER.x1 - 0.3, PIER.y + 0.85, PIER.hw - 0.15));
  group.add(mesh(new THREE.BoxGeometry(0.32, 0.36, 0.32), mat("#ffe08a", { emissive: "#ffc040", ei: 1 }), PIER.x1 - 0.3, PIER.y + 1.85, PIER.hw - 0.15, false));
  const crate = mesh(new THREE.BoxGeometry(0.7, 0.7, 0.7), mat(shade(th.wood, 0.08)), 15, PIER.y + 0.35, -PIER.hw + 0.45);
  crate.rotation.y = 0.3;
  group.add(crate);
  colliders.push({ x: 15, z: -PIER.hw + 0.45, r: 0.5 });

  // Лодка и капитан у пирса
  const boatG = boat(def.id === "abyss" ? "#4a3a8a" : def.id === "volcano" ? "#3a2a2a" : def.id === "lunar_crater" ? "#1e3a8a" : "#c8463a", th.wood);
  boatG.position.set(21, 0, 3.4);
  boatG.userData.dynamic = true;
  group.add(boatG);
  const captain = npc("#1f3a6a", "#ffffff", "captain", "#1a2440");
  captain.root.position.set(-0.6, 0.62, 0);
  captain.root.rotation.y = Math.PI;
  boatG.add(captain.root);
  const capLbl = makeLabel("⛵ " + labels.boat);
  capLbl.position.set(-0.6, 3.4, 0);
  boatG.add(capLbl);
  npcs.push({ kind: "boat", x: 21, z: 0.9, rig: captain });
  ups.push((t0, _dt, amp) => {
    boatG.position.y = waveHeight(21, 3.4, t0, amp) * 0.9 - 0.05;
    boatG.rotation.z = Math.sin(t0 * 1.3) * 0.04;
    boatG.rotation.x = Math.sin(t0 * 1.05) * 0.03;
  });

  // Лавки торговца и снастей (кроме космодрома, где нет рыбалки)
  if (def.id !== "spaceport") {
    const isLunar = def.id === "lunar_crater";
    const merchant = stall(isLunar ? "#e2e8f0" : "#ffffff", isLunar ? "#0284c7" : "#2a8ae0", th.wood, (isLunar ? "💎 " : "💰 ") + labels.merchant);
    merchant.position.set(6.5, 1.2, 6.3);
    merchant.rotation.y = Math.PI;
    group.add(merchant);
    const mRig = npc(isLunar ? "#0284c7" : "#3a7bd5", isLunar ? "#38bdf8" : "#e03a3a", "cap");
    mRig.root.userData.dynamic = true;
    mRig.root.position.set(0, 0, -0.75);
    merchant.add(mRig.root);
    for (let i = 0; i < 3; i++) {
      const cr = mesh(new THREE.BoxGeometry(0.6, 0.35, 0.5), mat(shade(th.wood, 0.1)), -1.0 + i * 0.75, 1.3, 0.05);
      merchant.add(cr);
      merchant.add(mesh(new THREE.BoxGeometry(0.42, 0.12, 0.2), mat(["#ffb02e", "#4aa8ff", "#5ddc5d"][i]), -1.0 + i * 0.75, 1.5, 0.05, false));
    }
    npcs.push({ kind: "merchant", x: 6.5, z: 4.4, rig: mRig });
    colliders.push({ x: 5.5, z: 6.7, r: 1.35 }, { x: 7.5, z: 6.7, r: 1.35 });

    const shop = stall(isLunar ? "#38bdf8" : "#ffd23a", isLunar ? "#1e3a8a" : "#2fa84a", th.wood, (isLunar ? "🌕 " : "🎣 ") + labels.shop);
    shop.position.set(6.5, 1.2, -6.3);
    group.add(shop);
    const sRig = npc(isLunar ? "#1e3a8a" : "#2fa84a", isLunar ? "#7dd3fc" : "#f0c030", "bucket");
    sRig.root.userData.dynamic = true;
    sRig.root.position.set(0, 0, -0.75);
    shop.add(sRig.root);
    for (let i = 0; i < 4; i++) {
      const rd = mesh(new THREE.CylinderGeometry(0.03, 0.05, 2.6, 5), mat(["#d8b45a", "#2a2a2e", "#ff6a8a", "#8ad8ff"][i]), 1.85, 1.3, -0.2 + i * 0.2);
      rd.rotation.z = -0.25;
      shop.add(rd);
    }
    shop.add(mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.8, 10), mat(shade(th.wood, -0.05)), -2.1, 0.4, 0.2));
    npcs.push({ kind: "shop", x: 6.5, z: -4.4, rig: sRig });
    colliders.push({ x: 5.5, z: -6.7, r: 1.35 }, { x: 7.5, z: -6.7, r: 1.35 }, { x: 4.4, z: -6.1, r: 0.5 });
  }

  // Помощник размещения декораций
  const occupied = [...colliders, { x: SPAWN.x, z: 0, r: 2.5 }, { x: 6.5, z: 4.4, r: 1.6 }, { x: 6.5, z: -4.4, r: 1.6 }];
  const place = (rMin, rMax, minD) => {
    for (let k = 0; k < 50; k++) {
      const a = r() * Math.PI * 2;
      const rr = rMin + r() * (rMax - rMin);
      const x = Math.cos(a) * rr, z = Math.sin(a) * rr;
      if (x > -1.5 && Math.abs(z) < 3.8) continue;
      if (occupied.some((o) => Math.hypot(o.x - x, o.z - z) < o.r + minD)) continue;
      return { x, z };
    }
    return null;
  };
  const addProp = (obj, rMin, rMax, col, minD = 1.6, y = 1.2) => {
    const p = place(rMin, rMax, minD);
    if (!p) return null;
    obj.position.set(p.x, y, p.z);
    obj.rotation.y = r() * Math.PI * 2;
    group.add(obj);
    occupied.push({ x: p.x, z: p.z, r: Math.max(col, 0.8) });
    if (col > 0) colliders.push({ x: p.x, z: p.z, r: col });
    return obj;
  };

  // ── Уникальные объекты каждого острова ──
  if (def.id === "sunny") {
    const lh = new THREE.Group();
    for (let i = 0; i < 5; i++) lh.add(mesh(new THREE.CylinderGeometry(1.0 - i * 0.12, 1.1 - i * 0.12, 1.4, 12), mat(i % 2 ? "#ffffff" : "#e0403a"), 0, 0.7 + i * 1.4, 0));
    lh.add(mesh(new THREE.CylinderGeometry(0.75, 0.75, 0.15, 12), mat("#3a3a3a"), 0, 7.1, 0));
    const lamp = mesh(new THREE.CylinderGeometry(0.45, 0.45, 0.8, 8), mat("#fff2a0", { emissive: "#ffd040", ei: 1.2 }), 0, 7.6, 0, false);
    lamp.userData.dynamic = true;
    lh.add(lamp);
    lh.add(mesh(new THREE.ConeGeometry(0.7, 0.8, 8), mat("#e0403a"), 0, 8.4, 0));
    lh.position.set(-9.5, 1.2, -7);
    group.add(lh);
    colliders.push({ x: -9.5, z: -7, r: 1.3 });
    occupied.push({ x: -9.5, z: -7, r: 2.2 });
    ups.push((t0) => (lamp.material.emissiveIntensity = 1 + Math.sin(t0 * 3) * 0.3));

    const fire = new THREE.Group();
    for (let i = 0; i < 4; i++) {
      const lg = mesh(new THREE.CylinderGeometry(0.09, 0.09, 1.0, 5), mat("#6a4026"), 0, 0.1, 0);
      lg.rotation.z = Math.PI / 2;
      lg.rotation.y = (i / 4) * Math.PI;
      fire.add(lg);
    }
    const flame = mesh(new THREE.ConeGeometry(0.32, 0.9, 6), mat("#ffb02e", { emissive: "#ff7a1a", ei: 1.2 }), 0, 0.55, 0, false);
    const flame2 = mesh(new THREE.ConeGeometry(0.18, 0.6, 6), mat("#fff2a0", { emissive: "#ffe060", ei: 1.2 }), 0, 0.45, 0, false);
    flame.userData.dynamic = true;
    flame2.userData.dynamic = true;
    fire.add(flame, flame2);
    fire.position.set(-5, 1.2, 5);
    group.add(fire);
    colliders.push({ x: -5, z: 5, r: 0.7 });
    occupied.push({ x: -5, z: 5, r: 2 });
    for (let i = 0; i < 3; i++) {
      const a = (i / 3) * Math.PI * 2 + 0.4;
      const lgS = mesh(new THREE.CylinderGeometry(0.22, 0.22, 1.3, 6), mat(th.wood), -5 + Math.cos(a) * 1.6, 1.42, 5 + Math.sin(a) * 1.6);
      lgS.rotation.z = Math.PI / 2;
      lgS.rotation.y = -a;
      group.add(lgS);
    }
    ups.push((t0) => {
      flame.scale.set(1 + Math.sin(t0 * 13) * 0.08, 1 + Math.sin(t0 * 9) * 0.15, 1 + Math.cos(t0 * 11) * 0.08);
      flame2.scale.y = 1 + Math.sin(t0 * 15) * 0.2;
    });

    const um = new THREE.Group();
    um.add(mesh(new THREE.CylinderGeometry(0.05, 0.05, 2.4, 5), mat("#ffffff"), 0, 1.2, 0));
    for (let i = 0; i < 8; i++) {
      const seg = mesh(new THREE.ConeGeometry(1.4, 0.5, 3, 1, true, (i / 8) * Math.PI * 2, Math.PI / 4), mat(i % 2 ? "#ffffff" : "#ff5a5a", { side: THREE.DoubleSide }), 0, 2.4, 0);
      um.add(seg);
    }
    um.add(mesh(new THREE.BoxGeometry(1.0, 0.04, 1.9), mat("#4ab0ff"), 0.9, 0.03, 0.2, false, true));
    um.position.set(-2, 0.4, 15.4);
    group.add(um);
    colliders.push({ x: -2, z: 15.4, r: 0.4 });
  }

  if (def.id === "coral") {
    const hut = new THREE.Group();
    hut.add(mesh(new THREE.CylinderGeometry(1.6, 1.7, 2.0, 10), mat("#d8b07a"), 0, 1.0, 0));
    hut.add(mesh(new THREE.ConeGeometry(2.4, 1.8, 10), mat("#c89a4a"), 0, 2.9, 0));
    hut.add(mesh(new THREE.BoxGeometry(0.7, 1.2, 0.1), mat("#5a3a1a"), 0, 0.6, 1.66, false));
    hut.position.set(-8, 1.2, -6);
    hut.rotation.y = 0.8;
    group.add(hut);
    colliders.push({ x: -8, z: -6, r: 1.9 });
    occupied.push({ x: -8, z: -6, r: 2.6 });
    const coralCols = ["#ff5a8a", "#ff9a3a", "#b46cff", "#ffd23a", "#3affd0"];
    for (let i = 0; i < 16; i++) {
      const a = r() * Math.PI * 2;
      if (Math.abs(Math.atan2(Math.sin(a), Math.cos(a))) < 0.25) continue;
      const rr = 18.6 + r() * 6;
      const c = new THREE.Group();
      const col = coralCols[i % coralCols.length];
      for (let k = 0; k < 4; k++) {
        const br = mesh(new THREE.CylinderGeometry(0.06, 0.12, 1.3 + r(), 5), mat(col, { emissive: col, ei: 0.15 }), (r() - 0.5) * 0.6, 0.5, (r() - 0.5) * 0.6, false);
        br.rotation.z = (r() - 0.5) * 0.9;
        br.rotation.x = (r() - 0.5) * 0.9;
        c.add(br);
        c.add(mesh(new THREE.SphereGeometry(0.14, 5, 4), mat(col), br.position.x + Math.sin(-br.rotation.z) * 0.6, 1.1, br.position.z + Math.sin(br.rotation.x) * 0.6, false));
      }
      c.position.set(Math.cos(a) * rr, -0.7, Math.sin(a) * rr);
      group.add(c);
    }
    for (let i = 0; i < 6; i++) {
      const a = r() * Math.PI * 2;
      const sf = starfish(["#ff7a3a", "#ff5a8a", "#ffd23a"][i % 3]);
      sf.position.set(Math.cos(a) * (15.2 + r() * 1.2), 0.42, Math.sin(a) * (15.2 + r() * 1.2));
      sf.rotation.y = r() * 3;
      group.add(sf);
    }
  }

  if (def.id === "frost") {
    const igloo = new THREE.Group();
    igloo.add(mesh(new THREE.SphereGeometry(2, 12, 7, 0, Math.PI * 2, 0, Math.PI / 2), mat("#f4fbff"), 0, 0, 0));
    const door = mesh(new THREE.CylinderGeometry(0.75, 0.75, 1.4, 10, 1, false, 0, Math.PI), mat("#e4f0fa"), 0, 0, 1.6);
    door.rotation.x = Math.PI / 2;
    door.rotation.z = Math.PI / 2;
    igloo.add(door);
    igloo.add(mesh(new THREE.BoxGeometry(0.9, 0.9, 0.2), mat("#2a3a4a"), 0, 0.45, 2.25, false));
    igloo.position.set(-8.5, 1.2, -6);
    igloo.rotation.y = 0.9;
    group.add(igloo);
    colliders.push({ x: -8.5, z: -6, r: 2.2 });
    occupied.push({ x: -8.5, z: -6, r: 3 });

    const sm = new THREE.Group();
    sm.add(mesh(new THREE.SphereGeometry(0.7, 10, 8), mat("#ffffff"), 0, 0.6, 0));
    sm.add(mesh(new THREE.SphereGeometry(0.5, 10, 8), mat("#ffffff"), 0, 1.55, 0));
    sm.add(mesh(new THREE.SphereGeometry(0.36, 10, 8), mat("#ffffff"), 0, 2.25, 0));
    const nose = mesh(new THREE.ConeGeometry(0.07, 0.4, 6), mat("#ff8a2a"), 0, 2.25, 0.5, false);
    nose.rotation.x = Math.PI / 2;
    sm.add(nose);
    sm.add(mesh(new THREE.CylinderGeometry(0.25, 0.28, 0.4, 8), mat("#2a2a2a"), 0, 2.65, 0));
    sm.add(mesh(new THREE.TorusGeometry(0.42, 0.08, 5, 12), mat("#e03a3a"), 0, 1.95, 0));
    sm.position.set(-4, 1.2, 6);
    sm.rotation.y = 0.6;
    group.add(sm);
    colliders.push({ x: -4, z: 6, r: 0.8 });
    occupied.push({ x: -4, z: 6, r: 1.8 });

    for (let i = 0; i < 9; i++) {
      const a = r() * Math.PI * 2;
      if (Math.abs(Math.atan2(Math.sin(a), Math.cos(a))) < 0.3) continue;
      const rr = 40 + r() * 70;
      const ib = mesh(jitter(new THREE.IcosahedronGeometry(2 + r() * 4, 0), 0.6, i + 50), mat(i % 2 ? "#f4fbff" : "#cfe9f8"), Math.cos(a) * rr, 0.2, Math.sin(a) * rr, false);
      ib.scale.y = 0.75;
      ib.userData.dynamic = true;
      group.add(ib);
      const ph = r() * 6;
      ups.push((t0) => (ib.position.y = Math.sin(t0 * 0.6 + ph) * 0.25));
    }
    for (let i = 0; i < 6; i++) {
      const a = Math.PI * 0.55 + (i / 5) * Math.PI * 0.9 + r() * 0.2;
      const rr = 85 + r() * 40;
      const h0 = 30 + r() * 25;
      const mt = new THREE.Group();
      mt.add(mesh(jitter(new THREE.ConeGeometry(22 + r() * 10, h0, 9, 2), 1.5, i + 70), mat("#6a7a8e"), 0, h0 / 2 - 2, 0, false));
      mt.add(mesh(new THREE.ConeGeometry(9, h0 * 0.35, 9), mat("#ffffff"), 0, h0 - 2 - h0 * 0.17, 0, false));
      mt.position.set(Math.cos(a) * rr, 0, Math.sin(a) * rr);
      group.add(mt);
    }
  }

  if (def.id === "volcano") {
    const v = new THREE.Group();
    v.add(mesh(jitter(new THREE.CylinderGeometry(7, 30, 36, 14, 4, true), 1.6, 99), mat("#2e2424"), 0, 18 - 2, 0, false));
    const lava = mesh(new THREE.CircleGeometry(7.2, 14), mat("#ff6a1a", { emissive: "#ff4a00", ei: 1.4 }), 0, 33.5, 0, false);
    lava.rotation.x = -Math.PI / 2;
    v.add(lava);
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2 + 0.3;
      const st = mesh(new THREE.BoxGeometry(1.4, 40, 0.6), mat("#ff5a1a", { emissive: "#ff3a00", ei: 1.1 }), Math.cos(a) * 18.5, 16, Math.sin(a) * 18.5, false);
      st.rotation.set(0, -a, 0.568);
      v.add(st);
    }
    v.position.set(-70, 0, -55);
    group.add(v);
    smoke.push(new THREE.Vector3(-70, 36, -55));
    for (let i = 0; i < 4; i++) {
      const lp = mesh(new THREE.CircleGeometry(0.9 + r() * 0.6, 9), mat("#ff6a1a", { emissive: "#ff4a00", ei: 1.3 }), 0, 0, 0, false);
      lp.rotation.x = -Math.PI / 2;
      const pp = place(4, 11, 1.4);
      if (!pp) continue;
      lp.position.set(pp.x, 1.24, pp.z);
      group.add(lp);
      const ring = mesh(new THREE.TorusGeometry(1.1, 0.25, 4, 10), mat("#1e1818"), pp.x, 1.24, pp.z, false);
      ring.rotation.x = Math.PI / 2;
      group.add(ring);
      colliders.push({ x: pp.x, z: pp.z, r: 1.0 });
      occupied.push({ x: pp.x, z: pp.z, r: 1.6 });
      smoke.push(new THREE.Vector3(pp.x, 1.4, pp.z));
    }
    for (let i = 0; i < 6; i++) {
      const sp = mesh(new THREE.ConeGeometry(0.4 + r() * 0.3, 1.8 + r() * 1.6, 5), mat("#1a1420", { emissive: "#2a0a3a", ei: 0.4 }), 0, 0, 0);
      addProp(sp, 13.5, 16, 0.5, 1.2, 1.0);
    }
  }

  if (def.id === "abyss") {
    const ring = mesh(new THREE.TorusGeometry(16, 1.1, 8, 48), mat("#3affd0", { emissive: "#3affd0", ei: 1 }), -42, 6, -30, false);
    ring.lookAt(0, 6, 0);
    ring.userData.dynamic = true;
    group.add(ring);
    ups.push((t0) => (ring.material.emissiveIntensity = 0.8 + Math.sin(t0 * 1.5) * 0.3));
    for (let i = 0; i < 7; i++) {
      const a = (i / 7) * Math.PI * 2 + 0.5;
      const rr = 32 + r() * 22;
      const fr = new THREE.Group();
      const cone = mesh(jitter(new THREE.ConeGeometry(2.4, 4, 7), 0.3, i + 30), mat(th.rock), 0, -2, 0, false);
      cone.rotation.x = Math.PI;
      fr.add(cone);
      fr.add(mesh(new THREE.CylinderGeometry(2.4, 2.4, 0.4, 7), mat(th.grass), 0, 0.1, 0, false));
      const cr = crystal(i % 2 ? "#c6a6ff" : "#3affd0", r, 0.8);
      cr.position.y = 0.2;
      fr.add(cr);
      fr.position.set(Math.cos(a) * rr, 9 + r() * 8, Math.sin(a) * rr);
      fr.userData.dynamic = true;
      group.add(fr);
      const ph = r() * 6;
      const y0 = fr.position.y;
      ups.push((t0) => {
        fr.position.y = y0 + Math.sin(t0 * 0.5 + ph) * 0.8;
        fr.rotation.y = t0 * 0.05 + ph;
      });
    }
    for (let i = 0; i < 6; i++) {
      const pl = new THREE.Group();
      const h0 = 2 + r() * 3;
      pl.add(mesh(new THREE.CylinderGeometry(0.45, 0.5, h0, 8), mat("#b8b0d0"), 0, h0 / 2, 0));
      pl.add(mesh(new THREE.BoxGeometry(1.2, 0.3, 1.2), mat("#a8a0c4"), 0, h0 + 0.15, 0));
      addProp(pl, 7, 12, 0.6, 1.4);
    }
    for (let i = 0; i < 6; i++) addProp(crystal(i % 2 ? "#c6a6ff" : "#3affd0", r), 4, 15.5, 0.7, 1.2);
  }

  if (def.id === "sunken") {
    const temple = new THREE.Group();
    for (let i = 0; i < 7; i++) {
      const a = (i / 7) * Math.PI * 2;
      const h0 = 1.6 + r() * 3.4;
      const col = new THREE.Group();
      col.add(mesh(new THREE.CylinderGeometry(0.42, 0.5, h0, 10), mat("#d8d0b4"), 0, h0 / 2, 0));
      for (let k = 1; k < Math.floor(h0 / 0.9); k++) col.add(mesh(new THREE.CylinderGeometry(0.52, 0.52, 0.1, 10), mat("#c8c0a4"), 0, k * 0.9, 0, false));
      col.add(mesh(new THREE.BoxGeometry(1.25, 0.28, 1.25), mat("#c8c0a4"), 0, h0 + 0.1, 0));
      col.position.set(Math.cos(a) * 4.2, 0, Math.sin(a) * 4.2);
      col.rotation.z = (r() - 0.5) * 0.14;
      temple.add(col);
      colliders.push({ x: -7 + Math.cos(a) * 4.2, z: -5 + Math.sin(a) * 4.2, r: 0.62 });
    }
    temple.position.set(-7, 1.2, -5);
    group.add(temple);
    occupied.push({ x: -7, z: -5, r: 6 });
    const head = new THREE.Group();
    head.add(mesh(jitter(new THREE.BoxGeometry(2.3, 2.6, 2.1), 0.12, 61), mat("#cfc8ac"), 0, 1.3, 0));
    head.add(mesh(new THREE.BoxGeometry(2.5, 0.5, 0.35), mat("#b8b094"), 0, 2.2, 1.0, false));
    for (const s of [-1, 1]) head.add(mesh(new THREE.BoxGeometry(0.5, 0.3, 0.2), mat("#4a5a4a"), 0.55 * s, 1.6, 1.06, false));
    head.add(mesh(new THREE.BoxGeometry(2.0, 0.35, 0.2), mat("#4a5a4a"), 0, 0.75, 1.06, false));
    head.rotation.z = 0.22;
    addProp(head, 6, 11, 1.5, 2.6);
    for (let i = 0; i < 5; i++) {
      const slab = mesh(jitter(new THREE.BoxGeometry(1.8 + r(), 0.4, 1.2 + r()), 0.1, i + 71), mat("#c8c0a4"), 0, 0, 0, true, true);
      slab.rotation.z = (r() - 0.5) * 0.3;
      addProp(slab, 5, 14, 0.9, 1.4, 1.35);
    }
    for (let i = 0; i < 10; i++) {
      const a = r() * Math.PI * 2;
      if (Math.abs(Math.atan2(Math.sin(a), Math.cos(a))) < 0.25) continue;
      const rr = 19 + r() * 9;
      const h0 = 3 + r() * 5;
      const sc = mesh(new THREE.CylinderGeometry(0.4, 0.5, h0, 9), mat("#b8b89c"), Math.cos(a) * rr, -1.5, Math.sin(a) * rr, false);
      sc.rotation.z = (r() - 0.5) * 0.25;
      group.add(sc);
    }
  }

  if (def.id === "storm") {
    const tower = new THREE.Group();
    for (let i = 0; i < 4; i++) {
      const leg = mesh(new THREE.CylinderGeometry(0.1, 0.14, 7, 5), mat("#3a4252"), 0, 3.5, 0);
      const a = (i / 4) * Math.PI * 2 + 0.78;
      leg.position.set(Math.cos(a) * 1.1, 3.3, Math.sin(a) * 1.1);
      leg.rotation.z = -Math.cos(a) * 0.14;
      leg.rotation.x = Math.sin(a) * 0.14;
      tower.add(leg);
    }
    for (let i = 1; i <= 3; i++) {
      const trRing = mesh(new THREE.TorusGeometry(1.0 - i * 0.12, 0.07, 4, 10), mat("#4a5464"), 0, i * 1.8, 0, false);
      trRing.rotation.x = Math.PI / 2;
      tower.add(trRing);
    }
    tower.add(mesh(new THREE.CylinderGeometry(0.06, 0.1, 3, 5), mat("#6a7484"), 0, 8, 0));
    const orb = mesh(new THREE.IcosahedronGeometry(0.55, 0), mat("#ffe14d", { emissive: "#ffe14d", ei: 1.4 }), 0, 9.6, 0, false);
    orb.userData.dynamic = true;
    tower.add(orb);
    tower.position.set(-8, 1.2, -5.5);
    group.add(tower);
    colliders.push({ x: -8, z: -5.5, r: 1.5 });
    occupied.push({ x: -8, z: -5.5, r: 3 });
    ups.push((t0) => {
      const flash = Math.pow(Math.max(0, Math.sin(t0 * 1.7)), 8);
      orb.material.emissiveIntensity = 0.8 + flash * 5;
      orb.scale.setScalar(1 + flash * 0.35);
      orb.rotation.y = t0 * 0.9;
    });
    for (let i = 0; i < 4; i++) {
      const wreck = new THREE.Group();
      const hl = 3 + r() * 2;
      wreck.add(mesh(new THREE.CylinderGeometry(0.11, 0.16, hl, 6), mat("#3a3a44"), 0, hl / 2, 0));
      const sail = new THREE.Shape();
      sail.moveTo(0, 0.4); sail.lineTo(0, hl * 0.8); sail.lineTo(1.1, hl * 0.35);
      wreck.add(mesh(new THREE.ShapeGeometry(sail), mat("#6a6a74", { side: THREE.DoubleSide, opacity: 0.9 }), 0.05, 0, 0));
      wreck.rotation.z = (r() - 0.5) * 0.5;
      addProp(wreck, 5, 14, 0.5, 1.8);
    }
    for (let i = 0; i < 5; i++) addProp(rock("#3a4252", 0.5 + r() * 0.6, i + 81), 4, 13, 0.7, 1.4, 1.2);
  }

  if (def.id === "celestial") {
    const gate = new THREE.Group();
    const ring = mesh(new THREE.TorusGeometry(2.6, 0.22, 7, 28), mat("#ffd6a0", { emissive: "#ffb46a", ei: 0.9 }), 0, 3.4, 0, false);
    ring.userData.dynamic = true;
    gate.add(ring);
    gate.add(mesh(new THREE.CylinderGeometry(0.3, 0.42, 1.6, 8), mat("#8a7ab8"), 0, 0.8, 0));
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      gate.add(mesh(new THREE.OctahedronGeometry(0.2, 0), mat("#ffffff", { emissive: "#ffffff", ei: 1 }), Math.cos(a) * 2.6, 3.4 + Math.sin(a) * 2.6, 0, false));
    }
    gate.position.set(-8, 1.2, -5);
    gate.rotation.y = 0.5;
    group.add(gate);
    colliders.push({ x: -8, z: -5, r: 0.9 });
    occupied.push({ x: -8, z: -5, r: 3.4 });
    ups.push((t0) => {
      ring.rotation.z = t0 * 0.25;
      ring.material.emissiveIntensity = 0.7 + Math.sin(t0 * 1.6) * 0.3;
    });
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2 + r();
      const rr = 26 + r() * 26;
      const isle = new THREE.Group();
      const rad = 2 + r() * 3;
      const cone = mesh(jitter(new THREE.ConeGeometry(rad, rad * 2.2, 8), 0.25, i + 91), mat("#8a7ab8"), 0, -rad * 1.1, 0, false);
      cone.rotation.x = Math.PI;
      isle.add(cone);
      isle.add(mesh(new THREE.CylinderGeometry(rad, rad, 0.4, 8), mat("#b9a6f0"), 0, 0.1, 0, false));
      for (let k = 0; k < 3; k++) {
        const trCol = r() < 0.5 ? "#ff9ac8" : "#a6c8ff";
        const tree = new THREE.Group();
        tree.add(mesh(new THREE.CylinderGeometry(0.1, 0.15, 1.1, 5), mat("#6a5a8a"), 0, 0.55, 0));
        tree.add(mesh(new THREE.IcosahedronGeometry(0.75, 0), mat(trCol, { emissive: trCol, ei: 0.3 }), 0, 1.5, 0));
        tree.position.set((r() - 0.5) * rad, 0.3, (r() - 0.5) * rad);
        isle.add(tree);
      }
      isle.position.set(Math.cos(a) * rr, 6 + r() * 12, Math.sin(a) * rr);
      isle.userData.dynamic = true;
      group.add(isle);
      const ph = r() * 6;
      const y0 = isle.position.y;
      ups.push((t0) => {
        isle.position.y = y0 + Math.sin(t0 * 0.4 + ph) * 1.1;
        isle.rotation.y = t0 * 0.04 + ph;
      });
    }
    for (let i = 0; i < 7; i++) {
      const a = r() * Math.PI * 2;
      if (Math.abs(Math.atan2(Math.sin(a), Math.cos(a))) < 0.25) continue;
      const rr = 19 + r() * 8;
      const pad = mesh(new THREE.CircleGeometry(1.1 + r() * 0.8, 12), mat(r() < 0.5 ? "#ff9ac8" : "#a6c8ff", { emissive: "#ffd0f0", ei: 0.5, side: THREE.DoubleSide }), Math.cos(a) * rr, 0.08, Math.sin(a) * rr, false);
      pad.rotation.x = -Math.PI / 2;
      pad.userData.dynamic = true;
      group.add(pad);
      const px = pad.position.x, pz = pad.position.z;
      ups.push((t0, _dt, amp) => (pad.position.y = waveHeight(px, pz, t0, amp) + 0.08));
    }
    for (let i = 0; i < 5; i++) addProp(crystal(i % 2 ? "#ffd6a0" : "#c6b0ff", r, 0.9), 4, 13, 0.6, 1.4);
  }

  // ── Космодром «Астра» (ракета на Луну в самом центре острова) ──
  if (def.id === "spaceport") {
    const pad = new THREE.Group();
    pad.add(mesh(new THREE.CylinderGeometry(5.6, 6.2, 0.35, 24), mat("#334155"), 0, 0.17, 0, true, true));
    pad.add(mesh(new THREE.CylinderGeometry(4.2, 4.4, 0.42, 24), mat("#1e293b"), 0, 0.2, 0, false, true));
    const warnRing = mesh(new THREE.RingGeometry(4.3, 4.9, 24), mat("#f59e0b", { side: THREE.DoubleSide }), 0, 0.4, 0, false);
    warnRing.rotation.x = -Math.PI / 2;
    pad.add(warnRing);

    // Ферма обслуживания ракеты
    const gantry = new THREE.Group();
    for (const gx of [-0.9, 0.9]) {
      for (const gz of [-0.9, 0.9]) {
        gantry.add(mesh(new THREE.CylinderGeometry(0.12, 0.15, 13.5, 6), mat("#dc2626"), gx, 6.75, gz));
      }
    }
    for (let gy = 2; gy <= 12; gy += 2.5) {
      gantry.add(mesh(new THREE.BoxGeometry(2.1, 0.16, 2.1), mat("#ef4444"), 0, gy, 0));
    }
    gantry.add(mesh(new THREE.BoxGeometry(2.8, 0.25, 0.9), mat("#94a3b8"), 1.6, 8.5, 0));
    gantry.position.set(-3.2, 0.3, -1.8);
    pad.add(gantry);

    // Многоступенчатая ракета в центре (0, 0)
    const rocket = new THREE.Group();
    rocket.userData.dynamic = true;
    rocket.add(mesh(new THREE.CylinderGeometry(1.15, 1.35, 3.6, 16), mat("#f8fafc"), 0, 2.2, 0));
    rocket.add(mesh(new THREE.CylinderGeometry(1.17, 1.22, 0.65, 16), mat("#1e293b"), 0, 3.7, 0));
    rocket.add(mesh(new THREE.CylinderGeometry(1.05, 1.15, 3.4, 16), mat("#f8fafc"), 0, 5.7, 0));
    rocket.add(mesh(new THREE.CylinderGeometry(1.08, 1.08, 0.5, 16), mat("#ef4444"), 0, 6.8, 0));
    rocket.add(mesh(new THREE.ConeGeometry(1.08, 2.8, 16), mat("#ef4444"), 0, 8.8, 0));
    // Иллюминатор
    rocket.add(mesh(new THREE.SphereGeometry(0.38, 12, 10), mat("#38bdf8", { emissive: "#0284c7", ei: 0.8 }), 0.85, 5.8, 0, false));
    // 4 боковых ускорителя и стабилизатора
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
      const bx = Math.cos(a) * 1.45, bz = Math.sin(a) * 1.45;
      rocket.add(mesh(new THREE.CylinderGeometry(0.38, 0.46, 3.0, 10), mat("#e2e8f0"), bx, 1.9, bz));
      rocket.add(mesh(new THREE.ConeGeometry(0.38, 0.9, 10), mat("#ef4444"), bx, 3.85, bz));
      rocket.add(mesh(new THREE.CylinderGeometry(0.32, 0.42, 0.45, 8), mat("#334155"), bx, 0.28, bz));
    }
    // Главный реактивный факел
    const flame = mesh(new THREE.ConeGeometry(0.85, 1.8, 10), mat("#38bdf8", { emissive: "#38bdf8", ei: 1.5, opacity: 0.85 }), 0, 0.2, 0, false);
    flame.rotation.x = Math.PI;
    rocket.add(flame);

    const rLbl = makeLabel("🚀 " + (labels.rocket || t("npcRocket")), "rgba(15,23,42,0.88)", "#ffe066", 1.15);
    rLbl.position.set(0, 11.2, 0);
    rocket.add(rLbl);
    pad.add(rocket);

    // Сигнальные огни вокруг площадки
    const beacons = [];
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const bc = mesh(new THREE.SphereGeometry(0.22, 8, 6), mat("#f97316", { emissive: "#f97316", ei: 1.2 }), Math.cos(a) * 5.2, 0.48, Math.sin(a) * 5.2, false);
      bc.userData.dynamic = true;
      pad.add(bc);
      beacons.push(bc);
    }

    pad.position.set(0, 1.2, 0);
    group.add(pad);
    colliders.push({ x: 0, z: 0, r: 2.35 }, { x: -3.2, z: -1.8, r: 1.3 });
    occupied.push({ x: 0, z: 0, r: 6.2 });

    // Инженер запуска у ракеты
    const astro = npc("#f8fafc", "#38bdf8", "captain", "#334155");
    astro.root.userData.dynamic = true;
    astro.root.position.set(3.2, 1.2, 0);
    astro.root.rotation.y = Math.PI / 2;
    group.add(astro.root);
    npcs.push({ kind: "rocket", x: 2.6, z: 0, rig: astro });
    smoke.push(new THREE.Vector3(0, 1.4, 0), new THREE.Vector3(1.1, 1.3, 1.1));

    ups.push((t0) => {
      rocket.position.y = Math.sin(t0 * 4) * 0.03;
      flame.scale.set(1 + Math.sin(t0 * 20) * 0.12, 0.8 + Math.sin(t0 * 25) * 0.25, 1 + Math.cos(t0 * 20) * 0.12);
      beacons.forEach((b, idx) => {
        b.material.emissiveIntensity = 0.5 + 0.9 * Math.max(0, Math.sin(t0 * 4 + idx));
      });
    });

    // Топливные баки и радарная башня
    const tanks = new THREE.Group();
    for (const tz of [-1.4, 1.4]) {
      tanks.add(mesh(new THREE.CylinderGeometry(1.1, 1.1, 3.2, 12), mat("#e2e8f0"), 0, 1.6, tz));
      tanks.add(mesh(new THREE.SphereGeometry(1.1, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), mat("#e2e8f0"), 0, 3.2, tz));
      tanks.add(mesh(new THREE.CylinderGeometry(1.13, 1.13, 0.35, 12), mat("#0284c7"), 0, 2.1, tz));
    }
    tanks.position.set(-8.5, 1.2, 5.8);
    group.add(tanks);
    colliders.push({ x: -8.5, z: 4.4, r: 1.25 }, { x: -8.5, z: 7.2, r: 1.25 });

    const radar = new THREE.Group();
    radar.add(mesh(new THREE.CylinderGeometry(0.45, 0.65, 4.2, 8), mat("#475569"), 0, 2.1, 0));
    const dish = new THREE.Group();
    dish.userData.dynamic = true;
    dish.position.set(0, 4.5, 0);
    const bowl = mesh(new THREE.SphereGeometry(1.5, 12, 8, 0, Math.PI * 2, 0, Math.PI * 0.45), mat("#f8fafc", { side: THREE.DoubleSide }), 0, 0, 0);
    bowl.rotation.x = Math.PI * 0.65;
    dish.add(bowl);
    radar.add(dish);
    radar.position.set(-8.2, 1.2, -6.5);
    group.add(radar);
    colliders.push({ x: -8.2, z: -6.5, r: 0.9 });
    ups.push((t0) => {
      dish.rotation.y = t0 * 0.7;
    });
  }

  // ── Луна (Кратер Спокойствия — реалистичный лунный пейзаж без магических кристаллов) ──
  if (def.id === "lunar_crater") {
    // Земля в небе над Луной
    const earth = new THREE.Group();
    earth.userData.dynamic = true;
    earth.add(mesh(new THREE.SphereGeometry(14, 24, 18), mat("#1d4ed8", { emissive: "#1e3a8a", ei: 0.35 }), 0, 0, 0, false));
    earth.add(mesh(jitter(new THREE.IcosahedronGeometry(14.15, 1), 0.35, 42), mat("#22c55e"), 0, 0, 0, false));
    earth.position.set(-75, 58, -85);
    group.add(earth);
    ups.push((t0) => {
      earth.rotation.y = t0 * 0.06;
    });

    // Посадочный модуль для возврата на Землю
    const lander = new THREE.Group();
    lander.add(mesh(new THREE.CylinderGeometry(1.5, 1.8, 1.4, 8), mat("#f59e0b"), 0, 1.2, 0));
    lander.add(mesh(new THREE.SphereGeometry(1.35, 10, 8), mat("#e2e8f0"), 0, 2.4, 0));
    lander.add(mesh(new THREE.SphereGeometry(0.42, 8, 6), mat("#38bdf8", { emissive: "#0284c7", ei: 0.7 }), 1.15, 2.4, 0, false));
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
      const leg = mesh(new THREE.CylinderGeometry(0.08, 0.08, 1.8, 6), mat("#94a3b8"), Math.cos(a) * 1.5, 0.7, Math.sin(a) * 1.5);
      leg.rotation.z = -Math.cos(a) * 0.45;
      leg.rotation.x = Math.sin(a) * 0.45;
      lander.add(leg);
      lander.add(mesh(new THREE.CylinderGeometry(0.35, 0.35, 0.08, 8), mat("#64748b"), Math.cos(a) * 1.9, 0.05, Math.sin(a) * 1.9));
    }
    const eLbl = makeLabel("🌍 " + (labels.earthRocket || t("npcEarthRocket")), "rgba(15,23,42,0.88)", "#7dd3fc");
    eLbl.position.set(0, 4.3, 0);
    lander.add(eLbl);
    lander.position.set(-8.5, 1.2, 5.8);
    group.add(lander);
    const pilot = npc("#f8fafc", "#38bdf8", "captain", "#334155");
    pilot.root.userData.dynamic = true;
    pilot.root.position.set(-6.2, 1.2, 5.2);
    pilot.root.rotation.y = Math.PI * 0.4;
    group.add(pilot.root);
    npcs.push({ kind: "earth_rocket", x: -6.2, z: 5.2, rig: pilot });
    colliders.push({ x: -8.5, z: 5.8, r: 2.1 });
    occupied.push({ x: -8.5, z: 5.8, r: 3.2 });

    // Научный купол лунной базы и солнечные панели
    const hab = new THREE.Group();
    hab.add(mesh(new THREE.SphereGeometry(2.6, 14, 10, 0, Math.PI * 2, 0, Math.PI / 2), mat("#e2e8f0"), 0, 0, 0));
    hab.add(mesh(new THREE.BoxGeometry(1.4, 1.5, 1.6), mat("#94a3b8"), 2.2, 0.75, 0));
    hab.add(mesh(new THREE.BoxGeometry(0.12, 1.1, 0.9), mat("#38bdf8", { emissive: "#0284c7", ei: 0.6 }), 2.92, 0.7, 0, false));
    // Солнечные батареи
    for (const sz of [-3.4, 3.4]) {
      hab.add(mesh(new THREE.CylinderGeometry(0.08, 0.1, 1.4, 6), mat("#64748b"), -0.5, 0.7, sz));
      const panel = mesh(new THREE.BoxGeometry(2.2, 0.08, 1.2), mat("#1d4ed8", { emissive: "#1e3a8a", ei: 0.3 }), -0.5, 1.4, sz);
      panel.rotation.z = -0.3;
      hab.add(panel);
    }
    // Флаг экспедиции
    hab.add(mesh(new THREE.CylinderGeometry(0.04, 0.04, 2.8, 6), mat("#f8fafc"), 1.8, 1.4, 2.2));
    hab.add(mesh(new THREE.BoxGeometry(1.1, 0.65, 0.04), mat("#0284c7"), 2.35, 2.4, 2.2, false));
    hab.position.set(-8.2, 1.2, -5.8);
    group.add(hab);
    colliders.push({ x: -8.2, z: -5.8, r: 2.6 });
    occupied.push({ x: -8.2, z: -5.8, r: 4.2 });

    // Луноход (Lunar Rover)
    const rover = new THREE.Group();
    rover.add(mesh(new THREE.BoxGeometry(1.8, 0.35, 1.2), mat("#eab308"), 0, 0.55, 0));
    for (const rx of [-0.65, 0, 0.65]) {
      for (const rz of [-0.68, 0.68]) {
        const wh = mesh(new THREE.CylinderGeometry(0.28, 0.28, 0.2, 10), mat("#1e293b"), rx, 0.28, rz);
        wh.rotation.x = Math.PI / 2;
        rover.add(wh);
      }
    }
    rover.add(mesh(new THREE.CylinderGeometry(0.05, 0.05, 1.1, 6), mat("#cbd5e1"), 0.6, 1.2, 0));
    rover.add(mesh(new THREE.BoxGeometry(0.35, 0.25, 0.35), mat("#f8fafc"), 0.6, 1.75, 0));
    rover.position.set(-2.5, 1.2, -7.8);
    rover.rotation.y = 0.5;
    group.add(rover);
    colliders.push({ x: -2.5, z: -7.8, r: 1.1 });
    occupied.push({ x: -2.5, z: -7.8, r: 2.0 });

    // Реалистичные лунные кратеры на поверхности
    for (let i = 0; i < 7; i++) {
      const p = place(3.5, 12.5, 1.8);
      if (!p) continue;
      const rad = 0.9 + r() * 1.1;
      const cr = new THREE.Group();
      const rim = mesh(jitter(new THREE.TorusGeometry(rad, 0.26, 6, 16), 0.05, i + 301), mat("#64748b"), 0, 0.06, 0, true, true);
      rim.rotation.x = Math.PI / 2;
      cr.add(rim);
      const pit = mesh(new THREE.CircleGeometry(rad * 0.9, 14), mat("#334155"), 0, 0.02, 0, false, true);
      pit.rotation.x = -Math.PI / 2;
      cr.add(pit);
      cr.position.set(p.x, 1.2, p.z);
      group.add(cr);
      occupied.push({ x: p.x, z: p.z, r: rad + 0.4 });
    }

    // Серые реголитовые валуны
    for (let i = 0; i < 10; i++) {
      const sz = 0.45 + r() * 0.65;
      addProp(rock(i % 2 ? "#64748b" : "#475569", sz, i + 400), 4, 15, sz * 0.9, 1.2, 1.2);
    }
  }

  // Деревья и кусты (только для земных природных островов)
  if (def.id !== "spaceport" && def.id !== "lunar_crater") {
    const treeCount = def.id === "volcano" || def.id === "storm" ? 7 : 9;
    for (let i = 0; i < treeCount; i++) {
      let tree;
      if (def.id === "sunny" || def.id === "coral" || def.id === "sunken") tree = palm(th, r);
      else if (def.id === "frost") tree = pine(th, true, r);
      else if (def.id === "volcano") tree = deadTree(th, r);
      else if (def.id === "storm") tree = pine(th, false, r);
      else if (def.id === "celestial") tree = blossom(th, r);
      else tree = mushroom(th, r);
      addProp(tree, 4.5, 12, 0.45, 2.2);
    }
    if (def.id === "sunny" || def.id === "coral" || def.id === "sunken" || def.id === "celestial") {
      for (let i = 0; i < 5; i++) addProp(bush(th, r), 3.5, 12.2, 0, 1.2);
    }
  }

  // Прибрежные камни
  for (let i = 0; i < 7; i++) {
    const s = 0.4 + r() * 0.5;
    addProp(rock(th.rock, s, i + seed), 14.8, 16.6, s * 0.9, 1.0, 0.45);
  }

  // Дальние фоновые острова / лунные хребты
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2 + r() * 0.5;
    const rr = 120 + r() * 60;
    const di = new THREE.Group();
    const rad = 8 + r() * 10;
    di.add(mesh(jitter(new THREE.CylinderGeometry(rad, rad + 4, 4, 10), 0.8, i + 200), mat(th.sand), 0, -1, 0, false));
    di.add(mesh(jitter(new THREE.ConeGeometry(rad * 0.8, 4 + r() * 10, 8), 0.8, i + 210), mat(def.id === "frost" ? "#ffffff" : th.grass), 0, 3, 0, false));
    di.position.set(Math.cos(a) * rr, 0, Math.sin(a) * rr);
    group.add(di);
  }

  mergeStatic(group);

  return {
    group,
    colliders,
    npcs,
    smoke,
    update: (t0, dt, amp) => {
      for (const u of ups) u(t0, dt, amp);
    },
  };
}

const tmp = new THREE.Vector3();
const tmp2 = new THREE.Vector3();

function pickMutation() {
  const total = MUTATIONS.reduce((a, m) => a + m.weight, 0);
  let r = Math.random() * total;
  for (const m of MUTATIONS) {
    r -= m.weight;
    if (r <= 0) return m.id;
  }
  return MUTATIONS[0].id;
}

export class Fishing {
  constructor(e) {
    this.e = e;
    this.phase = "idle";
    this.t = 0;
    this.power = 0;
    this.powerDir = 1;
    this.castQ = "good";
    this.from = new THREE.Vector3();
    this.to = new THREE.Vector3();
    this.bob = new THREE.Vector3();
    this.startPos = new THREE.Vector3();
    this.biteAt = 0;
    this.nibbleAt = 0;
    this.dip = 0;
    this.hotspot = false;
    this.pending = null;
    this.mg = null;
    this.autoT = 0;
    this.autoMode = false;
    this.held = null;
    this.heldTilt = 0;
    this.heldJelly = false;
    this.heldScale = 1;
    this.sparkT = 0;
    this.rescueTimer = null;
  }

  setPhase(p) {
    this.phase = p;
    this.t = 0;
    useGame.setState({ phase: p });
  }

  canAct() {
    const s = useGame.getState();
    return s.started && !s.panel && !s.fade && !s.hidden && !s.sdkPaused && !s.adBusy && !s.paymentBusy;
  }

  press() {
    if (!this.canAct()) return;
    switch (this.phase) {
      case "idle": {
        if (ISLAND_MAP[useGame.getState().island]?.noFishing) {
          toast("🚀 " + t("noFishingHere"), "#ffe066");
          audio.play("error");
          return;
        }
        if (isBagFull()) {
          toast("🎒 " + t("bagFull"), "#ff8a8a");
          audio.play("error");
          return;
        }
        this.power = 0;
        this.powerDir = 1;
        this.e.faceCamera();
        this.setPhase("charging");
        audio.play("charge");
        break;
      }
      case "waiting":
        this.reelBack();
        break;
      case "bite":
        this.startMinigame();
        break;
      case "reeling":
        this.hit();
        break;
      case "caught":
        if (this.t > 0.7) this.finishCatch();
        break;
      default:
        break;
    }
  }

  release() {
    if (this.phase === "charging") this.cast(this.power, false);
  }

  findTarget(p, heading, dist) {
    const dx = Math.sin(heading), dz = Math.cos(heading);
    for (let d = dist; d <= 34; d += 0.5) {
      const x = p.x + dx * d, z = p.z + dz * d;
      if (isWater(x, z)) return new THREE.Vector3(x, 0, z);
    }
    return null;
  }

  cast(power, auto) {
    const e = this.e;
    const q = power >= 0.92 ? "perfect" : power >= 0.75 ? "great" : power >= 0.42 ? "good" : "ok";
    const target = this.findTarget(e.player.pos, e.player.heading, 6 + power * 16);
    e.showTarget(null, false);
    if (!target) {
      if (!auto) {
        toast("🌊 " + t("aimWater"), "#ff8a8a");
        audio.play("error");
      }
      this.setPhase("idle");
      return false;
    }
    this.castQ = q;
    this.autoMode = auto;
    e.updateRodTip();
    this.from.copy(e.rodTipWorld);
    this.to.copy(target);
    this.bob.copy(this.from);
    this.hotspot = e.hotspotAt(target.x, target.z);
    if (!auto) {
      const labels = {
        perfect: [t("perfectCast"), "#ffe14d"],
        great: [t("greatCast"), "#7ef07e"],
        good: [t("goodCast"), "#ffffff"],
        ok: [t("okCast"), "#c3ccd6"],
      };
      useGame.setState({ castLabel: { text: labels[q][0], color: labels[q][1], key: Date.now() } });
      if (q === "perfect") notePerfectCast();
    }
    useGame.setState({ inHotspot: this.hotspot });
    if (this.hotspot) toast("✨ " + t("hotspot"), "#ffe14d");
    audio.play("cast");
    this.setPhase("casting");
    return true;
  }

  rollFish(island) {
    const mods = getMods();
    let lm = mods.luckMult;
    if (this.castQ === "perfect") lm *= 1.2;
    else if (this.castQ === "great") lm *= 1.08;
    if (this.hotspot) lm *= 1.5;
    const weights = RARITIES.map((r) => {
      if (r.idx === 0) return r.weight / Math.pow(Math.max(1, lm), 0.85);
      if (r.idx === 1) return r.weight / Math.pow(Math.max(1, lm), 0.25);
      return r.weight * Math.pow(Math.max(1, lm), r.boost * 0.78);
    });
    let roll = Math.random() * weights.reduce((a, b) => a + b, 0);
    let idx = 0;
    for (; idx < weights.length - 1; idx++) {
      roll -= weights[idx];
      if (roll <= 0) break;
    }
    let pool = [];
    for (let i = idx; i >= 0 && !pool.length; i--) pool = FISH.filter((f) => f.island === island && f.rarity === RARITIES[i].id);
    if (!pool.length) pool = FISH.filter((f) => f.island === island);
    const def = pool[Math.floor(Math.random() * pool.length)];
    const weightExp = Math.max(0.65, 2.2 / Math.pow(Math.max(1, lm), 0.18));
    const w = def.minW + (def.maxW - def.minW) * Math.pow(Math.random(), weightExp);
    const mc = Math.min(1, mods.mutChance * (this.hotspot ? 1.5 : 1));
    return { def, w, mut: Math.random() < mc ? pickMutation() : null };
  }

  triggerBite() {
    const e = this.e;
    this.pending = this.rollFish(useGame.getState().island);
    this.setPhase("bite");
    audio.play("bite");
    vibrate(60);
    e.splash.emit(this.to.x, 0.15, this.to.z, { count: 18, speed: 2.4, up: 4.5, color: "#ffffff", size: 0.32, life: 0.7 });
    e.ripple(this.to.x, this.to.z);
  }

  startMinigame() {
    if (!this.pending) {
      this.reelBack();
      return;
    }
    const r = RARITY[this.pending.def.rarity];
    const ctl = getMods().control;
    const zone = Math.min(0.5, r.mg.zone * (1 + ctl / 100));
    this.mg = {
      progress: 0.25, marker: 0, dir: 1, speed: r.mg.speed, zoneStart: 0.4, zoneWidth: zone, perfectWidth: zone * 0.32,
      gain: (0.85 / r.mg.hits) * (1 + ctl / 120), drain: r.mg.drain, penalty: r.mg.penalty,
      hits: 0, perfects: 0, misses: 0, result: "", resultKey: 0, cooldown: 0, autoTarget: 0.5, rarity: r.id,
    };
    this.placeZone();
    this.setPhase("reeling");
    audio.play("hit");
    vibrate(30);
  }

  placeZone() {
    const mg = this.mg;
    let start = 0.3;
    for (let k = 0; k < 12; k++) {
      start = 0.03 + Math.random() * (0.94 - mg.zoneWidth);
      if (Math.abs(start + mg.zoneWidth / 2 - mg.marker) > 0.28) break;
    }
    mg.zoneStart = start;
    this.rollAutoTarget();
  }

  rollAutoTarget() {
    const mg = this.mg;
    mg.autoTarget =
      Math.random() < 0.87
        ? mg.zoneStart + mg.zoneWidth * (0.12 + Math.random() * 0.76)
        : mg.zoneStart > 0.5
          ? Math.max(0.01, mg.zoneStart - 0.07)
          : Math.min(0.99, mg.zoneStart + mg.zoneWidth + 0.07);
  }

  hit() {
    const mg = this.mg;
    if (!mg || mg.cooldown > 0) return;
    mg.cooldown = 0.13;
    const e = this.e;
    const c = mg.zoneStart + mg.zoneWidth / 2;
    if (mg.marker >= mg.zoneStart && mg.marker <= mg.zoneStart + mg.zoneWidth) {
      if (Math.abs(mg.marker - c) <= mg.perfectWidth / 2) {
        mg.progress += mg.gain * 1.5;
        mg.perfects++;
        mg.result = "perfect";
        audio.play("perfect");
        e.sparkles.emit(this.bob.x, this.bob.y + 0.3, this.bob.z, { count: 14, speed: 3, up: 4, color: "#ffe14d", size: 0.35, life: 0.8, gravity: -4 });
      } else {
        mg.progress += mg.gain;
        mg.hits++;
        mg.result = "good";
        audio.play("hit");
      }
      e.splash.emit(this.bob.x, 0.15, this.bob.z, { count: 8, speed: 2, up: 3.5, color: "#ffffff", size: 0.25, life: 0.6 });
      this.placeZone();
      vibrate(15);
    } else {
      mg.progress -= mg.penalty;
      mg.misses++;
      mg.result = "miss";
      audio.play("miss");
      this.rollAutoTarget();
    }
    mg.resultKey++;
  }

  updateMinigame(dt) {
    const mg = this.mg;
    const e = this.e;
    mg.cooldown -= dt;
    const prev = mg.marker;
    mg.marker += mg.dir * mg.speed * 2 * dt;
    if (mg.marker >= 1) {
      mg.marker = 1;
      mg.dir = -1;
    } else if (mg.marker <= 0) {
      mg.marker = 0;
      mg.dir = 1;
    }
    mg.progress -= mg.drain * dt;
    if (this.autoMode && mg.cooldown <= 0 && (prev - mg.autoTarget) * (mg.marker - mg.autoTarget) <= 0) this.hit();
    const ang = this.t * 1.7;
    const rad = 0.6 + Math.sin(this.t * 2.3) * 0.3;
    const x = this.to.x + Math.cos(ang) * rad;
    const z = this.to.z + Math.sin(ang * 1.3) * rad;
    this.bob.set(x, waveHeight(x, z, e.time, e.waveAmp) - 0.16 + Math.sin(this.t * 11) * 0.05, z);
    if (Math.random() < dt * 5) e.splash.emit(x, 0.12, z, { count: 4, speed: 1.6, up: 2.6, color: "#ffffff", size: 0.22, life: 0.5 });
    if (Math.random() < dt * 2) e.ripple(x, z);
    if (mg.progress >= 1) this.caught();
    else if (mg.progress <= 0) this.escape();
  }

  caught(rescued = false) {
    const p = this.pending;
    if (!p) return;
    const mg = this.mg;
    const e = this.e;
    const perfect = !rescued && mg.misses === 0 && mg.perfects > mg.hits;
    let w = p.w;
    let mut = p.mut;
    if (perfect) {
      w = Math.min(p.def.maxW * 1.1, w * 1.08);
      if (!mut && Math.random() < getMods().mutChance * 2) mut = pickMutation();
    }
    const { item, isNew } = addCatch(p.def, w, mut);
    useGame.setState({ catchInfo: { fish: item, isNew, perfect, key: Date.now(), adBreak: S().stats.caught % 8 === 0 } });
    this.held = createFishMesh(p.def, mut, fishDisplayLength(w));
    this.held.rotation.order = "YXZ";
    this.heldTilt = p.def.shape === "ray" ? 1.15 : 0;
    this.heldJelly = p.def.shape === "jelly";
    this.heldScale = this.held.scale.x;
    e.scene.add(this.held);
    this.startPos.copy(this.bob);
    this.held.position.copy(this.bob);
    const rIdx = RARITY[p.def.rarity].idx;
    audio.play(rIdx >= 3 || mut ? "rare" : "catch");
    audio.play("splash");
    vibrate([40, 40, 90]);
    e.splash.emit(this.bob.x, 0.2, this.bob.z, { count: 30, speed: 3.5, up: 6, color: "#ffffff", size: 0.4, life: 0.9 });
    if (rIdx >= 2) e.sparkles.emit(this.bob.x, 1, this.bob.z, { count: 30, speed: 4, up: 5, color: RARITY[p.def.rarity].color, size: 0.45, life: 1.2, gravity: -3 });
    this.mg = null;
    this.pending = null;
    e.showcase = true;
    this.setPhase("caught");
  }

  escape() {
    const fish = this.pending?.def;
    if (fish && RARITY[fish.rarity].idx >= RARITY.rare.idx && YA.rewardedAvailable && !S().panel && !S().adBusy && !S().paymentBusy) {
      this.setPhase("rescue");
      set({ rescue: { fish, deadline: Date.now() + 5000, pending: false } });
      this.rescueTimer = setTimeout(() => void this.resolveRescue(false), 5000);
      return;
    }
    this.loseFish();
  }

  async resolveRescue(watch) {
    const offer = S().rescue;
    if (this.phase !== "rescue" || !offer || offer.pending) return;
    clearTimeout(this.rescueTimer);
    if (watch && Date.now() < offer.deadline) {
      const attempt = { ...offer, pending: true };
      set({ rescue: attempt });
      const rewarded = await askRewarded();
      if (this.phase !== "rescue" || S().rescue !== attempt) return;
      set({ rescue: null });
      if (rewarded) {
        this.caught(true);
        return;
      }
    } else set({ rescue: null });
    this.loseFish();
  }

  loseFish() {
    toast("🐟 " + t("escaped"), "#ff8a8a");
    audio.play("escape");
    this.mg = null;
    this.pending = null;
    this.reelBack();
  }

  reelBack() {
    this.startPos.copy(this.bob);
    this.setPhase("reelback");
  }

  finishCatch() {
    if (this.phase !== "caught") return;
    const { adBreak } = S().catchInfo ?? {};
    set({ catchInfo: null });
    if (adBreak && !S().panel) void showInterstitial();
    if (this.held) {
      this.e.scene.remove(this.held);
      disposeFish(this.held);
      this.held = null;
    }
    this.e.showcase = false;
    this.setPhase("idle");
  }

  cancel() {
    clearTimeout(this.rescueTimer);
    set({ rescue: null, catchInfo: null });
    if (this.held) {
      this.e.scene.remove(this.held);
      disposeFish(this.held);
      this.held = null;
    }
    this.mg = null;
    this.pending = null;
    this.e.showcase = false;
    this.e.showTarget(null, false);
    this.setPhase("idle");
  }

  update(dt) {
    this.t += dt;
    const e = this.e;
    const s = useGame.getState();
    switch (this.phase) {
      case "idle": {
        const can = s.autoOn && autoAvailable(s) && this.canAct() && !e.moving && !ISLAND_MAP[s.island]?.noFishing;
        if (!can) {
          this.autoT = 0;
          break;
        }
        this.autoT += dt;
        if (this.autoT < 0.9) break;
        this.autoT = 0;
        if (isBagFull(s)) {
          toast("🎒 " + t("bagFull"), "#ff8a8a");
          useGame.setState({ autoOn: false });
          break;
        }
        let heading = e.cameraHeading();
        if (!this.findTarget(e.player.pos, heading, 18)) {
          const ox = e.player.pos.x, oz = e.player.pos.z;
          heading = ox * ox + oz * oz < 0.01 ? Math.PI / 2 : Math.atan2(ox, oz);
        }
        e.player.heading = heading;
        if (!this.cast(0.62 + Math.random() * 0.36, true)) {
          useGame.setState({ autoOn: false });
          toast(t("autoNeedWater"), "#ff8a8a");
        }
        break;
      }
      case "charging": {
        this.power += this.powerDir * dt * 1.15;
        if (this.power >= 1) {
          this.power = 1;
          this.powerDir = -1;
        } else if (this.power <= 0) {
          this.power = 0;
          this.powerDir = 1;
        }
        e.faceCamera();
        const tg = this.findTarget(e.player.pos, e.player.heading, 6 + this.power * 16);
        e.showTarget(tg, tg ? e.hotspotAt(tg.x, tg.z) : false);
        break;
      }
      case "casting": {
        const dur = 0.75;
        const k = Math.min(1, this.t / dur);
        tmp.copy(this.from).lerp(this.to, 0.5);
        tmp.y += 4 + this.from.distanceTo(this.to) * 0.15;
        const a = (1 - k) * (1 - k), b = 2 * (1 - k) * k, c = k * k;
        this.bob.set(
          a * this.from.x + b * tmp.x + c * this.to.x,
          a * this.from.y + b * tmp.y + c * this.to.y,
          a * this.from.z + b * tmp.z + c * this.to.z
        );
        if (k >= 1) {
          e.splash.emit(this.to.x, 0.1, this.to.z, { count: 14, speed: 2, up: 3.5, color: "#ffffff", size: 0.28, life: 0.6 });
          e.ripple(this.to.x, this.to.z);
          audio.play("splash");
          const mods = getMods();
          let wait = (3.5 + Math.random() * 5.5) / mods.speedMult;
          if (this.hotspot) wait *= 0.6;
          if (this.castQ === "ok") wait *= 1.15;
          this.biteAt = Math.max(1.2, wait);
          this.nibbleAt = 0.8 + Math.random() * 1.4;
          this.setPhase("waiting");
        }
        break;
      }
      case "waiting": {
        if (this.t > this.nibbleAt && this.t < this.biteAt - 0.5) {
          this.dip = 0.12;
          this.nibbleAt = this.t + 0.8 + Math.random() * 1.6;
          audio.play("nibble");
          e.ripple(this.to.x, this.to.z);
        }
        this.dip = Math.max(0, this.dip - dt * 0.45);
        this.bob.set(this.to.x, waveHeight(this.to.x, this.to.z, e.time, e.waveAmp) - this.dip + 0.02, this.to.z);
        if (this.t >= this.biteAt) this.triggerBite();
        break;
      }
      case "bite": {
        this.bob.set(this.to.x + Math.sin(this.t * 30) * 0.05, waveHeight(this.to.x, this.to.z, e.time, e.waveAmp) - 0.28, this.to.z);
        if (this.autoMode) {
          if (this.t > 0.35) this.startMinigame();
        } else if (this.t > 1.6) {
          toast("⏱ " + t("missedBite"), "#ff8a8a");
          audio.play("escape");
          this.pending = null;
          this.reelBack();
        }
        break;
      }
      case "reeling":
        if (this.mg) this.updateMinigame(dt);
        break;
      case "caught": {
        const held = this.held;
        if (held) {
          e.rig.root.updateMatrixWorld(true);
          e.rig.hold.getWorldPosition(tmp2);
          const jump = 0.6;
          if (this.t < jump) {
            const k = this.t / jump;
            held.position.lerpVectors(this.startPos, tmp2, k);
            held.position.y += Math.sin(k * Math.PI) * 3;
            held.rotation.set(this.heldTilt * k, e.player.heading, k * Math.PI * 2);
          } else {
            held.position.copy(tmp2);
            held.position.y += Math.sin(this.t * 3) * 0.05;
            held.rotation.set(this.heldTilt, e.player.heading, Math.sin(this.t * 2.5) * 0.12);
          }
          const d = held.userData;
          if (this.heldJelly) {
            const pulse = 1 + Math.sin(this.t * 6) * 0.12;
            held.scale.set(this.heldScale * (2 - pulse), this.heldScale * pulse, this.heldScale * (2 - pulse));
            d.tail.rotation.z = Math.sin(this.t * 6) * 0.18;
          } else {
            d.tail.rotation.y = Math.sin(this.t * 16) * 0.55;
          }
          if (d.rainbow) d.mats.forEach((m) => m.color.setHSL((this.t * 0.35) % 1, 0.9, 0.62));
          this.sparkT -= dt;
          if (d.sparkle && this.sparkT <= 0) {
            this.sparkT = 0.07;
            e.sparkles.emit(held.position.x + (Math.random() - 0.5), held.position.y + (Math.random() - 0.5) * 0.6, held.position.z + (Math.random() - 0.5), {
              count: 2, speed: 0.6, up: 1.2, color: d.rainbow ? new THREE.Color().setHSL(Math.random(), 1, 0.6) : "#fff3a0", size: 0.3, life: 0.7, gravity: 0.5,
            });
          }
        }
        if (this.t > (this.autoMode ? 2.1 : 3.4)) this.finishCatch();
        break;
      }
      case "reelback": {
        const k = Math.min(1, this.t / 0.35);
        e.updateRodTip();
        this.bob.lerpVectors(this.startPos, e.rodTipWorld, k);
        if (k >= 1) this.setPhase("idle");
        break;
      }
    }
  }
}

const STORM_TOP = new THREE.Color("#3a4450");
const STORM_HOR = new THREE.Color("#8a96a0");
const NIGHT_TOP = new THREE.Color("#060a24");
const NIGHT_HOR = new THREE.Color("#2a2a66");

const beamVert = `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`;
const beamFrag = `uniform vec3 uColor; uniform float uAlpha; varying vec2 vUv;
void main(){ float a = (1.0 - vUv.y) * uAlpha; gl_FragColor = vec4(uColor, a); }`;

export class Engine {
  constructor(container, isMobile) {
    this.container = container;
    this.isMobile = isMobile;
    this.scene = new THREE.Scene();
    this.clouds = new THREE.Group();
    this.cloudMat = new THREE.MeshLambertMaterial({ color: "#ffffff", flatShading: true });
    this.birds = [];
    this.islands = new Map();
    this.island = null;
    this.islandId = "";
    this.recent = [];
    this.player = { pos: new THREE.Vector3(SPAWN.x, 1.2, SPAWN.z), heading: SPAWN.heading };
    this.moving = false;
    this.walkPhase = 0;
    this.walkBlend = 0;
    this.cam = { yaw: -Math.PI / 2, pitch: 0.36, dist: 11 };
    this.curYaw = 0.6;
    this.curPitch = 0.32;
    this.curDist = 30;
    this.camTarget = new THREE.Vector3(0, 2, 0);
    this.menuYaw = 0.6;
    this.keys = new Set();
    this.joy = { x: 0, y: 0 };
    this.ripples = [];
    this.rippleIdx = 0;
    this.hotspots = [];
    this.rodTipWorld = new THREE.Vector3();
    this.time = 0;
    this.waveAmp = 1;
    this.showcase = false;
    this.paused = false;
    this.base = {
      top: new THREE.Color(), hor: new THREE.Color(), fog: new THREE.Color(), deep: new THREE.Color(), shallow: new THREE.Color(),
    };
    this.stormMix = 0;
    this.starMix = 0;
    this.smokeT = 0;
    this.bubbleT = 0;
    this.raf = 0;
    this.clock = new THREE.Clock();
    this.nearNpc = null;
    this.unsubs = [];
    this.pointers = new Map();
    this.pinch = 0;
    this.firstFrame = true;
    this.tmpC = new THREE.Color();
    this.tmpC2 = new THREE.Color();

    const r = new THREE.WebGLRenderer({ antialias: !isMobile, powerPreference: "high-performance" });
    r.setPixelRatio(Math.min(window.devicePixelRatio || 1, isMobile ? 1.5 : 2));
    r.shadowMap.enabled = true;
    r.shadowMap.type = THREE.PCFSoftShadowMap;
    r.setSize(container.clientWidth || 1, container.clientHeight || 1);
    container.appendChild(r.domElement);
    this.renderer = r;

    this.camera = new THREE.PerspectiveCamera(55, (container.clientWidth || 1) / (container.clientHeight || 1), 0.1, 1000);
    this.scene.fog = new THREE.Fog("#c4ecff", 60, 260);

    this.hemi = new THREE.HemisphereLight("#cfeaff", "#d8c08a", 1.3);
    this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight("#fff4dc", 2.4);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(isMobile ? 1024 : 2048, isMobile ? 1024 : 2048);
    const sc = this.sun.shadow.camera;
    sc.left = -24; sc.right = 24; sc.top = 24; sc.bottom = -24; sc.near = 1; sc.far = 120;
    this.sun.shadow.bias = -0.0006;
    this.sun.shadow.normalBias = 0.03;
    this.scene.add(this.sun, this.sun.target);

    this.sky = new Sky();
    this.scene.add(this.sky.mesh);
    this.water = new Water(isMobile ? 110 : 150);
    this.scene.add(this.water.mesh);
    this.splash = new Particles(500, false);
    this.sparkles = new Particles(500, true);
    this.weather = new WeatherFX();
    this.scene.add(this.splash.points, this.sparkles.points, this.weather.points);

    this.buildClouds();
    this.buildBirds();

    this.rig = createCharacter({ shirt: "#ffc832", pants: "#3a5a8a", skin: "#f2c9a0", hat: "#e8a020", hatType: "bucket", withRod: true });
    this.scene.add(this.rig.root);
    setRodLook(this.rig, ROD_MAP[useGame.getState().rod] ?? ROD_MAP.bamboo);

    this.bobber = createBobber();
    this.bobber.visible = false;
    this.scene.add(this.bobber);

    this.linePos = new Float32Array(24 * 3);
    const lg = new THREE.BufferGeometry();
    lg.setAttribute("position", new THREE.BufferAttribute(this.linePos, 3).setUsage(THREE.DynamicDrawUsage));
    this.line = new THREE.Line(lg, new THREE.LineBasicMaterial({ color: "#ffffff", transparent: true, opacity: 0.85 }));
    this.line.frustumCulled = false;
    this.line.visible = false;
    this.scene.add(this.line);

    this.exclaim = makeExclaim();
    this.exclaim.visible = false;
    this.scene.add(this.exclaim);

    const tr = new THREE.Mesh(new THREE.RingGeometry(0.55, 0.8, 28), new THREE.MeshBasicMaterial({ color: "#7ef07e", transparent: true, opacity: 0.85, depthWrite: false, side: THREE.DoubleSide }));
    tr.rotation.x = -Math.PI / 2;
    tr.visible = false;
    tr.renderOrder = 4;
    this.targetRing = tr;
    this.scene.add(tr);

    const rippleGeo = new THREE.RingGeometry(0.26, 0.36, 28);
    for (let i = 0; i < 12; i++) {
      const m = new THREE.Mesh(rippleGeo, new THREE.MeshBasicMaterial({ color: "#ffffff", transparent: true, opacity: 0, depthWrite: false }));
      m.rotation.x = -Math.PI / 2;
      m.visible = false;
      m.renderOrder = 3;
      this.scene.add(m);
      this.ripples.push({ m, t: 1 });
    }

    this.fishing = new Fishing(this);
    this.setIsland(useGame.getState().island, false);

    this.unsubs.push(
      useGame.subscribe((s, p) => {
        if (s.rod !== p.rod) setRodLook(this.rig, ROD_MAP[s.rod] ?? ROD_MAP.bamboo);
        if (s.island !== p.island) this.setIsland(s.island, false);
        if (s.curLang !== p.curLang) this.rebuildLabels();
        if (s.lowGfx !== p.lowGfx) this.applyQuality(s.lowGfx);
        if (s.started && !p.started) {
          this.curYaw = this.menuYaw;
          this.cam.yaw = -Math.PI / 2;
        }
      })
    );

    const st0 = useGame.getState();
    this.paused = st0.hidden || st0.adBusy || st0.paymentBusy || st0.sdkPaused;
    if (st0.lowGfx) this.applyQuality(true);
    this.bindInput();
    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(container);
    this.resize();
    this.loop = this.loop.bind(this);
    this.loop();
  }

  buildClouds() {
    const geo = new THREE.IcosahedronGeometry(1, 0);
    for (let i = 0; i < 14; i++) {
      const c = new THREE.Group();
      const n = 3 + Math.floor(Math.random() * 3);
      for (let k = 0; k < n; k++) {
        const m = new THREE.Mesh(geo, this.cloudMat);
        m.position.set(k * 3 - n * 1.5 + Math.random(), Math.random() * 1.5, Math.random() * 3 - 1.5);
        m.scale.setScalar(3 + Math.random() * 3);
        m.scale.y *= 0.65;
        c.add(m);
      }
      const a = Math.random() * Math.PI * 2;
      const rr = 60 + Math.random() * 170;
      c.position.set(Math.cos(a) * rr, 45 + Math.random() * 30, Math.sin(a) * rr);
      this.clouds.add(c);
    }
    this.scene.add(this.clouds);
  }

  buildBirds() {
    const wingGeo = new THREE.BoxGeometry(0.9, 0.04, 0.32).translate(0.45, 0, 0);
    for (let i = 0; i < 4; i++) {
      const g = new THREE.Group();
      g.add(new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.18, 0.6), mat("#ffffff")));
      const wl = new THREE.Group();
      const wr = new THREE.Group();
      wl.add(new THREE.Mesh(wingGeo, mat("#f0f0f0")));
      const wrm = new THREE.Mesh(wingGeo, mat("#f0f0f0"));
      wrm.rotation.y = Math.PI;
      wr.add(wrm);
      wl.position.x = 0.1;
      wr.position.x = -0.1;
      g.add(wl, wr);
      this.scene.add(g);
      this.birds.push({ g, wl, wr, r: 18 + Math.random() * 18, h: 12 + Math.random() * 7, sp: 0.18 + Math.random() * 0.12, ph: Math.random() * 6 });
    }
  }

  setIsland(id, keepPlayer) {
    const def = ISLAND_MAP[id] ?? ISLAND_MAP.sunny;
    if (this.island) this.island.group.visible = false;
    let b = this.islands.get(def.id);
    if (!b) {
      b = buildIsland(def, {
        merchant: t("npcMerchant"),
        shop: t("npcShop"),
        boat: t("npcBoat"),
        rocket: t("npcRocket"),
        earthRocket: t("npcEarthRocket"),
      });
      this.islands.set(def.id, b);
      this.scene.add(b.group);
    }
    b.group.visible = true;
    this.island = b;
    this.islandId = def.id;
    this.recent = [def.id, ...this.recent.filter((x) => x !== def.id)];
    this.trimIslandCache();
    const th = def.theme;
    this.theme = th;
    this.base.top.set(th.skyTop);
    this.base.hor.set(th.skyHorizon);
    this.base.fog.set(th.fog);
    this.base.deep.set(th.waterDeep);
    this.base.shallow.set(th.waterShallow);
    const fog = this.scene.fog;
    fog.near = th.fogNear;
    fog.far = th.fogFar;
    this.water.u.uFogNear.value = th.fogNear;
    this.water.u.uFogFar.value = th.fogFar;
    this.water.u.uFoam.value.set(th.foam);
    const sd = new THREE.Vector3(...th.sunDir).normalize();
    this.water.u.uSunDir.value.copy(sd);
    this.sky.u.uSunDir.value.copy(sd);
    this.sun.color.set(th.sun);
    this.water.u.uSunColor.value.set(th.sun);
    this.sky.u.uSunColor.value.set(th.sun);
    this.hemi.color.set(th.hemiSky);
    this.hemi.groundColor.set(th.hemiGround);
    this.cloudMat.color.set(th.cloud);
    const birdsOn = ["sunny", "coral", "frost", "sunken", "celestial"].includes(def.id);
    this.birds.forEach((bd) => (bd.g.visible = birdsOn));
    if (!keepPlayer) {
      this.fishing.cancel();
      this.player.pos.set(SPAWN.x, 1.2, SPAWN.z);
      this.player.heading = SPAWN.heading;
      this.cam.yaw = -Math.PI / 2;
      this.curYaw = this.cam.yaw;
      this.camTarget.set(SPAWN.x, 2.8, SPAWN.z);
      this.respawnHotspots();
    }
    this.applyEnv(10);
  }

  trimIslandCache(keep = 3) {
    for (const id of this.recent.slice(keep)) {
      const b = this.islands.get(id);
      if (!b) continue;
      this.scene.remove(b.group);
      b.group.traverse((o) => {
        if (o.isMesh) o.geometry.dispose();
      });
      this.islands.delete(id);
    }
    this.recent = this.recent.slice(0, keep);
  }

  rebuildLabels() {
    for (const [, b] of this.islands) {
      this.scene.remove(b.group);
      b.group.traverse((o) => {
        if (o.isMesh) o.geometry.dispose();
      });
    }
    this.islands.clear();
    this.recent = [];
    this.island = null;
    this.setIsland(this.islandId, true);
  }

  makeHotspot() {
    const g = new THREE.Group();
    const ringMat = new THREE.MeshBasicMaterial({ color: "#ffe14d", transparent: true, opacity: 0.9, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide });
    const ring = new THREE.Mesh(new THREE.RingGeometry(2.3, 2.75, 36), ringMat);
    ring.rotation.x = -Math.PI / 2;
    g.add(ring);
    const disc = new THREE.Mesh(new THREE.CircleGeometry(2.3, 30), new THREE.MeshBasicMaterial({ color: "#ffd23a", transparent: true, opacity: 0.18, depthWrite: false, blending: THREE.AdditiveBlending }));
    disc.rotation.x = -Math.PI / 2;
    g.add(disc);
    const beam = new THREE.Mesh(
      new THREE.CylinderGeometry(1.4, 2.3, 16, 20, 1, true).translate(0, 8, 0),
      new THREE.ShaderMaterial({ uniforms: { uColor: { value: new THREE.Color("#ffe680") }, uAlpha: { value: 0.35 } }, vertexShader: beamVert, fragmentShader: beamFrag, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide })
    );
    g.add(beam);
    g.renderOrder = 4;
    this.scene.add(g);
    const hs = { group: g, x: 0, z: 0, ttl: 0, vis: 0, dying: false };
    this.relocate(hs);
    return hs;
  }

  relocate(hs) {
    for (let k = 0; k < 30; k++) {
      const a = Math.random() * Math.PI * 2;
      if (Math.abs(Math.atan2(Math.sin(a), Math.cos(a))) < 0.22) continue;
      const rr = 21 + Math.random() * 9;
      const x = Math.cos(a) * rr, z = Math.sin(a) * rr;
      if (this.hotspots.some((o) => o !== hs && Math.hypot(o.x - x, o.z - z) < 9)) continue;
      hs.x = x;
      hs.z = z;
      break;
    }
    hs.ttl = 70 + Math.random() * 35;
    hs.vis = 0;
    hs.dying = false;
  }

  respawnHotspots() {
    this.hotspots.forEach((h) => this.relocate(h));
  }

  hotspotAt(x, z) {
    return this.hotspots.some((h) => h.group.visible && h.vis > 0.5 && Math.hypot(h.x - x, h.z - z) < 3.2);
  }

  updateHotspots(dt, frenzy) {
    const noFish = !!ISLAND_MAP[this.islandId]?.noFishing;
    const want = noFish ? 0 : frenzy ? 4 : 2;
    while (this.hotspots.length < want) this.hotspots.push(this.makeHotspot());
    this.bubbleT -= dt;
    const emit = this.bubbleT <= 0;
    if (emit) this.bubbleT = 0.12;
    this.hotspots.forEach((h, i) => {
      const active = i < want;
      h.ttl -= dt;
      if (h.ttl <= 0 || !active) h.dying = true;
      h.vis = clamp(h.vis + (h.dying ? -dt : dt) * 0.8, 0, 1);
      if (h.dying && h.vis <= 0) {
        if (active) this.relocate(h);
      }
      h.group.visible = h.vis > 0.01;
      if (!h.group.visible) return;
      const y = waveHeight(h.x, h.z, this.time, this.waveAmp);
      h.group.position.set(h.x, y + 0.06, h.z);
      const pulse = 1 + Math.sin(this.time * 3 + i) * 0.06;
      h.group.scale.set(pulse * h.vis, 1, pulse * h.vis);
      if (emit && h.vis > 0.5) {
        this.sparkles.emit(h.x + (Math.random() - 0.5) * 3, y + 0.1, h.z + (Math.random() - 0.5) * 3, { count: 1, speed: 0.2, up: 1.6, color: "#fff3a0", size: 0.3, life: 1.4, gravity: 0.6 });
      }
    });
  }

  cameraHeading() {
    return Math.atan2(-Math.sin(this.cam.yaw), -Math.cos(this.cam.yaw));
  }
  faceCamera() {
    this.player.heading = this.cameraHeading();
  }
  updateRodTip() {
    this.rig.root.position.copy(this.player.pos);
    this.rig.root.rotation.y = this.player.heading;
    this.rig.root.updateMatrixWorld(true);
    this.rig.rodTip?.getWorldPosition(this.rodTipWorld);
  }
  showTarget(p, hot) {
    if (!p) {
      this.targetRing.visible = false;
      return;
    }
    this.targetRing.visible = true;
    this.targetRing.position.set(p.x, waveHeight(p.x, p.z, this.time, this.waveAmp) + 0.08, p.z);
    this.targetRing.material.color.set(hot ? "#ffe14d" : isWater(p.x, p.z) ? "#7ef07e" : "#ff6a6a");
    this.targetRing.scale.setScalar(1 + Math.sin(this.time * 8) * 0.08);
  }
  ripple(x, z) {
    const r = this.ripples[this.rippleIdx];
    this.rippleIdx = (this.rippleIdx + 1) % this.ripples.length;
    r.t = 0;
    r.m.position.set(x, 0, z);
    r.m.visible = true;
  }

  bindInput() {
    const el = this.renderer.domElement;
    const onKeyDown = (e) => {
      // Пункт 1.6.2.6: Игнорируем системные сочетания клавиш
      if (e.ctrlKey || e.altKey || e.metaKey) return;
      const tag = document.activeElement?.tagName;
      if (useGame.getState().started && ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.code) && tag !== "INPUT" && tag !== "TEXTAREA") e.preventDefault();
      if (tag === "INPUT" || tag === "TEXTAREA") {
        if (e.code === "Escape") document.activeElement.blur();
        return;
      }
      const s = useGame.getState();
      if (e.code === "Escape") {
        if (s.phase === "rescue") void this.fishing.resolveRescue(false);
        else if (s.panel) openPanel(null);
        return;
      }
      if (s.panel || !s.started || s.phase === "rescue" || s.adBusy || s.paymentBusy) return;
      if (e.code === "Space") {
        e.preventDefault();
        const ae = document.activeElement;
        if (ae && ae !== document.body) ae.blur();
        if (!e.repeat) this.fishing.press();
        return;
      }
      if ((e.code === "KeyE" || e.code === "KeyF") && !e.repeat) this.interact();
      this.keys.add(e.code);
    };
    const onKeyUp = (e) => {
      this.keys.delete(e.code);
      if (e.code === "Space") {
        e.preventDefault();
        this.fishing.release();
      }
    };
    const onBlur = () => {
      this.keys.clear();
      this.fishing.release();
    };
    const onDown = (e) => {
      el.setPointerCapture?.(e.pointerId);
      this.pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (this.pointers.size === 2) this.pinch = this.pinchDist();
    };
    const onMove = (e) => {
      const p = this.pointers.get(e.pointerId);
      if (!p) return;
      const dx = e.clientX - p.x, dy = e.clientY - p.y;
      p.x = e.clientX;
      p.y = e.clientY;
      if (!useGame.getState().started) return;
      if (this.pointers.size === 1) {
        const k = e.pointerType === "touch" ? 0.008 : 0.006;
        this.cam.yaw -= dx * k;
        this.cam.pitch = clamp(this.cam.pitch + dy * k * 0.8, 0.06, 1.25);
      } else if (this.pointers.size === 2) {
        const d = this.pinchDist();
        if (this.pinch > 0 && d > 0) this.cam.dist = clamp((this.cam.dist * this.pinch) / d, 5, 20);
        this.pinch = d;
      }
    };
    const onUp = (e) => {
      this.pointers.delete(e.pointerId);
      this.pinch = this.pointers.size === 2 ? this.pinchDist() : 0;
    };
    const onWheel = (e) => {
      e.preventDefault();
      this.cam.dist = clamp(this.cam.dist * (1 + Math.sign(e.deltaY) * 0.09), 5, 20);
    };
    const onCtx = (e) => e.preventDefault();
    window.addEventListener("keydown", onKeyDown);
    window.addEventListener("keyup", onKeyUp);
    window.addEventListener("blur", onBlur);
    el.addEventListener("pointerdown", onDown);
    el.addEventListener("pointermove", onMove);
    el.addEventListener("pointerup", onUp);
    el.addEventListener("pointercancel", onUp);
    el.addEventListener("wheel", onWheel, { passive: false });
    el.addEventListener("contextmenu", onCtx);
    this.unsubs.push(() => {
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
      el.removeEventListener("pointerdown", onDown);
      el.removeEventListener("pointermove", onMove);
      el.removeEventListener("pointerup", onUp);
      el.removeEventListener("pointercancel", onUp);
      el.removeEventListener("wheel", onWheel);
      el.removeEventListener("contextmenu", onCtx);
    });
  }

  pinchDist() {
    const pts = [...this.pointers.values()];
    if (pts.length < 2) return 0;
    return Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
  }

  press() {
    this.fishing.press();
  }
  release() {
    this.fishing.release();
  }
  setJoy(x, y) {
    this.joy.x = x;
    this.joy.y = y;
  }
  interact() {
    const n = this.nearNpc;
    if (!n || this.fishing.phase !== "idle") return;
    if (n === "merchant") openPanel("bag");
    else if (n === "shop") {
      const isMoon = (ISLAND_MAP[useGame.getState().island]?.planet ?? 1) === 2;
      if (isMoon) {
        useGame.setState({ panel: "lunar", lunarTab: "gear" });
        audio.play("click");
      } else {
        openPanel("shop", "rods");
      }
    } else if (n === "rocket") void launchRocketToMoon();
    else if (n === "earth_rocket") void travelTo("spaceport");
    else openPanel("map");
  }
  setPaused(p) {
    this.paused = p;
    if (p) {
      this.keys.clear();
      this.fishing.release();
    }
  }

  applyQuality(low) {
    this.sun.castShadow = !low;
    this.renderer.setPixelRatio(low ? 1 : Math.min(window.devicePixelRatio || 1, this.isMobile ? 1.5 : 2));
    this.resize();
  }

  resize() {
    const w = this.container.clientWidth || 1;
    const h0 = this.container.clientHeight || 1;
    this.renderer.setSize(w, h0);
    this.camera.aspect = w / h0;
    this.camera.fov = w / h0 < 0.8 ? 68 : 55;
    this.camera.updateProjectionMatrix();
    pointScale.value = (h0 * this.renderer.getPixelRatio()) / (2 * Math.tan(THREE.MathUtils.degToRad(this.camera.fov) / 2));
  }

  applyEnv(dt) {
    const s = useGame.getState();
    const ev = s.event && s.event.until > Date.now() ? s.event.id : null;
    this.stormMix = damp(this.stormMix, ev === "storm" ? 1 : 0, 0.7, dt);
    this.starMix = damp(this.starMix, ev === "starfall" ? 1 : 0, 0.7, dt);
    const th = this.theme;
    const sm = this.stormMix, st = this.starMix;
    const top = this.tmpC.copy(this.base.top).lerp(STORM_TOP, sm * 0.8).lerp(NIGHT_TOP, st * 0.85);
    this.sky.u.uTop.value.copy(top);
    const hor = this.tmpC2.copy(this.base.hor).lerp(STORM_HOR, sm * 0.75).lerp(NIGHT_HOR, st * 0.8);
    this.sky.u.uHorizon.value.copy(hor);
    this.water.u.uSky.value.copy(hor);
    const fog = this.scene.fog.color;
    fog.copy(this.base.fog).lerp(STORM_HOR, sm * 0.7).lerp(NIGHT_HOR, st * 0.8);
    this.water.u.uFogColor.value.copy(fog);
    this.sky.u.uStars.value = Math.max(th.stars, st);
    const dim = (1 - 0.5 * sm) * (1 - 0.45 * st);
    this.sun.intensity = th.sunIntensity * dim;
    this.hemi.intensity = th.hemiIntensity * (1 - 0.3 * sm) * (1 - 0.3 * st);
    this.water.u.uDeep.value.copy(this.base.deep).multiplyScalar(1 - 0.3 * Math.max(sm, st));
    this.water.u.uShallow.value.copy(this.base.shallow).multiplyScalar(1 - 0.25 * Math.max(sm, st));
    this.waveAmp = th.waveAmp * (1 + 0.9 * sm);
    this.water.u.uAmp.value = this.waveAmp;
    const w = ev === "storm" ? "rain" : ev === "starfall" ? "stars" : th.weather;
    this.weather.setType(w);
  }

  updatePlayer(dt) {
    const s = useGame.getState();
    const ph = this.fishing.phase;
    let ix = this.joy.x, iy = this.joy.y;
    if (this.keys.has("KeyW") || this.keys.has("ArrowUp")) iy += 1;
    if (this.keys.has("KeyS") || this.keys.has("ArrowDown")) iy -= 1;
    if (this.keys.has("KeyA") || this.keys.has("ArrowLeft")) ix -= 1;
    if (this.keys.has("KeyD") || this.keys.has("ArrowRight")) ix += 1;
    let len = Math.hypot(ix, iy);
    if (len > 1) {
      ix /= len;
      iy /= len;
      len = 1;
    }
    const canMove = s.started && !s.panel && !s.fade && (ph === "idle" || ph === "waiting" || ph === "reelback");
    this.moving = false;
    const p = this.player.pos;
    if (canMove && len > 0.08) {
      if (ph === "waiting") this.fishing.reelBack();
      const y = this.cam.yaw;
      const mx = -Math.sin(y) * iy + Math.cos(y) * ix;
      const mz = -Math.cos(y) * iy - Math.sin(y) * ix;
      const sp = 6.4 * Math.min(1, len);
      let nx = p.x + mx * sp * dt;
      let nz = p.z + mz * sp * dt;
      for (const c of this.island?.colliders ?? []) {
        const dx = nx - c.x, dz = nz - c.z;
        const d = Math.hypot(dx, dz);
        const minD = c.r + 0.45;
        if (d < minD && d > 1e-4) {
          nx = c.x + (dx / d) * minD;
          nz = c.z + (dz / d) * minD;
        }
      }
      if (!isWalkable(nx, nz)) {
        if (isWalkable(nx, p.z)) nz = p.z;
        else if (isWalkable(p.x, nz)) nx = p.x;
        else {
          nx = p.x;
          nz = p.z;
        }
      }
      if (Math.hypot(nx - p.x, nz - p.z) > 1e-4) this.moving = true;
      p.x = nx;
      p.z = nz;
      this.player.heading = lerpAngle(this.player.heading, Math.atan2(mx, mz), 1 - Math.exp(-14 * dt));
    }
    if (ph === "caught") {
      const cx = this.camera.position.x - p.x, cz = this.camera.position.z - p.z;
      this.player.heading = lerpAngle(this.player.heading, Math.atan2(cx, cz), 1 - Math.exp(-8 * dt));
    }
    p.y = damp(p.y, groundHeight(p.x, p.z), 14, dt);

    let best = null;
    let bd = 3.3;
    for (const n of this.island?.npcs ?? []) {
      const d = Math.hypot(p.x - n.x, p.z - n.z);
      if (d < bd) {
        bd = d;
        best = n.kind;
      }
    }
    if (best !== this.nearNpc) {
      this.nearNpc = best;
      useGame.setState({ nearNpc: best });
    }
  }

  animateRig(dt) {
    const rig = this.rig;
    const f = this.fishing;
    const ph = f.phase;
    const tm = this.time;
    this.walkBlend = damp(this.walkBlend, this.moving ? 1 : 0, 10, dt);
    if (this.moving) this.walkPhase += dt * 11;
    const sw = Math.sin(this.walkPhase) * 0.75 * this.walkBlend;
    rig.legL.rotation.x = sw;
    rig.legR.rotation.x = -sw;
    rig.body.position.y = Math.abs(Math.cos(this.walkPhase)) * 0.09 * this.walkBlend + Math.sin(tm * 2) * 0.012;
    let armR = -0.5 + sw * 0.15;
    let armL = -sw * 0.8;
    let lean = 0;
    let bend = 0.04;
    switch (ph) {
      case "charging": armR = -0.9 - f.power * 2.4; armL = -0.4; lean = -0.08 * f.power; bend = 0; break;
      case "casting": armR = -1.0; armL = -0.3; bend = 0.1; break;
      case "waiting": armR = -0.75 + Math.sin(tm * 1.5) * 0.03; armL = -0.5; bend = 0.08; break;
      case "bite": armR = -0.95 + Math.sin(tm * 40) * 0.05; armL = -0.7; bend = 0.35; break;
      case "reeling": armR = -1.05 + Math.sin(tm * 22) * 0.06; armL = -0.9 + Math.sin(tm * 14) * 0.35; lean = -0.12; bend = 0.45 + Math.sin(tm * 9) * 0.12; break;
      case "caught": armR = -1.75; armL = -1.75; break;
      case "reelback": armR = -0.8; break;
      default: break;
    }
    rig.armR.rotation.x = damp(rig.armR.rotation.x, armR, ph === "casting" ? 24 : 12, dt);
    rig.armL.rotation.x = damp(rig.armL.rotation.x, armL, 10, dt);
    rig.body.rotation.x = damp(rig.body.rotation.x, lean, 8, dt);
    if (rig.rodPivots.length === 3) {
      rig.rodPivots[1].rotation.x = damp(rig.rodPivots[1].rotation.x, bend * 0.5, 10, dt);
      rig.rodPivots[2].rotation.x = damp(rig.rodPivots[2].rotation.x, bend * 0.8, 10, dt);
    }
    if (rig.rod) rig.rod.visible = ph !== "caught";
    rig.root.position.copy(this.player.pos);
    rig.root.rotation.y = this.player.heading;
    const rod = ROD_MAP[useGame.getState().rod];
    if (rod?.rainbow && rig.rodMain) {
      rig.rodMain.color.setHSL((tm * 0.2) % 1, 0.85, 0.65);
      rig.rodMain.emissive.copy(rig.rodMain.color);
    }
  }

  animateNpcs() {
    const tm = this.time;
    (this.island?.npcs ?? []).forEach((n, i) => {
      const r = n.rig;
      r.body.position.y = Math.sin(tm * 2 + i) * 0.02;
      r.armL.rotation.x = Math.sin(tm * 1.4 + i) * 0.12;
      const waving = this.nearNpc === n.kind;
      r.armR.rotation.x = waving ? -2.7 + Math.sin(tm * 9) * 0.25 : Math.sin(tm * 1.4 + i + 1) * 0.12;
      r.head.rotation.y = Math.sin(tm * 0.6 + i * 2) * 0.35;
    });
  }

  updateLine() {
    const f = this.fishing;
    const ph = f.phase;
    const on = ph === "casting" || ph === "waiting" || ph === "bite" || ph === "reeling" || ph === "rescue" || ph === "reelback";
    this.bobber.visible = on;
    this.line.visible = on;
    this.exclaim.visible = ph === "bite";
    if (this.exclaim.visible) {
      const s = 1.1 + Math.abs(Math.sin(this.time * 10)) * 0.25;
      this.exclaim.scale.set(s, s, 1);
      this.exclaim.position.set(this.player.pos.x, this.player.pos.y + 3.2, this.player.pos.z);
    }
    if (!on) return;
    this.bobber.position.copy(f.bob);
    this.rig.root.updateMatrixWorld(true);
    this.rig.rodTip?.getWorldPosition(this.rodTipWorld);
    const a = this.rodTipWorld, b = f.bob;
    const sag = ph === "waiting" ? 1.0 : ph === "casting" || ph === "reelback" ? 0.25 : 0.06;
    const n = 24;
    for (let i = 0; i < n; i++) {
      const k = i / (n - 1);
      this.linePos[i * 3] = a.x + (b.x - a.x) * k;
      this.linePos[i * 3 + 1] = a.y + (b.y + 0.15 - a.y) * k - Math.sin(k * Math.PI) * sag;
      this.linePos[i * 3 + 2] = a.z + (b.z - a.z) * k;
    }
    this.line.geometry.attributes.position.needsUpdate = true;
  }

  updateCamera(dt) {
    const s = useGame.getState();
    let tx, ty, tz, dist, yaw, pitch;
    if (!s.started) {
      this.menuYaw += dt * 0.07;
      tx = 2; ty = 2; tz = 0; dist = 30; yaw = this.menuYaw; pitch = 0.3;
    } else {
      tx = this.player.pos.x; ty = this.player.pos.y + 1.7; tz = this.player.pos.z;
      dist = this.showcase ? 6.4 : this.cam.dist;
      yaw = this.cam.yaw;
      pitch = this.showcase ? Math.min(this.cam.pitch, 0.3) : this.cam.pitch;
    }
    const k = 1 - Math.exp(-7 * dt);
    this.camTarget.x += (tx - this.camTarget.x) * k;
    this.camTarget.y += (ty - this.camTarget.y) * k;
    this.camTarget.z += (tz - this.camTarget.z) * k;
    this.curDist = damp(this.curDist, dist, 4, dt);
    this.curYaw = lerpAngle(this.curYaw, yaw, 1 - Math.exp(-(s.started ? 16 : 3) * dt));
    this.curPitch = damp(this.curPitch, pitch, 10, dt);
    const cp = Math.cos(this.curPitch);
    const c = this.camera.position;
    c.set(
      this.camTarget.x + Math.sin(this.curYaw) * cp * this.curDist,
      this.camTarget.y + Math.sin(this.curPitch) * this.curDist,
      this.camTarget.z + Math.cos(this.curYaw) * cp * this.curDist
    );
    const minY = waveHeight(c.x, c.z, this.time, this.waveAmp) + 0.8;
    if (c.y < minY) c.y = minY;
    this.camera.lookAt(this.camTarget);
  }

  update(dt) {
    this.time += dt;
    const s = useGame.getState();
    const tm = this.time;
    this.applyEnv(dt);
    this.updatePlayer(dt);
    this.fishing.update(dt);
    this.animateRig(dt);
    this.animateNpcs();
    this.updateLine();
    this.island?.update(tm, dt, this.waveAmp);
    const frenzy = !!(s.event && s.event.id === "frenzy" && s.event.until > Date.now());
    this.updateHotspots(dt, frenzy);

    for (const r of this.ripples) {
      if (r.t >= 1) continue;
      r.t += dt / 1.2;
      if (r.t >= 1) {
        r.m.visible = false;
        continue;
      }
      r.m.position.y = waveHeight(r.m.position.x, r.m.position.z, tm, this.waveAmp) + 0.04;
      r.m.scale.setScalar(1 + r.t * 5);
      r.m.material.opacity = (1 - r.t) * 0.75;
    }

    this.smokeT -= dt;
    if (this.smokeT <= 0 && this.island?.smoke.length) {
      this.smokeT = 0.18;
      const sm = this.island.smoke;
      const v = sm[0];
      this.splash.emit(v.x + (Math.random() - 0.5) * 6, v.y, v.z + (Math.random() - 0.5) * 6, { count: 1, speed: 1, up: 3, color: "#5a4a4a", size: 9, life: 5, gravity: 0.4, drag: 0.1 });
      const lp = sm[1 + Math.floor(Math.random() * (sm.length - 1))];
      if (lp && Math.random() < 0.6) this.sparkles.emit(lp.x, lp.y, lp.z, { count: 2, speed: 0.6, up: 2.5, color: "#ff8a2a", size: 0.25, life: 1.2, gravity: 0.5 });
    }

    this.splash.update(dt);
    this.sparkles.update(dt);
    this.weather.update(dt, this.camera.position, tm);

    for (const c of this.clouds.children) {
      c.position.x += dt * 1.6;
      if (c.position.x > 240) c.position.x -= 480;
    }
    this.birds.forEach((b) => {
      if (!b.g.visible) return;
      const a = tm * b.sp + b.ph;
      b.g.position.set(Math.cos(a) * b.r, b.h + Math.sin(tm * 0.7 + b.ph) * 1.2, Math.sin(a) * b.r);
      b.g.rotation.y = -a;
      const fl = Math.sin(tm * 7 + b.ph) * 0.6;
      b.wl.rotation.z = fl;
      b.wr.rotation.z = -fl;
    });

    this.updateCamera(dt);
    this.sky.mesh.position.copy(this.camera.position);
    this.water.u.uTime.value = tm;
    this.sky.u.uTime.value = tm;
    const sd = this.water.u.uSunDir.value;
    const p = this.player.pos;
    const focusX = s.started ? p.x : 2, focusZ = s.started ? p.z : 0;
    this.sun.position.set(focusX + sd.x * 50, sd.y * 50, focusZ + sd.z * 50);
    this.sun.target.position.set(focusX, 0, focusZ);
  }

  loop() {
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(this.clock.getDelta(), 0.05);
    if (this.paused && !this.firstFrame) return;
    this.update(dt);
    this.renderer.render(this.scene, this.camera);
    if (this.firstFrame) {
      this.firstFrame = false;
      useGame.setState({ engineReady: true });
    }
  }

  dispose() {
    cancelAnimationFrame(this.raf);
    this.unsubs.forEach((u) => u());
    this.ro.disconnect();
    this.renderer.dispose();
    this.renderer.domElement.remove();
  }
}

export const runtime = { engine: null };
export const eventKey = (id) => (id === "storm" ? "evStorm" : id === "starfall" ? "evStarfall" : "evFrenzy");

let booted = false;

function isGameplay(s = S()) {
  return s.started && s.engineReady && !s.adBusy && !s.paymentBusy && !s.panel && !s.fade && !s.hidden && !s.sdkPaused && s.phase !== "rescue";
}

let bannerRequested = false;
async function showGameBanner() {
  if (bannerRequested || !YA.available) return;
  bannerRequested = true;
  set({ bannerShown: await YA.showBanner() });
}

export async function boot() {
  if (booted) return;
  booted = true;
  YA.onPause((p) => set({ sdkPaused: p }));
  loadLocalSave();
  YA.onReady(() => {
    const current = S();
    if (!current.lang) {
      const lang = detectLang(YA.lang());
      setLangInternal(lang);
      set({ curLang: lang });
    }
    set({ rewardAvailable: YA.rewardedAvailable });
    if (current.engineReady) YA.loadingReady();
    YA.gameplay(isGameplay());
    if (current.started) void showGameBanner();
    void syncCloudSave();
  });
  await YA.init();
  const isMobile = YA.isMobile() ?? (window.matchMedia("(pointer: coarse)").matches || "ontouchstart" in window);
  if (YA.available) {
    let timer;
    try {
      await Promise.race([syncCloudSave(), new Promise((resolve) => { timer = setTimeout(resolve, 8000); })]);
    } finally { clearTimeout(timer); }
  }
  startAutoSave();

  const syncVisibility = () => {
    const isHidden = document.hidden || !document.hasFocus();
    useGame.setState({ hidden: isHidden });
    if (isHidden) flushSave(true);
  };

  document.addEventListener("visibilitychange", syncVisibility);
  window.addEventListener("blur", () => {
    useGame.setState({ hidden: true });
    flushSave(true);
  });
  window.addEventListener("focus", () => {
    useGame.setState({ hidden: document.hidden });
  });
  window.addEventListener("pagehide", () => flushSave(true));
  window.addEventListener("beforeunload", () => flushSave(true));

  const stop = (e) => e.preventDefault();
  document.addEventListener("gesturestart", stop);
  document.addEventListener("dblclick", stop);

  window.addEventListener(
    "pointerdown",
    () => {
      if (!document.hidden && S().hidden) set({ hidden: false });
      const st = S();
      if (st.started && !st.hidden && !st.adBusy && !st.paymentBusy && !st.sdkPaused) {
        audio.init();
      }
    },
    { capture: true }
  );

  let prevPaused;
  useGame.subscribe((st) => {
    const paused = st.hidden || st.adBusy || st.paymentBusy || st.sdkPaused;
    if (paused !== prevPaused) {
      prevPaused = paused;
      audio.setPaused(paused);
      runtime.engine?.setPaused(paused);
    }
    if (st.engineReady) YA.loadingReady();
    YA.gameplay(isGameplay(st));
  });
  set({ isMobile, saveLoaded: true });

  let nextEvent = Date.now() + 150000;
  window.setInterval(() => {
    const st = useGame.getState();
    if (st.hidden || st.sdkPaused || st.adBusy || st.paymentBusy) return;
    void postEarnings();
    const now = Date.now();
    const patch = { now };
    if (st.event && st.event.until <= now) patch.event = null;
    if (!st.event && st.started && now >= nextEvent) {
      const ev = EVENTS[Math.floor(Math.random() * EVENTS.length)];
      patch.event = { id: ev.id, until: now + ev.duration * 1000 };
      nextEvent = now + ev.duration * 1000 + (180 + Math.random() * 180) * 1000;
      toast(`${ev.icon} ${t("evStarted")} ${t(eventKey(ev.id))}`, "#ffe066");
      audio.play("quest");
    }
    if (st.autoOn && !autoAvailable(st)) {
      patch.autoOn = false;
      toast("🤖 " + t("autoOff"));
    }
    useGame.setState(patch);
  }, 1000);
}

export function startGame() {
  useGame.setState({ hidden: false });
  audio.init();
  const s = useGame.getState();
  audio.setSound(s.sound);
  audio.setMusic(s.music);
  set({ started: true });
  void showGameBanner();
  if (S().cloudReady || !cloudSync) void refreshPayments();
}

export async function requestAuth() {
  if (!YA.available || S().paymentBusy || S().adBusy || cloudSync || scorePosting) return;
  const oldReady = S().cloudReady;
  const oldConflict = S().cloudConflict;
  if (oldReady && cloudScheduled) {
    clearTimeout(cloudScheduled);
    cloudScheduled = undefined;
  }
  set({ paymentBusy: true });
  try {
    await cloudQueue;
    const ok = await YA.openAuthDialog();
    if (!ok) return;
    payments = undefined;
    restoredPurchases = false;
    bestSent = undefined;
    persistLocal();
    // Reconcile the signed-in cloud without silently discarding progress made after local load.
    set({ authorized: true, cloudReady: false, cloudConflict: null, products: null });
    if (oldConflict) flagConflict(true);
    await syncCloudSave();
    if (S().cloudReady) toast("☁️ " + t("authDone"), "#7ef07e");
  } finally {
    set({ paymentBusy: false });
    if (S().authorized && S().cloudReady) void refreshPayments();
  }
}

function Coin({ size = 20, className }) {
  return h(
    "svg",
    { width: size, height: size, viewBox: "0 0 24 24", className: cn("inline-block shrink-0 drop-shadow", className) },
    h("circle", { cx: "12", cy: "12", r: "11", fill: "#e8a317" }),
    h("circle", { cx: "12", cy: "12", r: "9", fill: "#ffd34d" }),
    h("circle", { cx: "12", cy: "12", r: "6.5", fill: "none", stroke: "#e8a317", strokeWidth: "1.5" }),
    h("path", { d: "M8 12.5c1.6-2.2 4.6-2.6 7-.5-2.4 2.1-5.4 1.7-7-.5zM15 12l2-1.5v3z", fill: "#c77d0a" })
  );
}

function Price({ n, className, size = 18 }) {
  return h(
    "span",
    { className: cn("inline-flex items-center gap-1 font-extrabold tabular-nums", className) },
    h(Coin, { size }),
    fmtNum(n)
  );
}

function Diamond({ size = 20, className }) {
  return h(
    "svg",
    { width: size, height: size, viewBox: "0 0 24 24", className: cn("inline-block shrink-0 drop-shadow", className) },
    h("polygon", { points: "12,2 21,9 12,22 3,9", fill: "#0284c7" }),
    h("polygon", { points: "12,2 18,9 12,20 6,9", fill: "#38bdf8" }),
    h("polygon", { points: "12,2 18,9 6,9", fill: "#bae6fd" }),
    h("polygon", { points: "6,9 12,9 12,20", fill: "#0ea5e9" })
  );
}

function DiamondPrice({ n, className, size = 18 }) {
  return h(
    "span",
    { className: cn("inline-flex items-center gap-1 font-extrabold tabular-nums text-[#7dd3fc]", className) },
    h(Diamond, { size }),
    fmtNum(n)
  );
}

function RarityPill({ id, className }) {
  const r = RARITY[id];
  return h(
    "span",
    {
      className: cn("inline-block rounded-full px-2 py-0.5 text-[11px] font-extrabold uppercase tracking-wide text-[#0b2546]", id === "secret" && "rainbow-bg", className),
      style: id === "secret" ? undefined : { background: r.color },
    },
    tr(r.name)
  );
}

function MutPill({ id, className }) {
  const m = MUTATION[id];
  if (!m) return null;
  return h(
    "span",
    {
      className: cn("inline-block rounded-full px-2 py-0.5 text-[11px] font-extrabold uppercase text-[#2a1a4a]", m.color === "rainbow" && "rainbow-bg", className),
      style: m.color === "rainbow" ? undefined : { background: m.color },
    },
    `✦ ${tr(m.name)} ×${m.mult}`
  );
}

function StatBar({ label, value, max, color }) {
  return h(
    "div",
    { className: "flex items-center gap-2 text-[11px] font-bold text-white/85" },
    h("span", { className: "w-16 shrink-0 truncate" }, label),
    h(
      "div",
      { className: "h-2 flex-1 overflow-hidden rounded-full bg-black/30" },
      h("div", { className: "h-full rounded-full", style: { width: `${Math.min(100, (value / max) * 100)}%`, background: color } })
    ),
    h("span", { className: "w-10 text-right tabular-nums" }, `+${value}`)
  );
}

function PanelShell({ title, icon, onClose, children, footer }) {
  return h(
    "div",
    {
      className: "absolute inset-0 z-40 flex items-center justify-center bg-[#04142a]/55 p-2 backdrop-blur-[2px] sm:p-4",
      onPointerDown: (e) => e.target === e.currentTarget && onClose(),
    },
    h(
      "div",
      { className: "panel-bg anim-pop relative flex max-h-full w-full max-w-[760px] flex-col overflow-hidden rounded-[28px]", style: { height: "min(640px, 100%)" } },
      h(
        "div",
        { className: "flex items-center gap-3 border-b-2 border-black/20 bg-black/15 px-4 py-3" },
        h("span", { className: "text-3xl drop-shadow" }, icon),
        h("h2", { className: "txt-o flex-1 truncate text-xl font-extrabold text-white sm:text-2xl" }, title),
        h("button", { className: "btn btn-red h-10 w-10 rounded-full text-xl", onClick: onClose, "aria-label": t("close") }, "✕")
      ),
      h("div", { className: "scroll-y flex-1 p-3 sm:p-4" }, children),
      footer && h("div", { className: "border-t-2 border-black/20 bg-black/20 px-3 py-3 sm:px-4" }, footer)
    )
  );
}

const SHAPE_SVG = {
  normal: { body: "M20,30 C26,12 60,10 80,24 C86,28 86,32 80,36 C60,50 26,48 20,30 Z", tail: "M24,30 L6,15 L11,30 L6,45 Z", fin: "M40,16 L58,14 L47,4 Z", eye: [72, 27, 3.6] },
  long: { body: "M16,30 C24,22 70,20 90,27 C93,29 93,31 90,33 C70,40 24,38 16,30 Z", tail: "M19,30 L3,23 L3,37 Z", fin: "M26,24 L80,23 L76,18 L30,18 Z", eye: [84, 28, 2.6] },
  round: { body: "M28,30 C28,9 74,8 77,30 C74,52 28,51 28,30 Z", tail: "M31,30 L13,17 Q9,30 13,43 Z", fin: "M44,12 L61,12 L50,3 Z", eye: [66, 24, 4.2] },
  tall: { body: "M26,30 C30,6 64,6 78,28 C80,30 80,32 78,34 C64,54 30,54 26,30 Z", tail: "M29,30 L12,17 L17,30 L12,43 Z", fin: "M38,11 L58,12 L42,0 Z M38,49 L58,48 L42,60 Z", eye: [68, 26, 3.6] },
  shark: { body: "M14,32 C26,18 66,15 95,30 C70,41 30,45 14,32 Z", tail: "M19,31 L3,12 L10,31 L5,46 Z", fin: "M45,20 L61,18 L49,4 Z", eye: [81, 28, 2.6] },
  ray: { body: "M52,9 L88,30 L52,48 L16,30 Z", tail: "M20,29.2 L0,30 L20,30.8 Z", fin: "", eye: [66, 27, 2.6] },
  squid: { body: "M30,30 C34,17 70,15 94,30 C70,45 34,43 30,30 Z", tail: "M33,26 L5,16 M33,28.5 L3,25 M33,31.5 L3,35 M33,34 L5,44 M33,30 L1,30", fin: "M86,25 L98,18 L94,30 L98,42 L86,35 Z", eye: [40, 27, 4], lines: true },
  sword: { body: "M20,30 C26,14 60,12 80,25 C86,28 86,32 80,35 C60,48 26,46 20,30 Z", tail: "M24,30 L6,13 L12,30 L6,47 Z", fin: "M40,17 L57,15 L46,3 Z M82,29 L100,30 L82,31 Z", eye: [72, 27, 3] },
  jelly: { body: "M86,30 C86,8 44,8 44,30 C44,38 86,38 86,30 Z", tail: "M44,33 L14,44 M50,36 L22,52 M58,37 L36,56 M68,37 L54,58 M78,36 L72,56", fin: "", eye: [72, 24, 3.6], lines: true },
};

function FishIcon({ def, mut = null, silhouette = false, className }) {
  const uid = useId().replace(/:/g, "");
  const s = SHAPE_SVG[def.shape];
  let body = def.body, belly = def.belly, fin = def.fin, accent = def.accent ?? def.fin;
  let opacity = 1;
  let filter;
  if (mut === "albino") [body, belly, fin, accent] = ["#f6f2f0", "#ffffff", "#ffc8d0", "#ffe0e6"];
  if (mut === "golden") [body, belly, fin, accent] = ["#ffcf33", "#fff0a0", "#ffb300", "#ffe680"];
  if (mut === "galaxy") [body, belly, fin, accent] = ["#2a1a6a", "#6a3aff", "#ff6aff", "#ffffff"];
  if (mut === "ghost") {
    opacity = 0.6;
    [body, belly, fin] = ["#a6f4ff", "#e0fbff", "#7fe0ff"];
  }
  if (mut === "crystal") [body, belly, fin, accent] = ["#9fe8ff", "#eafaff", "#c6b0ff", "#ffffff"];
  if (mut === "solar") [body, belly, fin, accent] = ["#ffb02e", "#fff2a0", "#ff6a1a", "#fff6d0"];
  if (mut === "void") [body, belly, fin, accent] = ["#1a0a2a", "#3a1a5a", "#8a2aff", "#c66aff"];
  const glowCols = { golden: "#ffd34d", shiny: "#fff6a0", crystal: "#9fe8ff", solar: "#ffb02e", void: "#8a2aff" };
  if (glowCols[mut ?? ""] || def.glow) filter = `drop-shadow(0 0 4px ${glowCols[mut ?? ""] ?? def.fin})`;
  if (silhouette) {
    body = belly = fin = accent = "#0b2546";
    opacity = 0.55;
    filter = undefined;
  }
  const rainbow = mut === "rainbow" && !silhouette;
  const pattern = silhouette ? undefined : mut === "galaxy" ? "spots" : def.pattern;
  return h(
    "svg",
    { viewBox: "0 0 100 60", className, style: { opacity, filter, overflow: "visible" } },
    h(
      "defs",
      null,
      h(
        "linearGradient",
        { id: `g${uid}`, x1: "0", y1: "0", x2: rainbow ? "1" : "0", y2: rainbow ? "0" : "1" },
        rainbow
          ? ["#ff4d6d", "#ffb02e", "#ffe14d", "#5ddc5d", "#3dfcff", "#4a7dff", "#b46cff"].map((c, i) =>
              h("stop", { key: c, offset: i / 6, stopColor: c })
            )
          : [
              h("stop", { key: "a", offset: "0.15", stopColor: body }),
              h("stop", { key: "b", offset: "0.95", stopColor: belly }),
            ]
      ),
      h("clipPath", { id: `c${uid}` }, h("path", { d: s.body }))
    ),
    s.lines
      ? h("path", { d: s.tail, stroke: rainbow ? "#b46cff" : fin, strokeWidth: "3.5", strokeLinecap: "round", fill: "none" })
      : h("path", { d: s.tail, fill: rainbow ? "#ff4d6d" : fin, stroke: "rgba(0,0,0,.3)", strokeWidth: "1.2" }),
    s.fin && h("path", { d: s.fin, fill: rainbow ? "#3dfcff" : fin, stroke: "rgba(0,0,0,.3)", strokeWidth: "1.2" }),
    h("path", { d: s.body, fill: `url(#g${uid})`, stroke: "rgba(0,0,0,.38)", strokeWidth: "1.6" }),
    pattern === "stripes" &&
      h(
        "g",
        { clipPath: `url(#c${uid})`, opacity: "0.8" },
        [34, 46, 58, 70].map((x) => h("rect", { key: x, x, y: "0", width: "5", height: "44", fill: accent }))
      ),
    pattern === "spots" &&
      h(
        "g",
        { clipPath: `url(#c${uid})`, opacity: "0.85" },
        [[34, 24], [44, 30], [52, 21], [60, 33], [40, 36], [66, 24], [28, 30], [56, 40]].map(([x, y]) =>
          h("circle", { key: `${x}-${y}`, cx: x, cy: y, r: "2.4", fill: accent })
        )
      ),
    !silhouette &&
      h(
        React.Fragment,
        null,
        h("circle", { cx: s.eye[0], cy: s.eye[1], r: s.eye[2], fill: "#fff", stroke: "rgba(0,0,0,.4)", strokeWidth: "0.8" }),
        h("circle", { cx: s.eye[0] + s.eye[2] * 0.25, cy: s.eye[1], r: s.eye[2] * 0.55, fill: mut === "albino" ? "#e0263a" : "#111" })
      )
  );
}

function rarityGlow(id) {
  const c = RARITY[id].color;
  return `0 0 0 2px ${c}, 0 0 18px ${c}88`;
}

function TapOverlay() {
  const phase = useGame((s) => s.phase);
  const panel = useGame((s) => s.panel);
  if (panel || !(phase === "bite" || phase === "reeling" || phase === "caught")) return null;
  return h("div", {
    className: "absolute inset-0 z-10",
    onPointerDown: (e) => {
      e.preventDefault();
      runtime.engine?.press();
    },
  });
}

function ChargeMeter() {
  const phase = useGame((s) => s.phase);
  const fillRef = useRef(null);
  const markRef = useRef(null);
  useEffect(() => {
    if (phase !== "charging") return;
    let raf = 0;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      const p = runtime.engine?.fishing.power ?? 0;
      if (fillRef.current) fillRef.current.style.width = `${p * 100}%`;
      if (markRef.current) markRef.current.style.left = `${p * 100}%`;
    };
    loop();
    return () => cancelAnimationFrame(raf);
  }, [phase]);
  if (phase !== "charging") return null;
  return h(
    "div",
    { className: "pointer-events-none absolute bottom-[150px] left-1/2 z-20 w-[min(80vw,360px)] -translate-x-1/2 sm:bottom-[60px]" },
    h("div", { className: "txt-o mb-1 text-center text-sm font-extrabold text-white" }, t("hintCharge")),
    h(
      "div",
      { className: "relative h-7 overflow-hidden rounded-full border-4 border-[#0b2546] bg-[#0b2546]/70" },
      h("div", { className: "absolute inset-y-0 left-0 w-[42%] bg-red-500/40" }),
      h("div", { className: "absolute inset-y-0 left-[42%] w-[33%] bg-yellow-400/40" }),
      h("div", { className: "absolute inset-y-0 left-[75%] w-[17%] bg-green-400/50" }),
      h("div", { className: "absolute inset-y-0 left-[92%] w-[8%] bg-yellow-200/90" }),
      h("div", { ref: fillRef, className: "absolute inset-y-0 left-0 bg-gradient-to-r from-red-400 via-yellow-300 to-green-400 opacity-70" }),
      h("div", { ref: markRef, className: "absolute -top-1 -bottom-1 w-1.5 -translate-x-1/2 rounded bg-white shadow-[0_0_8px_#fff]" })
    )
  );
}

function Minigame() {
  const phase = useGame((s) => s.phase);
  const caught = useGame((s) => s.stats.caught);
  const zoneRef = useRef(null);
  const perfRef = useRef(null);
  const markRef = useRef(null);
  const progRef = useRef(null);
  const fishRef = useRef(null);
  const [res, setRes] = useState(null);
  const [rarity, setRarity] = useState(null);

  useEffect(() => {
    if (phase !== "reeling") {
      setRes(null);
      return;
    }
    let raf = 0;
    let lastKey = 0;
    const loop = () => {
      raf = requestAnimationFrame(loop);
      const mg = runtime.engine?.fishing.mg;
      if (!mg) return;
      setRarity((r) => (r === mg.rarity ? r : mg.rarity));
      if (zoneRef.current) {
        zoneRef.current.style.left = `${mg.zoneStart * 100}%`;
        zoneRef.current.style.width = `${mg.zoneWidth * 100}%`;
      }
      if (perfRef.current) {
        perfRef.current.style.left = `${((mg.zoneWidth - mg.perfectWidth) / 2 / mg.zoneWidth) * 100}%`;
        perfRef.current.style.width = `${(mg.perfectWidth / mg.zoneWidth) * 100}%`;
      }
      if (markRef.current) markRef.current.style.left = `${mg.marker * 100}%`;
      const p = Math.max(0, Math.min(1, mg.progress));
      if (progRef.current) progRef.current.style.width = `${p * 100}%`;
      if (fishRef.current) fishRef.current.style.left = `${p * 100}%`;
      if (mg.resultKey !== lastKey) {
        lastKey = mg.resultKey;
        setRes({ k: mg.resultKey, r: mg.result });
      }
    };
    loop();
    return () => cancelAnimationFrame(raf);
  }, [phase]);

  if (phase !== "reeling") return null;
  const rc = rarity ? RARITY[rarity] : null;
  const resText = res?.r === "perfect" ? t("mgPerfect") : res?.r === "good" ? t("mgGood") : res?.r === "miss" ? t("mgMiss") : "";
  const resColor = res?.r === "perfect" ? "#ffe14d" : res?.r === "good" ? "#7ef07e" : "#ff6a6a";
  return h(
    "div",
    { className: "pointer-events-none absolute bottom-[150px] left-1/2 z-20 w-[min(90vw,540px)] -translate-x-1/2 sm:bottom-[48px]" },
    res &&
      resText &&
      h("div", { key: res.k, className: "anim-float txt-o2 absolute -top-12 left-1/2 text-3xl font-extrabold", style: { color: resColor } }, resText),
    h(
      "div",
      { className: "mb-1 flex items-center justify-between gap-2" },
      h("span", { className: "txt-o text-sm font-extrabold text-white" }, `🎣 ${t("onLine")}`),
      rc && h(RarityPill, { id: rc.id })
    ),
    h(
      "div",
      { className: "relative mb-2 h-4 rounded-full border-2 border-[#0b2546] bg-[#0b2546]/70" },
      h("div", {
        ref: progRef,
        className: cn("h-full rounded-full", rc?.id === "secret" && "rainbow-bg"),
        style: { background: rc && rc.id !== "secret" ? rc.color : undefined, width: "20%" },
      }),
      h("div", { ref: fishRef, className: "absolute -top-3 -translate-x-1/2 text-xl drop-shadow" }, "🐟")
    ),
    h(
      "div",
      { className: "relative h-12 overflow-hidden rounded-2xl border-4 border-[#0b2546] bg-[#0b2546]/80 shadow-lg" },
      h(
        "div",
        { ref: zoneRef, className: "absolute inset-y-0 bg-gradient-to-b from-[#8ff58f] to-[#2fb84a]" },
        h("div", { ref: perfRef, className: "absolute inset-y-0 bg-gradient-to-b from-[#fff6a0] to-[#ffc93a] shadow-[0_0_12px_#ffe14d]" })
      ),
      h("div", { ref: markRef, className: "absolute -top-1 -bottom-1 w-2 -translate-x-1/2 rounded-full bg-white shadow-[0_0_10px_#fff]" })
    ),
    caught < 4 && h("div", { className: "txt-o mt-2 text-center text-sm font-bold text-white" }, t("hintReel"))
  );
}

function BitePrompt() {
  const phase = useGame((s) => s.phase);
  if (phase !== "bite") return null;
  return h(
    "div",
    { className: "pointer-events-none absolute left-1/2 top-[30%] z-20 -translate-x-1/2 text-center" },
    h("div", { className: "anim-shake txt-o2 text-5xl font-extrabold text-[#ffe14d] sm:text-6xl" }, t("actHook")),
    h("div", { className: "txt-o mt-1 text-lg font-bold text-white" }, t("hintHook"))
  );
}

function CastLabel() {
  const cl = useGame((s) => s.castLabel);
  const [show, setShow] = useState(false);
  useEffect(() => {
    if (!cl) return;
    setShow(true);
    const id = setTimeout(() => setShow(false), 900);
    return () => clearTimeout(id);
  }, [cl]);
  if (!cl || !show) return null;
  return h(
    "div",
    { key: cl.key, className: "anim-float txt-o2 pointer-events-none absolute left-1/2 top-[38%] z-20 text-4xl font-extrabold", style: { color: cl.color } },
    cl.text
  );
}

function CatchPopup() {
  const info = useGame((s) => s.catchInfo);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    if (!info) return;
    setVisible(true);
    if (info.adBreak) return;
    const id = setTimeout(() => setVisible(false), 3000);
    return () => clearTimeout(id);
  }, [info]);
  if (!info || !visible) return null;
  const def = FISH_MAP[info.fish.id];
  if (!def) return null;
  const r = RARITY[def.rarity];
  return h(
    "div",
    { className: "pointer-events-none absolute left-1/2 top-16 z-30 w-[min(92vw,380px)] -translate-x-1/2 sm:top-20" },
    h(
      "div",
      {
        key: info.key,
        className: "anim-drop relative overflow-hidden rounded-3xl border-4 border-[#0b2546] bg-gradient-to-b from-[#24609f] to-[#123764] p-3 text-white",
        style: { boxShadow: `0 0 0 3px ${r.color}, 0 0 30px ${r.color}aa, 0 10px 30px rgba(0,0,0,.4)` },
      },
      h("div", { className: "absolute inset-0 opacity-25", style: { background: `radial-gradient(circle at 30% 40%, ${r.color}, transparent 60%)` } }),
      h(
        "div",
        { className: "relative flex items-center gap-3" },
        h(
          "div",
          { className: "relative h-20 w-28 shrink-0" },
          h("div", { className: "anim-spin absolute inset-0 rounded-full opacity-40", style: { background: `conic-gradient(from 0deg, transparent, ${r.color}, transparent, ${r.color}, transparent)` } }),
          h(FishIcon, { def, mut: info.fish.m, className: "relative h-full w-full" })
        ),
        h(
          "div",
          { className: "min-w-0 flex-1" },
          h(
            "div",
            { className: "flex flex-wrap items-center gap-1.5" },
            h("span", { className: "text-xs font-extrabold uppercase tracking-wider text-white/70" }, t("caught")),
            info.isNew && h("span", { className: "rounded-full bg-[#ff4d6d] px-2 py-0.5 text-[10px] font-extrabold" }, t("newFish"))
          ),
          h("div", { className: cn("truncate text-lg font-extrabold leading-tight", def.rarity === "secret" && "rainbow-text") }, tr(def.name)),
          h(
            "div",
            { className: "mt-1 flex flex-wrap items-center gap-1.5" },
            h(RarityPill, { id: def.rarity }),
            info.fish.m && h(MutPill, { id: info.fish.m })
          ),
          h(
            "div",
            { className: "mt-1.5 flex items-center gap-3 text-sm font-bold" },
            h("span", null, `⚖️ ${fmtWeight(info.fish.w)}`),
            info.fish.dia || isFishLunar(def)
              ? h(DiamondPrice, { n: info.fish.p, className: "text-[#7dd3fc]" })
              : h(Price, { n: info.fish.p, className: "text-[#ffe066]" })
          )
        )
      ),
      info.perfect && h("div", { className: "relative mt-2 rounded-xl bg-[#ffe14d]/20 py-1 text-center text-xs font-extrabold text-[#ffe14d]" }, `⭐ ${t("perfectCatch")}`)
    )
  );
}

const close = () => openPanel(null);

function BagPanel() {
  const bag = useGame((s) => s.bag);
  const lvl = useGame((s) => s.bagLevel);
  const x2At = useGame((s) => s.x2At);
  const now = useGame((s) => s.now);
  const busy = useGame((s) => s.adBusy);
  const [sort, setSort] = useState("price");
  const priceLevel = useGame((s) => s.priceLevel);
  const luExtrLevel = useGame((s) => s.luExtrLevel);
  const cap = bagCapacity(lvl);
  const val = (p) => sellValue(p, useGame.getState());
  const sellable = bag.filter((f) => !f.fav);
  const totalCoins = sellable.reduce((a, f) => a + (f.dia || isFishLunar(f.id) ? 0 : val(f.p)), 0);
  const totalDias = sellable.reduce((a, f) => a + (f.dia || isFishLunar(f.id) ? val(f.p) : 0), 0);
  const hasAnySell = totalCoins > 0 || totalDias > 0;
  const sorted = useMemo(() => {
    const arr = [...bag];
    if (sort === "price") arr.sort((a, b) => b.p - a.p);
    else if (sort === "rarity") arr.sort((a, b) => RARITY[FISH_MAP[b.id].rarity].idx - RARITY[FISH_MAP[a.id].rarity].idx || b.p - a.p);
    return arr;
  }, [bag, sort]);
  const x2Cd = Math.max(0, x2At + 90000 - now);

  return h(
    PanelShell,
    {
      title: `${t("bagTitle")} ${bag.length}/${cap}`,
      icon: "🎒",
      onClose: close,
      footer: h(
        "div",
        { className: "flex flex-wrap items-center justify-between gap-2" },
        h(
          "div",
          { className: "flex flex-wrap items-center gap-3 text-sm font-bold text-white/80" },
          `${t("total")}:`,
          h(Price, { n: totalCoins, className: "text-lg text-[#ffe066]" }),
          totalDias > 0 && h(DiamondPrice, { n: totalDias, className: "text-lg text-[#7dd3fc]" })
        ),
        h(
          "div",
          { className: "flex gap-2" },
          h(
            "button",
            {
              className: "btn btn-purple px-3 py-2.5 text-sm",
              disabled: !hasAnySell || x2Cd > 0 || busy,
              onClick: () => void watchRewarded("x2"),
            },
            `📺 ${x2Cd > 0 ? fmtTime(x2Cd) : t("sellX2")}`
          ),
          h(
            "button",
            {
              className: "btn btn-green px-4 py-2.5 text-base",
              disabled: !hasAnySell || busy,
              onClick: async () => {
                if (!S().adBusy && sellAll(1) > 0) await showInterstitial();
              },
            },
            `💰 ${t("sellAll")}`
          )
        )
      ),
    },
    h(
      "div",
      { className: "mb-3 flex flex-wrap items-center justify-between gap-2" },
      h(
        "div",
        { className: "flex gap-1" },
        ["price", "rarity", "new"].map((k) =>
          h(
            "button",
            { key: k, className: cn("btn px-3 py-1 text-xs", sort === k ? "btn-yellow" : "btn-gray"), onClick: () => setSort(k) },
            k === "price" ? "💰" : k === "rarity" ? "💎" : "🕒"
          )
        )
      ),
      h(
        "span",
        { className: "text-xs font-bold text-white/70" },
        t("favHint"),
        (priceLevel > 0 || luExtrLevel > 0) && h("span", { className: "ml-2 text-[#7ef07e]" }, `📜 +${priceLevel * PRICE_PER_LVL + (luExtrLevel || 0) * LU_EXTR_PER}%`)
      )
    ),
    !bag.length
      ? h(
          "div",
          { className: "flex h-48 flex-col items-center justify-center gap-2 text-white/80" },
          h("span", { className: "anim-bob text-5xl" }, "🎣"),
          h("span", { className: "font-bold" }, t("bagEmpty"))
        )
      : h(
          "div",
          { className: "grid grid-cols-3 gap-2 sm:grid-cols-4 md:grid-cols-5" },
          sorted.map((f) => {
            const def = FISH_MAP[f.id];
            const isDia = !!(f.dia || isFishLunar(def));
            return h(
              "div",
              {
                key: f.uid,
                className: "card-bg relative flex flex-col items-center rounded-2xl p-1.5 text-center",
                style: { boxShadow: `inset 0 0 0 2px ${RARITY[def.rarity].color}66` },
              },
              h(
                "button",
                { className: cn("absolute right-1 top-0.5 text-lg leading-none", f.fav ? "text-[#ffe14d]" : "text-white/40"), onClick: () => toggleFav(f.uid) },
                f.fav ? "★" : "☆"
              ),
              h(FishIcon, { def, mut: f.m, className: "h-12 w-20" }),
              h("div", { className: "w-full truncate text-[11px] font-extrabold text-white" }, tr(def.name)),
              h("div", { className: "text-[10px] font-bold", style: { color: RARITY[def.rarity].color } }, fmtWeight(f.w)),
              f.m && h(MutPill, { id: f.m, className: "mt-0.5 scale-90 text-[9px]" }),
              h(
                "button",
                { className: cn("btn mt-1 w-full px-1 py-0.5 text-[11px]", isDia ? "btn-blue" : "btn-green"), disabled: f.fav, onClick: () => sellOne(f.uid) },
                isDia ? h(DiamondPrice, { n: val(f.p), size: 13 }) : h(Price, { n: val(f.p), size: 13 })
              )
            );
          })
        )
  );
}

function RodIcon({ rod }) {
  const id = `rod-${rod.id}`;
  return h(
    "svg",
    { viewBox: "0 0 64 64", className: "h-14 w-14 shrink-0", style: rod.glow ? { filter: `drop-shadow(0 0 5px ${rod.color})` } : undefined },
    h(
      "defs",
      null,
      h(
        "linearGradient",
        { id, x1: "0", y1: "1", x2: "1", y2: "0" },
        rod.rainbow
          ? ["#ff4d6d", "#ffe14d", "#5ddc5d", "#3dfcff", "#b46cff"].map((c, i) => h("stop", { key: c, offset: i / 4, stopColor: c }))
          : [h("stop", { key: "a", offset: "0", stopColor: rod.color }), h("stop", { key: "b", offset: "1", stopColor: rod.accent })]
      )
    ),
    h("path", { d: "M10 56 L56 8", stroke: `url(#${id})`, strokeWidth: "5", strokeLinecap: "round" }),
    h("path", { d: "M8 58 L18 48", stroke: rod.accent, strokeWidth: "8", strokeLinecap: "round" }),
    h("circle", { cx: "20", cy: "42", r: "6", fill: rod.accent, stroke: "#0b2546", strokeWidth: "2" }),
    h("path", { d: "M56 8 Q60 30 52 50", stroke: "#ffffff", strokeWidth: "1.2", fill: "none", opacity: "0.8" }),
    h("circle", { cx: "52", cy: "51", r: "3", fill: "#e8302a" })
  );
}

function BuyButton({ owned, equipped, price, diamond = false, onClick }) {
  const coins = useGame((s) => s.coins);
  const diamonds = useGame((s) => s.diamonds);
  if (equipped) return h("button", { className: "btn btn-gray min-w-[104px] px-3 py-2 text-sm", disabled: true }, `✔ ${t("inUse")}`);
  if (owned) return h("button", { className: "btn btn-blue min-w-[104px] px-3 py-2 text-sm", onClick }, t("equip"));
  const canAfford = diamond ? (diamonds || 0) >= price : coins >= price;
  return h(
    "button",
    { className: cn("btn min-w-[104px] px-3 py-2 text-sm", canAfford ? "btn-green" : "btn-gray"), onClick },
    diamond ? h(DiamondPrice, { n: price, size: 16 }) : h(Price, { n: price, size: 16 })
  );
}

function RodsTab({ lunar = false }) {
  const owned = useGame((s) => s.rodsOwned);
  const rod = useGame((s) => s.rod);
  const list = RODS.filter((r) => !!r.lunar === lunar);
  return h(
    "div",
    { className: "flex flex-col gap-2" },
    list.map((r) =>
      h(
        "div",
        { key: r.id, className: cn("card-bg flex items-center gap-3 rounded-2xl p-2.5", rod === r.id && "ring-2 ring-[#ffe066]") },
        h(RodIcon, { rod: r }),
        h(
          "div",
          { className: "min-w-0 flex-1" },
          h("div", { className: cn("truncate font-extrabold text-white", r.rainbow && "rainbow-text") }, tr(r.name)),
          h(
            "div",
            { className: "mt-1 flex flex-col gap-0.5" },
            h(StatBar, { label: t("luck"), value: r.luck, max: lunar ? 13500 : 1800, color: "#7ef07e" }),
            h(StatBar, { label: t("speed"), value: r.speed, max: lunar ? 320 : 145, color: "#6cc7ff" }),
            h(StatBar, { label: t("control"), value: r.control, max: lunar ? 155 : 85, color: "#ffb02e" })
          )
        ),
        h(BuyButton, { owned: owned.includes(r.id), equipped: rod === r.id, price: r.price, diamond: !!r.lunar, onClick: () => buyOrEquipRod(r.id) })
      )
    )
  );
}

function BaitsTab({ lunar = false }) {
  const owned = useGame((s) => s.baitsOwned);
  const bait = useGame((s) => s.bait);
  const list = BAITS.filter((b) => !!b.lunar === lunar);
  return h(
    "div",
    { className: "flex flex-col gap-2" },
    list.map((b) =>
      h(
        "div",
        { key: b.id, className: cn("card-bg flex items-center gap-3 rounded-2xl p-2.5", bait === b.id && "ring-2 ring-[#ffe066]") },
        h("div", { className: "flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-black/25 text-3xl" }, b.icon),
        h(
          "div",
          { className: "min-w-0 flex-1" },
          h("div", { className: "truncate font-extrabold text-white" }, tr(b.name)),
          h(
            "div",
            { className: "mt-0.5 flex flex-wrap gap-x-3 text-xs font-bold text-white/85" },
            h("span", { className: "text-[#7ef07e]" }, `🍀 +${b.luck}%`),
            h("span", { className: "text-[#6cc7ff]" }, `⚡ +${b.speed}%`),
            b.mut > 0 && h("span", { className: "text-[#d29bff]" }, `✦ +${b.mut}%`)
          )
        ),
        h(BuyButton, { owned: owned.includes(b.id), equipped: bait === b.id, price: b.price, diamond: !!b.lunar, onClick: () => buyOrEquipBait(b.id) })
      )
    )
  );
}

function UpgradeRow({ icon, title, desc, level, max, cost, onClick, done }) {
  const coins = useGame((s) => s.coins);
  return h(
    "div",
    { className: "card-bg flex items-center gap-3 rounded-2xl p-3" },
    h("div", { className: "flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-black/25 text-3xl" }, icon),
    h(
      "div",
      { className: "min-w-0 flex-1" },
      h(
        "div",
        { className: "font-extrabold text-white" },
        `${title} `,
        level !== undefined && h("span", { className: "text-xs text-white/60" }, `${t("level")} ${level}/${max}`)
      ),
      h("div", { className: "text-xs font-bold text-white/75" }, desc)
    ),
    done
      ? h("button", { className: "btn btn-gray min-w-[104px] px-3 py-2 text-sm", disabled: true }, t("maxed"))
      : h(
          "button",
          { className: cn("btn min-w-[104px] px-3 py-2 text-sm", coins >= cost ? "btn-green" : "btn-gray"), onClick },
          h(Price, { n: cost, size: 16 })
        )
  );
}

function UpgradesTab() {
  const bagLevel = useGame((s) => s.bagLevel);
  const luckLevel = useGame((s) => s.luckLevel);
  const mutLevel = useGame((s) => s.mutLevel);
  const priceLevel = useGame((s) => s.priceLevel);
  const ctrlLevel = useGame((s) => s.ctrlLevel);
  const spdLevel = useGame((s) => s.spdLevel);
  const autoOwned = useGame((s) => s.autoOwned);
  const nxt = (l, max) => Math.min(max, l + 1);
  const r1 = (v) => Math.round(v * 10) / 10;
  return h(
    "div",
    { className: "flex flex-col gap-2" },
    h(UpgradeRow, { icon: "🎒", title: t("bagUpgrade"), desc: t("bagUpgradeDesc", { a: bagCapacity(bagLevel), b: bagCapacity(nxt(bagLevel, BAG_MAX_LVL)) }), level: bagLevel, max: BAG_MAX_LVL, cost: bagUpgradeCost(bagLevel), onClick: upgradeBag, done: bagLevel >= BAG_MAX_LVL }),
    h(UpgradeRow, { icon: "🪝", title: t("luckUpgrade"), desc: t("luckUpgradeDesc", { a: luckLevel * LUCK_PER_LVL, b: nxt(luckLevel, LUCK_MAX_LVL) * LUCK_PER_LVL }), level: luckLevel, max: LUCK_MAX_LVL, cost: luckUpgradeCost(luckLevel), onClick: upgradeLuck, done: luckLevel >= LUCK_MAX_LVL }),
    h(UpgradeRow, { icon: "⚙️", title: t("ctrlUpgrade"), desc: t("ctrlUpgradeDesc", { a: ctrlLevel * CTRL_PER_LVL, b: nxt(ctrlLevel, CTRL_MAX_LVL) * CTRL_PER_LVL }), level: ctrlLevel, max: CTRL_MAX_LVL, cost: ctrlUpgradeCost(ctrlLevel), onClick: () => upgradeStat("ctrl"), done: ctrlLevel >= CTRL_MAX_LVL }),
    h(UpgradeRow, { icon: "📡", title: t("spdUpgrade"), desc: t("spdUpgradeDesc", { a: spdLevel * SPD_PER_LVL, b: nxt(spdLevel, SPD_MAX_LVL) * SPD_PER_LVL }), level: spdLevel, max: SPD_MAX_LVL, cost: spdUpgradeCost(spdLevel), onClick: () => upgradeStat("spd"), done: spdLevel >= SPD_MAX_LVL }),
    h(UpgradeRow, { icon: "🧪", title: t("mutUpgrade"), desc: t("mutUpgradeDesc", { a: r1(mutLevel * MUT_PER_LVL), b: r1(nxt(mutLevel, MUT_MAX_LVL) * MUT_PER_LVL) }), level: mutLevel, max: MUT_MAX_LVL, cost: mutUpgradeCost(mutLevel), onClick: () => upgradeStat("mut"), done: mutLevel >= MUT_MAX_LVL }),
    h(UpgradeRow, { icon: "📜", title: t("priceUpgrade"), desc: t("priceUpgradeDesc", { a: priceLevel * PRICE_PER_LVL, b: nxt(priceLevel, PRICE_MAX_LVL) * PRICE_PER_LVL }), level: priceLevel, max: PRICE_MAX_LVL, cost: priceUpgradeCost(priceLevel), onClick: () => upgradeStat("price"), done: priceLevel >= PRICE_MAX_LVL }),
    h(UpgradeRow, { icon: "🤖", title: t("autoUpgrade"), desc: t("autoUpgradeDesc"), cost: AUTO_PRICE, onClick: buyAuto, done: autoOwned })
  );
}

function BoostsTab() {
  const now = useGame((s) => s.now);
  const luckUntil = useGame((s) => s.luckUntil);
  const autoUntil = useGame((s) => s.autoUntil);
  const autoOwned = useGame((s) => s.autoOwned);
  const coinsAt = useGame((s) => s.coinsAt);
  const busy = useGame((s) => s.adBusy);
  useGame((s) => s.islands);
  const coinCd = Math.max(0, coinsAt + 120000 - now);
  const rows = [
    { icon: "🍀", title: t("boostLuckTitle"), desc: t("boostLuckDesc"), active: luckUntil > now ? fmtTime(luckUntil - now) : null, cd: 0, kind: "luck", color: "from-[#2fb84a] to-[#1b7a2e]" },
    { icon: "🤖", title: t("boostAutoTitle"), desc: autoOwned ? t("autoUpgradeDesc") : t("boostAutoDesc"), active: autoOwned ? "∞" : autoUntil > now ? fmtTime(autoUntil - now) : null, cd: 0, kind: "auto", color: "from-[#2a7de1] to-[#1a4f9a]", disabled: autoOwned },
    { icon: "💰", title: t("boostCoinsTitle"), desc: t("boostCoinsDesc", { n: fmtNum(coinReward()) }), active: null, cd: coinCd, kind: "coins", color: "from-[#f5a623] to-[#b9700c]" },
  ];
  return h(
    "div",
    { className: "flex flex-col gap-2" },
    rows.map((r) =>
      h(
        "div",
        { key: r.kind, className: cn("flex items-center gap-3 rounded-2xl border-2 border-white/20 bg-gradient-to-r p-3", r.color) },
        h("div", { className: "flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-black/20 text-3xl" }, r.icon),
        h(
          "div",
          { className: "min-w-0 flex-1" },
          h("div", { className: "txt-o font-extrabold text-white" }, r.title),
          h("div", { className: "text-xs font-bold text-white/90" }, r.desc),
          r.active && h("div", { className: "mt-0.5 text-xs font-extrabold text-[#ffe066]" }, `✔ ${t("active")} ${r.active}`)
        ),
        h(
          "button",
          {
            className: "btn btn-yellow min-w-[118px] px-3 py-2 text-sm",
            disabled: busy || r.cd > 0 || !!r.disabled,
            onClick: () => void watchRewarded(r.kind),
          },
          r.cd > 0 ? `⏳ ${fmtTime(r.cd)}` : `📺 ${t("watchAd")}`
        )
      )
    )
  );
}

function PremiumTab() {
  const products = useGame((s) => s.products);
  const busy = useGame((s) => s.paymentBusy || s.adBusy);
  const sync = useGame((s) => s.cloudReady);
  const conflict = useGame((s) => !!s.cloudConflict);
  const failed = useGame((s) => s.restoreFailed);
  const vipLuck = useGame((s) => s.vipLuck);
  const autoOwned = useGame((s) => s.autoOwned);
  const islands = useGame((s) => s.islands);
  const mult = highestMult({ islands });
  return h("div", { className: "space-y-2 text-sm text-white", "aria-busy": busy },
    !sync && h("p", { className: "card-bg rounded-xl p-3", role: "status" }, t(conflict ? "cloudResolveBeforePurchase" : "cloudWaiting")),
    failed && h("div", { className: "card-bg flex flex-wrap items-center justify-between gap-2 rounded-xl p-3", role: "status" },
      t("restoreNeeded"), h("button", { className: "btn btn-blue px-3 py-2", disabled: busy || !sync, onClick: () => void refreshPayments(true) }, t("retryRestore"))),
    busy && h("p", { role: "status", className: "px-1 text-white/80" }, t("paymentWait")),
    !products?.length && h("p", { className: "card-bg rounded-xl p-3" }, t("premiumEmpty")),
    products?.map((product) => {
      const spec = PREMIUM_ITEMS[product.id];
      const owned = ownsPremium(product.id, { vipLuck, autoOwned });
      let icon;
      try { icon = product.getPriceCurrencyImage?.("small"); } catch { /* The catalog price stays visible. */ }
      return h("div", { key: product.id, className: "card-bg flex flex-wrap items-center justify-between gap-2 rounded-2xl p-3" },
        h("div", { className: "min-w-0 flex-1" },
          h("div", { className: "font-extrabold" }, `${spec.icon} ${t(spec.title)}`),
          h("div", { className: "text-xs text-white/80" }, t(spec.desc, { n: fmtNum(5000 * mult) }))),
        h("button", { className: "btn btn-yellow max-w-full flex-wrap gap-1 px-3 py-2", disabled: busy || owned || !sync || failed || !restoredPurchases,
          onClick: () => void buyPremium(product.id),
          "aria-label": owned ? t("owned") : `${t("buy")} · ${t(spec.title)} · ${product.price}` },
          owned ? `✔ ${t("owned")}` : product.price,
          !owned && icon && h("img", { src: icon, alt: "", width: 18, height: 18, onError: (e) => { e.currentTarget.hidden = true; } }),
          !owned && product.priceCurrencyCode && !String(product.price).includes(product.priceCurrencyCode)
            && h("span", { className: "text-xs opacity-80" }, product.priceCurrencyCode)));
    }));
}

function DailyPanel() {
  const state = useGame();
  const { available, day } = dailyStatus(state);
  return h(PanelShell, { title: t("dailyTitle"), icon: "📅", onClose: close,
    footer: h("button", { className: "btn btn-green w-full px-3 py-2 text-sm", disabled: !available || state.adBusy || state.paymentBusy,
      onClick: claimDaily }, t(available ? "claim" : "dailyTomorrow")) },
    h("p", { className: "mb-3 text-sm font-bold text-white" }, t("dailyRules")),
    h("ol", { className: "flex flex-col gap-1.5" }, DAILY_REWARDS.map((reward, i) => {
      const claimed = available ? i < day - 1 : i < day;
      const current = i === day - 1;
      const label = reward.coins ? `${fmtNum(reward.coins * highestMult(state))} 🪙`
        : reward.diamonds ? `${fmtNum(reward.diamonds)} 💎` : t("dailyLuck", { n: reward.minutes });
      return h("li", { key: i, className: cn("card-bg flex flex-wrap items-center justify-between gap-1 rounded-xl px-3 py-2 text-sm text-white", current && "ring-2 ring-[#ffe066]"),
        "aria-current": current ? "step" : undefined },
        h("span", { className: "font-bold" }, t("dailyDay", { n: i + 1 })),
        h("span", null, `${claimed ? "✔ " : ""}${label}`));
    })));
}

function FishRescue() {
  const offer = useGame((s) => s.rescue);
  const [seconds, setSeconds] = useState(5);
  const watch = useRef(null);
  const deadline = offer?.deadline;
  useEffect(() => {
    if (!deadline) return;
    const update = () => setSeconds(Math.max(0, Math.ceil((deadline - Date.now()) / 1000)));
    update();
    watch.current?.focus();
    const timer = setInterval(update, 125);
    return () => clearInterval(timer);
  }, [deadline]);
  if (!offer) return null;
  const resolve = (take) => void runtime.engine?.fishing.resolveRescue(take);
  return h("div", { className: "absolute inset-0 z-[60] grid place-items-center bg-[#04142a]/80 p-3" },
    h("section", { role: "dialog", "aria-modal": true, "aria-labelledby": "fish-rescue-heading",
      className: "panel-bg max-h-full w-full max-w-[410px] overflow-y-auto rounded-3xl p-4 text-center text-white",
      onKeyDown: (e) => {
        if (e.key !== "Tab" || offer.pending) return;
        const buttons = e.currentTarget.querySelectorAll("button:not(:disabled)");
        if (e.shiftKey && document.activeElement === buttons[0]) { e.preventDefault(); buttons[buttons.length - 1]?.focus(); }
        else if (!e.shiftKey && document.activeElement === buttons[buttons.length - 1]) { e.preventDefault(); buttons[0]?.focus(); }
      } },
      h("h2", { id: "fish-rescue-heading", className: "txt-o text-lg font-extrabold" }, t("rescueTitle")),
      h("div", { className: "my-1 flex flex-wrap items-center justify-center gap-2 text-sm font-bold" }, tr(offer.fish.name), h(RarityPill, { id: offer.fish.rarity })),
      h("p", { className: "my-2 text-sm", role: "status" }, offer.pending ? t("paymentWait") : t("rescueTimer", { n: seconds })),
      h("div", { className: "flex flex-wrap justify-center gap-2" },
        h("button", { ref: watch, className: "btn btn-purple px-3 py-2 text-sm", disabled: offer.pending || seconds === 0, onClick: () => resolve(true) }, `📺 ${t("rescueWatch")}`),
        h("button", { className: "btn btn-gray px-3 py-2 text-sm", disabled: offer.pending, onClick: () => resolve(false) }, t("rescueSkip")))));
}

function ShopPanel() {
  const products = useGame((s) => s.products);
  const selectedTab = useGame((s) => s.shopTab);
  const tab = selectedTab === "premium" && products === null ? "rods" : selectedTab;
  const tabs = [
    { id: "rods", icon: "🎣", label: t("rods") },
    { id: "baits", icon: "🪝", label: t("baits") },
    { id: "upgrades", icon: "⬆️", label: t("upgrades") },
    { id: "boosts", icon: "🎁", label: t("boosts") },
    ...(products !== null ? [{ id: "premium", icon: "💎", label: t("premium") }] : []),
  ];
  return h(
    PanelShell,
    { title: t("shop"), icon: "🛒", onClose: close },
    h(
      "div",
      { className: "mb-3 flex flex-wrap gap-1.5" },
      tabs.map((x) =>
        h(
          "button",
          {
            key: x.id,
            className: cn("btn min-w-[68px] flex-1 flex-col gap-0 px-1 py-1.5 text-[11px] sm:text-sm", tab === x.id ? "btn-yellow" : "btn-blue"),
            onClick: () => {
              audio.play("click");
              useGame.setState({ shopTab: x.id });
            },
          },
          h("span", { className: "text-xl" }, x.icon),
          x.label
        )
      )
    ),
    tab === "rods" && h(RodsTab),
    tab === "baits" && h(BaitsTab),
    tab === "upgrades" && h(UpgradesTab),
    tab === "boosts" && h(BoostsTab),
    tab === "premium" && h(PremiumTab)
  );
}

function MapPanel() {
  const islands = useGame((s) => s.islands);
  const current = useGame((s) => s.island);
  const coins = useGame((s) => s.coins);
  const collection = useGame((s) => s.collection);
  const curPlanet = ISLAND_MAP[current]?.planet ?? 1;
  const [planetTab, setPlanetTab] = useState(curPlanet);
  const planetIslands = ISLANDS.filter((isl) => (isl.planet ?? 1) === planetTab);

  return h(
    PanelShell,
    { title: t("mapTitle"), icon: "🗺️", onClose: close },
    h(
      "div",
      { className: "mb-3 grid grid-cols-2 gap-2" },
      [
        { p: 1, icon: "🌍", label: t("planet1") },
        { p: 2, icon: "🌕", label: t("planet2") },
      ].map((pl) =>
        h(
          "button",
          {
            key: pl.p,
            className: cn("btn py-2 text-xs sm:text-sm", planetTab === pl.p ? "btn-yellow" : "btn-blue"),
            onClick: () => {
              audio.play("click");
              setPlanetTab(pl.p);
            },
          },
          `${pl.icon} ${pl.label}`
        )
      )
    ),
    h(
      "div",
      { className: "grid grid-cols-1 gap-3 sm:grid-cols-2" },
      planetIslands.map((isl) => {
        const idx = ISLANDS.findIndex((x) => x.id === isl.id);
        const unlocked = islands.includes(isl.id);
        const here = current === isl.id;
        const fish = FISH.filter((f) => f.island === isl.id);
        const got = fish.filter((f) => collection[f.id]).length;
        const prevUnlocked = idx === 0 || islands.includes(ISLANDS[idx - 1].id);
        const isMoonLocked = isl.id === "lunar_crater" && !unlocked;
        return h(
          "div",
          { key: isl.id, className: cn("overflow-hidden rounded-3xl border-4 border-[#0b2546] bg-[#0f3360]", here && "ring-4 ring-[#ffe066]") },
          h(
            "div",
            { className: "relative flex h-24 items-center justify-center", style: { background: isl.gradient } },
            h("span", { className: cn("text-6xl drop-shadow-lg", !unlocked && "opacity-60 grayscale") }, isl.icon),
            !isl.noFishing && h("span", { className: "txt-o absolute right-2 top-2 rounded-full bg-black/35 px-2 py-0.5 text-xs font-extrabold text-[#ffe066]" }, `💰 ×${isl.mult}`),
            !unlocked && h("span", { className: "absolute left-2 top-2 text-2xl" }, "🔒")
          ),
          h(
            "div",
            { className: "p-3" },
            h("div", { className: "txt-o text-lg font-extrabold text-white" }, tr(isl.name)),
            h("div", { className: "min-h-[32px] text-xs font-bold text-white/75" }, tr(isl.desc)),
            isl.noFishing
              ? h("div", { className: "mt-1 text-xs font-extrabold text-[#ffe066]" }, `🚀 ${t("spaceportNote")}`)
              : h("div", { className: "mt-1 text-xs font-bold text-white/80" }, `🐟 ${t("fishCaught")}: ${got}/${fish.length}`),
            h(
              "div",
              { className: "mt-2" },
              here
                ? h("button", { className: "btn btn-gray w-full py-2 text-sm", disabled: true }, `📍 ${t("youAreHere")}`)
                : unlocked
                  ? h("button", { className: "btn btn-blue w-full py-2 text-sm", onClick: () => void travelTo(isl.id) }, `${(isl.planet ?? 1) === 2 ? "🚀" : "⛵"} ${t("sail")}`)
                  : isMoonLocked
                    ? h(
                        "button",
                        {
                          className: cn("btn w-full py-2 text-xs", islands.includes("spaceport") && coins >= ROCKET_LAUNCH_COST ? "btn-green" : "btn-gray"),
                          disabled: !islands.includes("spaceport"),
                          onClick: () => void launchRocketToMoon(),
                        },
                        islands.includes("spaceport")
                          ? h(React.Fragment, null, `🚀 ${t("talkRocket")} `, h(Price, { n: ROCKET_LAUNCH_COST, size: 15 }))
                          : `🔒 ${t("needSpaceportRocket")}`
                      )
                    : h(
                        "button",
                        {
                          className: cn("btn w-full py-2 text-sm", coins >= isl.price && prevUnlocked ? "btn-green" : "btn-gray"),
                          disabled: !prevUnlocked,
                          onClick: () => void travelTo(isl.id),
                        },
                        prevUnlocked ? h(React.Fragment, null, `🔓 ${t("unlock")} `, h(Price, { n: isl.price, size: 16 })) : "🔒"
                      )
            )
          )
        );
      })
    )
  );
}

function CollectionPanel() {
  const rawTab = useGame((s) => s.colTab);
  const collection = useGame((s) => s.collection);
  const fishableIslands = ISLANDS.filter((isl) => !isl.noFishing);
  const tab = ISLAND_MAP[rawTab] && !ISLAND_MAP[rawTab].noFishing ? rawTab : "sunny";
  const done = completedIslands(useGame.getState());
  const fish = FISH.filter((f) => f.island === tab);
  const got = fish.filter((f) => collection[f.id]).length;
  const total = FISH.filter((f) => collection[f.id]).length;
  return h(
    PanelShell,
    { title: `${t("collectionTitle")} ${total}/${FISH.length}`, icon: "📖", onClose: close },
    h(
      "div",
      { className: "mb-3 grid grid-cols-3 gap-1.5 sm:grid-cols-9" },
      fishableIslands.map((isl) => {
        const all = FISH.filter((f) => f.island === isl.id);
        return h(
          "button",
          {
            key: isl.id,
            className: cn("btn flex-col gap-0 py-1.5 text-2xl", tab === isl.id ? "btn-yellow" : "btn-blue"),
            onClick: () => {
              audio.play("click");
              useGame.setState({ colTab: isl.id });
            },
          },
          isl.icon,
          h("span", { className: "text-[10px] font-extrabold" }, `${all.filter((f) => collection[f.id]).length}/${all.length}`)
        );
      })
    ),
    h(
      "div",
      { className: "mb-3 rounded-2xl bg-black/20 p-2.5" },
      h(
        "div",
        { className: "mb-1 flex items-center justify-between text-sm font-extrabold text-white" },
        h("span", null, tr(ISLAND_MAP[tab].name)),
        h("span", null, `${got}/${fish.length}`)
      ),
      h(
        "div",
        { className: "h-3 overflow-hidden rounded-full bg-black/30" },
        h("div", { className: "h-full rounded-full bg-gradient-to-r from-[#7ef07e] to-[#2fb84a]", style: { width: `${(got / fish.length) * 100}%` } })
      ),
      h("div", { className: cn("mt-1 text-xs font-bold", done.includes(tab) ? "text-[#7ef07e]" : "text-white/75") }, done.includes(tab) ? "✔ " + t("collectDone") : "🎁 " + t("collectReward"))
    ),
    h(
      "div",
      { className: "grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4" },
      fish.map((f) => {
        const e = collection[f.id];
        return h(
          "div",
          {
            key: f.id,
            className: "card-bg flex flex-col items-center rounded-2xl p-2 text-center",
            style: e ? { boxShadow: rarityGlow(f.rarity) } : undefined,
          },
          h(FishIcon, { def: f, silhouette: !e, className: "h-14 w-24" }),
          h("div", { className: cn("w-full truncate text-xs font-extrabold text-white", e && f.rarity === "secret" && "rainbow-text") }, e ? tr(f.name) : t("unknown")),
          h(RarityPill, { id: f.rarity, className: "mt-0.5 scale-90" }),
          e
            ? h(
                "div",
                { className: "mt-1 text-[10px] font-bold text-white/80" },
                `×${e.n} · ${t("best")}: ${fmtWeight(e.best)}`,
                e.muts.length > 0 &&
                  h(
                    "div",
                    { className: "mt-0.5 flex justify-center gap-0.5" },
                    e.muts.map((m) =>
                      h("span", {
                        key: m,
                        title: tr(MUTATION[m].name),
                        className: cn("inline-block h-2.5 w-2.5 rounded-full", MUTATION[m].color === "rainbow" && "rainbow-bg"),
                        style: MUTATION[m].color === "rainbow" ? undefined : { background: MUTATION[m].color },
                      })
                    )
                  )
              )
            : h(
                "div",
                { className: "mt-1 text-[10px] font-bold text-white/50" },
                isFishLunar(f) ? `💎 ${fmtNum(f.price)}+` : `💰 ${fmtNum(f.price)}+`
              )
        );
      })
    )
  );
}

function questText(q) {
  switch (q.type) {
    case "catch": return t("qCatch", { n: q.target });
    case "rarity": return t("qRarity", { n: q.target, r: tr(RARITY[q.param ?? "rare"].name) });
    case "sell": return t("qSell", { n: fmtNum(q.target) });
    case "perfect": return t("qPerfect", { n: q.target });
    case "mutation": return t("qMutation", { n: q.target });
    case "island": return t("qIsland", { n: q.target, i: tr(ISLAND_MAP[q.param ?? "sunny"]?.name ?? ISLAND_MAP.sunny.name) });
  }
}

function QuestsPanel() {
  const busy = useGame((s) => s.adBusy || s.paymentBusy);
  const rewarded = useGame((s) => s.rewardAvailable);
  const quests = useGame((s) => s.quests);
  const icons = { catch: "🎣", rarity: "💎", sell: "💰", perfect: "🎯", mutation: "✦", island: "🏝️" };
  return h(
    PanelShell,
    { title: t("questsTitle"), icon: "📜", onClose: close },
    h(
      "div",
      { className: "flex flex-col gap-2.5" },
      quests.map((q, i) =>
        h(
          "div",
          { key: i, className: cn("card-bg flex flex-wrap items-center gap-3 rounded-2xl p-3", q.done && "ring-2 ring-[#7ef07e]") },
          h("div", { className: "flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-black/25 text-3xl" }, icons[q.type]),
          h(
            "div",
            { className: "min-w-0 flex-1" },
            h("div", { className: "font-extrabold text-white" }, questText(q)),
            h(
              "div",
              { className: "mt-1 h-3 overflow-hidden rounded-full bg-black/30" },
              h("div", { className: "h-full rounded-full bg-gradient-to-r from-[#6cc7ff] to-[#2a7de1]", style: { width: `${(q.progress / q.target) * 100}%` } })
            ),
            h(
              "div",
              { className: "mt-0.5 flex justify-between text-xs font-bold text-white/75" },
              h("span", null, `${fmtNum(q.progress)}/${fmtNum(q.target)}`),
              h("span", { className: "inline-flex items-center gap-1" }, `${t("reward")}: `, h(Price, { n: q.reward, size: 14, className: "text-[#ffe066]" }))
            )
          ),
          h("div", { className: "flex w-full shrink-0 justify-end gap-2 sm:w-auto" },
          h("button", { className: cn("btn px-3 py-2 text-sm", q.done ? "btn-green" : "btn-gray"),
            disabled: !q.done || busy, onClick: () => claimQuest(i) }, t("claim")),
          q.done && rewarded && h("button", { className: "btn btn-purple px-3 py-2 text-sm", disabled: busy,
            onClick: () => void claimQuestDouble(i, q), title: t("claimDouble"), "aria-label": t("claimDouble") }, "📺 ×2"))
        )
      )
    )
  );
}

function SettingsPanel() {
  const conflict = useGame((s) => !!s.cloudConflict);
  const cloudReady = useGame((s) => s.cloudReady);
  const busy = useGame((s) => s.paymentBusy || s.adBusy);
  const sound = useGame((s) => s.sound);
  const music = useGame((s) => s.music);
  const lang = useGame((s) => s.curLang);
  const lowGfx = useGame((s) => s.lowGfx);
  const stats = useGame((s) => s.stats);
  const authorized = useGame((s) => s.authorized);
  useGame((s) => s.now);
  const mods = getMods();
  const Toggle = ({ on, onClick }) =>
    h("button", { className: cn("btn min-w-[90px] px-4 py-2 text-sm", on ? "btn-green" : "btn-gray"), onClick }, on ? t("on") : t("off"));
  return h(
    PanelShell,
    { title: t("settings"), icon: "⚙️", onClose: close },
    h(
      "div",
      { className: "flex flex-col gap-2" },
      h(
        "div",
        { className: "card-bg flex items-center justify-between rounded-2xl p-3 font-extrabold text-white" },
        h("span", null, `🔊 ${t("sound")}`),
        h(Toggle, { on: sound, onClick: toggleSound })
      ),
      h(
        "div",
        { className: "card-bg flex items-center justify-between rounded-2xl p-3 font-extrabold text-white" },
        h("span", null, `🎵 ${t("music")}`),
        h(Toggle, { on: music, onClick: toggleMusic })
      ),
      h(
        "div",
        { className: "card-bg flex items-center justify-between rounded-2xl p-3 font-extrabold text-white" },
        h("span", null, `🖥️ ${t("graphics")}`),
        h("button", { className: cn("btn min-w-[90px] px-4 py-2 text-sm", lowGfx ? "btn-gray" : "btn-blue"), onClick: toggleGfx }, lowGfx ? t("gfxLow") : t("gfxHigh"))
      ),
      h(
        "div",
        { className: "card-bg flex items-center justify-between rounded-2xl p-3 font-extrabold text-white" },
        h("span", null, `🌐 ${t("language")}`),
        h(
          "div",
          { className: "flex gap-1.5" },
          ["ru", "en"].map((l) =>
            h(
              "button",
              {
                key: l,
                className: cn("btn px-4 py-2 text-sm uppercase", lang === l ? "btn-yellow" : "btn-gray"),
                onClick: () => {
                  audio.play("click");
                  setLanguage(l);
                },
              },
              l
            )
          )
        )
      ),
      conflict && h("div", { className: "card-bg flex flex-wrap items-center justify-between gap-2 rounded-2xl p-3 text-sm font-bold text-white" },
        t("cloudConflict"), h("button", { className: "btn btn-blue px-3 py-2", disabled: busy,
          onClick: useCloudProgress }, t("useCloud"))),
      YA.available &&
        h(
          "div",
          { className: "card-bg flex items-center justify-between gap-3 rounded-2xl p-3 text-white" },
          h(
            "div",
            { className: "min-w-0 flex-1" },
            h("div", { className: "font-extrabold" }, `☁️ ${t("authTitle")}`),
            h("div", { className: "text-xs font-bold text-white/75" }, t("authDesc"))
          ),
          authorized
            ? h("button", { className: "btn btn-gray min-w-[110px] px-3 py-2 text-xs", disabled: true }, cloudReady ? `✔ ${t("authDone")}` : t("cloudWaiting"))
            : h("button", { className: "btn btn-yellow min-w-[110px] px-3 py-2 text-sm", disabled: busy, onClick: () => void requestAuth() }, t("authBtn"))
        ),
      h(
        "div",
        { className: "card-bg rounded-2xl p-3 text-white" },
        h("div", { className: "mb-2 font-extrabold" }, `📊 ${t("stats")}`),
        h(
          "div",
          { className: "grid grid-cols-2 gap-2 text-sm font-bold" },
          h("div", { className: "rounded-xl bg-black/20 p-2" }, `🐟 ${t("statCaught")}`, h("div", { className: "text-lg text-[#ffe066]" }, fmtNum(stats.caught))),
          h("div", { className: "rounded-xl bg-black/20 p-2" }, h(Coin, { size: 14 }), ` ${t("statEarned")}`, h("div", { className: "text-lg text-[#ffe066]" }, fmtNum(stats.earned))),
          h("div", { className: "rounded-xl bg-black/20 p-2" }, `🎯 ${t("statPerfect")}`, h("div", { className: "text-lg text-[#ffe066]" }, fmtNum(stats.perfect))),
          h("div", { className: "rounded-xl bg-black/20 p-2" }, `🍀 ${t("statLuck")}`, h("div", { className: "text-lg text-[#7ef07e]" }, `×${mods.luckMult.toFixed(2)}`))
        )
      )
    )
  );
}

function LunarUpgradesTab() {
  const diamonds = useGame((s) => s.diamonds) || 0;
  const suit = useGame((s) => s.luSuitLevel) || 0;
  const scan = useGame((s) => s.luScanLevel) || 0;
  const extr = useGame((s) => s.luExtrLevel) || 0;
  const mut = useGame((s) => s.luMutLevel) || 0;
  const inc = useGame((s) => s.luIncLevel) || 0;
  const nxt = (l, max) => Math.min(max, l + 1);
  const r1 = (v) => Math.round(v * 10) / 10;

  const rows = [
    { id: "scan", icon: "🔭", title: t("luScanner"), desc: t("luScannerDesc", { a: scan * LU_SCAN_PER, b: nxt(scan, LU_SCAN_MAX) * LU_SCAN_PER }), lvl: scan, max: LU_SCAN_MAX, cost: luScanCost(scan) },
    { id: "extr", icon: "🛰️", title: t("luExtractor"), desc: t("luExtractorDesc", { a: extr * LU_EXTR_PER, b: nxt(extr, LU_EXTR_MAX) * LU_EXTR_PER }), lvl: extr, max: LU_EXTR_MAX, cost: luExtrCost(extr) },
    { id: "mut", icon: "☄️", title: t("luMutagen"), desc: t("luMutagenDesc", { a: r1(mut * LU_MUT_PER), b: r1(nxt(mut, LU_MUT_MAX) * LU_MUT_PER) }), lvl: mut, max: LU_MUT_MAX, cost: luMutCost(mut) },
    { id: "suit", icon: "⚙️", title: t("luSuit"), desc: t("luSuitDesc", { a: suit * LU_SUIT_PER, b: nxt(suit, LU_SUIT_MAX) * LU_SUIT_PER }), lvl: suit, max: LU_SUIT_MAX, cost: luSuitCost(suit) },
    { id: "inc", icon: "🥚", title: t("luIncubator"), desc: t("luIncubatorDesc", { a: inc * LU_INC_PER, b: nxt(inc, LU_INC_MAX) * LU_INC_PER }), lvl: inc, max: LU_INC_MAX, cost: luIncCost(inc) },
  ];

  return h(
    "div",
    { className: "flex flex-col gap-2" },
    rows.map((r) => {
      const done = r.lvl >= r.max;
      return h(
        "div",
        { key: r.id, className: "card-bg flex items-center gap-3 rounded-2xl p-3" },
        h("div", { className: "flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-black/25 text-3xl" }, r.icon),
        h(
          "div",
          { className: "min-w-0 flex-1" },
          h(
            "div",
            { className: "font-extrabold text-white" },
            `${r.title} `,
            h("span", { className: "text-xs text-white/60" }, `${t("level")} ${r.lvl}/${r.max}`)
          ),
          h("div", { className: "text-xs font-bold text-white/75" }, r.desc)
        ),
        done
          ? h("button", { className: "btn btn-gray min-w-[104px] px-3 py-2 text-sm", disabled: true }, t("maxed"))
          : h(
              "button",
              { className: cn("btn min-w-[104px] px-3 py-2 text-sm", diamonds >= r.cost ? "btn-blue" : "btn-gray"), onClick: () => upgradeLunarStat(r.id) },
              h(DiamondPrice, { n: r.cost, size: 16 })
            )
      );
    })
  );
}

function LunarPetsTab() {
  const rewarded = useGame((s) => s.rewardAvailable);
  const busy = useGame((s) => s.adBusy || s.paymentBusy);
  const freeEggAt = useGame((s) => s.freeEggAt);
  useGame((s) => s.now);
  const freeWait = eggWait(freeEggAt);
  const diamonds = useGame((s) => s.diamonds) || 0;
  const petsOwned = useGame((s) => s.petsOwned) || [];
  const petsEquipped = useGame((s) => s.petsEquipped) || [];
  const hatched = useGame((s) => s.hatchedPet);
  useGame((s) => s.rod);
  useGame((s) => s.bait);
  useGame((s) => s.luckLevel);
  useGame((s) => s.luScanLevel);
  useGame((s) => s.luIncLevel);
  useGame((s) => s.vipLuck);

  const full = petsOwned.length >= PET_LIMIT;
  const weights = getPetRarityWeights();
  const totalW = weights.reduce((a, b) => a + b, 0);
  const hatchedDef = hatched ? PET_MAP[hatched.pet.id] : null;

  return h(
    "div",
    { className: "flex flex-col gap-3 text-white" },
    // Карточка покупки и вылупления яйца
    h(
      "div",
      { className: "card-bg flex flex-col items-center gap-2 rounded-3xl border-2 border-[#38bdf8]/40 bg-gradient-to-b from-[#0f294a] to-[#091526] p-4 text-center" },
      h("div", { className: "anim-bob text-6xl drop-shadow-[0_0_16px_#38bdf8]" }, "🥚"),
      h("div", { className: "txt-o text-xl font-extrabold text-[#7dd3fc]" }, t("eggTitle")),
      h("div", { className: "max-w-md text-xs font-bold text-white/80" }, t("eggDesc")),
      // Таблица текущих шансов по редкостям с учётом удачи игрока
      h(
        "div",
        { className: "mt-1 flex flex-wrap justify-center gap-1.5" },
        RARITIES.map((r, i) => {
          const pct = (weights[i] / totalW) * 100;
          const txt = pct >= 10 ? pct.toFixed(1) : pct >= 0.1 ? pct.toFixed(2) : pct.toFixed(3);
          return h(
            "span",
            {
              key: r.id,
              className: cn("rounded-full px-2 py-0.5 text-[10px] font-extrabold text-[#0b2546]", r.id === "secret" && "rainbow-bg"),
              style: r.id === "secret" ? undefined : { background: r.color },
            },
            `${tr(r.name)}: ${txt}%`
          );
        })
      ),
      h(
        "button",
        {
          className: cn("btn mt-2 px-6 py-3 text-base", diamonds >= EGG_PRICE ? "btn-blue anim-pulse" : "btn-gray"),
          disabled: full || busy,
          onClick: () => hatchLunarEgg(),
        },
        `🥚 ${t("hatchBtn")} · `,
        h(DiamondPrice, { n: EGG_PRICE, size: 18 })
      ),
      rewarded && h("button", { className: "btn btn-purple px-3 py-2 text-sm", disabled: full || busy || freeWait > 0,
        onClick: () => void watchFreeEgg() }, `📺 ${freeWait > 0 ? t("freeEggWait", { time: fmtTime(freeWait) }) : t("freeEgg")}`),
      full && h("p", { className: "text-xs font-bold text-white/85" }, t("petLimit", { n: PET_LIMIT })),
      hatchedDef &&
        h(
          "div",
          {
            key: hatched.key,
            className: "anim-pop mt-2 flex items-center gap-3 rounded-2xl border-2 px-4 py-2",
            style: { borderColor: RARITY[hatchedDef.rarity].color, background: "rgba(0,0,0,0.35)" },
          },
          h("span", { className: "text-4xl" }, hatchedDef.icon),
          h(
            "div",
            { className: "text-left" },
            h("div", { className: "text-xs font-bold text-white/70" }, t("hatched")),
            h("div", { className: "font-extrabold" }, tr(hatchedDef.name)),
            h(RarityPill, { id: hatchedDef.rarity, className: "mt-0.5 scale-90" })
          )
        )
    ),

    // Инвентарь питомцев
    h(
      "div",
      { className: "flex items-center justify-between px-1" },
      h("span", { className: "font-extrabold" }, `🐾 ${t("myPets")} (${petsOwned.length})`),
      h("span", { className: "text-xs font-bold text-[#7dd3fc]" }, `${t("equipped")}: ${petsEquipped.length}/${PET_MAX_EQUIP}`)
    ),
    !petsOwned.length
      ? h("div", { className: "card-bg rounded-2xl p-6 text-center text-sm font-bold text-white/70" }, t("noPets"))
      : h(
          "div",
          { className: "grid grid-cols-2 gap-2 sm:grid-cols-3" },
          petsOwned.map((p) => {
            const def = PET_MAP[p.id];
            if (!def) return null;
            const isEq = petsEquipped.includes(p.uid);
            return h(
              "div",
              {
                key: p.uid,
                className: cn("card-bg relative flex flex-col items-center rounded-2xl p-2.5 text-center", isEq && "ring-2 ring-[#38bdf8]"),
                style: { boxShadow: `inset 0 0 0 2px ${RARITY[def.rarity].color}66` },
              },
              h(
                "button",
                {
                  className: "absolute right-1.5 top-1 text-xs font-bold text-white/40 hover:text-red-400",
                  onClick: () => deletePet(p.uid),
                  title: t("releasePet"),
                  "aria-label": t("releasePet"),
                },
                "✕"
              ),
              h("div", { className: "text-4xl drop-shadow" }, def.icon),
              h("div", { className: cn("mt-1 w-full truncate text-xs font-extrabold", def.rarity === "secret" && "rainbow-text") }, tr(def.name)),
              h(RarityPill, { id: def.rarity, className: "mt-0.5 scale-90" }),
              h(
                "div",
                { className: "mt-1.5 flex flex-wrap justify-center gap-x-2 text-[10px] font-bold text-white/85" },
                h("span", { className: "text-[#7ef07e]" }, `🍀+${def.luck}%`),
                h("span", { className: "text-[#6cc7ff]" }, `⚡+${def.speed}%`),
                def.mut > 0 && h("span", { className: "text-[#d29bff]" }, `✦+${def.mut}%`),
                h("span", { className: "text-[#ffe066]" }, `💎+${def.val}%`)
              ),
              h(
                "button",
                {
                  className: cn("btn mt-2 w-full py-1 text-xs", isEq ? "btn-yellow" : "btn-blue"),
                  onClick: () => toggleEquipPet(p.uid),
                },
                isEq ? `✔ ${t("unequipPet")}` : t("equipPet")
              )
            );
          })
        )
  );
}

function LunarExchangeTab() {
  const coins = useGame((s) => s.coins);
  const diamonds = useGame((s) => s.diamonds) || 0;
  const [amount, setAmount] = useState("1");
  const maxBuyDia = Math.floor(coins / EXCHANGE_RATE);

  return h(
    "div",
    { className: "flex flex-col gap-3 text-white" },
    h(
      "div",
      { className: "card-bg rounded-2xl p-4 text-center" },
      h("div", { className: "text-4xl" }, "🏦"),
      h("div", { className: "txt-o mt-1 text-xl font-extrabold text-[#7dd3fc]" }, t("exchTitle")),
      h("div", { className: "mt-1 text-sm font-extrabold text-[#ffe066]" }, t("exchRate")),
      h(
        "div",
        { className: "mt-3 flex flex-wrap items-center justify-center gap-4 rounded-xl bg-black/25 p-2.5" },
        h(Price, { n: coins, className: "text-lg text-[#ffe066]" }),
        h("span", { className: "text-white/50" }, "⇄"),
        h(DiamondPrice, { n: diamonds, className: "text-lg text-[#7dd3fc]" })
      )
    ),

    h(
      "div",
      { className: "card-bg rounded-2xl p-3" },
      h("div", { className: "mb-2 text-sm font-extrabold" }, t("exchAmount")),
      h(
        "div",
        { className: "flex flex-wrap items-center gap-2" },
        h("input", {
          type: "number",
        "aria-label": t("exchAmount"),
          inputMode: "numeric",
          min: "1",
          value: amount,
          onChange: (e) => setAmount(e.target.value),
          className: "min-w-[120px] flex-1 rounded-xl border-2 border-white/30 bg-black/40 px-3 py-2 text-base font-extrabold text-[#7dd3fc] outline-none focus:border-[#38bdf8]",
        }),
        [1, 10, 100, 1000].map((n) =>
          h(
            "button",
            { key: n, className: "btn btn-gray px-3 py-2 text-xs", onClick: () => setAmount(String(n)) },
            `${n} 💎`
          )
        ),
        h(
          "button",
          { className: "btn btn-yellow px-3 py-2 text-xs", onClick: () => setAmount(String(Math.max(1, maxBuyDia))) },
          t("exchMax", { n: fmtNum(maxBuyDia) })
        )
      ),

      h(
        "div",
        { className: "mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2" },
        h(
          "button",
          {
            className: cn("btn flex-col gap-0.5 py-3 text-sm", coins >= (Math.max(1, Math.floor(Number(amount) || 0)) * EXCHANGE_RATE) ? "btn-blue" : "btn-gray"),
            onClick: () => exchangeCoinsToDiamonds(amount),
          },
          h("span", null, `🪙 ${t("coinsToDia")}`),
          h("span", { className: "text-xs text-[#ffe066]" }, `${fmtNum(Math.max(1, Math.floor(Number(amount) || 0)) * EXCHANGE_RATE)} 🪙 → +${fmtNum(Math.max(1, Math.floor(Number(amount) || 0)))} 💎`)
        ),
        h(
          "button",
          {
            className: cn("btn flex-col gap-0.5 py-3 text-sm", diamonds >= Math.max(1, Math.floor(Number(amount) || 0)) ? "btn-green" : "btn-gray"),
            onClick: () => exchangeDiamondsToCoins(amount),
          },
          h("span", null, `💎 ${t("diaToCoins")}`),
          h("span", { className: "text-xs text-[#ffe066]" }, `${fmtNum(Math.max(1, Math.floor(Number(amount) || 0)))} 💎 → +${fmtNum(Math.max(1, Math.floor(Number(amount) || 0)) * EXCHANGE_RATE)} 🪙`)
        )
      )
    )
  );
}

function LunarPanel() {
  const tab = useGame((s) => s.lunarTab) || "gear";
  const tabs = [
    { id: "gear", icon: "🎣", label: t("lunarGear") },
    { id: "upgrades", icon: "🛰️", label: t("lunarUpgrades") },
    { id: "pets", icon: "🥚", label: t("petsTab") },
    { id: "exchange", icon: "💎", label: t("exchangeTab") },
  ];
  return h(
    PanelShell,
    { title: t("lunarHubTitle"), icon: "🌕", onClose: close },
    h(
      "div",
      { className: "mb-3 grid grid-cols-4 gap-1.5" },
      tabs.map((x) =>
        h(
          "button",
          {
            key: x.id,
            className: cn("btn flex-col gap-0 px-1 py-1.5 text-[11px] sm:text-sm", tab === x.id ? "btn-yellow" : "btn-blue"),
            onClick: () => {
              audio.play("click");
              useGame.setState({ lunarTab: x.id });
            },
          },
          h("span", { className: "text-xl" }, x.icon),
          x.label
        )
      )
    ),
    tab === "gear" &&
      h(
        "div",
        { className: "flex flex-col gap-3" },
        h("div", { className: "txt-o text-sm font-extrabold text-[#7dd3fc]" }, `🎣 ${t("rods")} (💎)`),
        h(RodsTab, { lunar: true }),
        h("div", { className: "txt-o mt-2 text-sm font-extrabold text-[#7dd3fc]" }, `🪝 ${t("baits")} (💎)`),
        h(BaitsTab, { lunar: true })
      ),
    tab === "upgrades" && h(LunarUpgradesTab),
    tab === "pets" && h(LunarPetsTab),
    tab === "exchange" && h(LunarExchangeTab)
  );
}

function Panels() {
  const panel = useGame((s) => s.panel);
  switch (panel) {
    case "bag": return h(BagPanel);
    case "daily": return h(DailyPanel);
    case "shop": return h(ShopPanel);
    case "lunar": return h(LunarPanel);
    case "map": return h(MapPanel);
    case "collection": return h(CollectionPanel);
    case "quests": return h(QuestsPanel);
    case "settings": return h(SettingsPanel);
    default: return null;
  }
}

function CoinsDisplay() {
  const coins = useGame((s) => s.coins);
  const [shown, setShown] = useState(coins);
  const [bump, setBump] = useState(0);
  const prev = useRef(coins);
  useEffect(() => {
    const from = prev.current;
    prev.current = coins;
    if (coins > from) setBump((b) => b + 1);
    const start = performance.now();
    let raf = 0;
    const step = () => {
      const k = Math.min(1, (performance.now() - start) / 500);
      setShown(Math.round(from + (coins - from) * (1 - Math.pow(1 - k, 3))));
      if (k < 1) raf = requestAnimationFrame(step);
    };
    step();
    return () => cancelAnimationFrame(raf);
  }, [coins]);
  return h(
    "div",
    {
      key: bump,
      className: cn(
        "flex items-center gap-1.5 rounded-full border-[3px] border-[#0b2546] bg-gradient-to-b from-[#24609f] to-[#123764] py-0.5 pl-1 pr-3 shadow-lg sm:gap-2 sm:border-4 sm:py-1 sm:pr-4",
        bump > 0 && "anim-pop"
      ),
    },
    h(Coin, { size: 24 }),
    h("span", { className: "txt-o text-base font-extrabold tabular-nums text-[#ffe066] sm:text-xl" }, fmtNum(shown))
  );
}

function DiamondsDisplay() {
  const diamonds = useGame((s) => s.diamonds) || 0;
  const islands = useGame((s) => s.islands);
  const island = useGame((s) => s.island);
  const show = diamonds > 0 || islands.includes("lunar_crater") || island === "lunar_crater";
  if (!show) return null;
  return h(
    "div",
    {
      className: "pointer-events-auto flex cursor-pointer items-center gap-1.5 rounded-full border-[3px] border-[#0b2546] bg-gradient-to-b from-[#0284c7] to-[#0f294a] py-0.5 pl-1.5 pr-3 shadow-lg sm:gap-2 sm:border-4 sm:py-1 sm:pr-4",
      onClick: () => {
        useGame.setState({ panel: "lunar", lunarTab: "exchange" });
        audio.play("click");
      },
      title: t("exchTitle"),
    },
    h(Diamond, { size: 22 }),
    h("span", { className: "txt-o text-base font-extrabold tabular-nums text-[#e0f2fe] sm:text-xl" }, fmtNum(diamonds))
  );
}

function LuckBadge() {
  useGame((s) => s.now);
  useGame((s) => s.rod);
  useGame((s) => s.bait);
  useGame((s) => s.luckLevel);
  useGame((s) => s.mutLevel);
  useGame((s) => s.luScanLevel);
  useGame((s) => s.luMutLevel);
  useGame((s) => s.petsEquipped);
  useGame((s) => s.collection);
  const inHot = useGame((s) => s.inHotspot);
  const phase = useGame((s) => s.phase);
  const m = getMods();
  const hotActive = inHot && (phase === "waiting" || phase === "bite" || phase === "reeling");
  const effLuck = m.luckMult * (hotActive ? 1.5 : 1);
  const effMut = Math.min(1, m.mutChance * (hotActive ? 1.5 : 1));
  const mutPct = Math.round(effMut * 1000) / 10;
  return h(
    "div",
    { className: "flex flex-wrap items-center justify-end gap-1" },
    h(
      "div",
      { className: "txt-o rounded-full bg-black/35 px-2 py-0.5 text-[10px] font-extrabold text-[#7ef07e] sm:text-xs" },
      `🍀 ×${effLuck >= 100 ? Math.round(effLuck) : effLuck.toFixed(2)}`
    ),
    h(
      "div",
      { className: "txt-o rounded-full bg-black/35 px-2 py-0.5 text-[10px] font-extrabold text-[#d29bff] sm:text-xs" },
      `✦ ${mutPct}%`
    )
  );
}

function TopBar() {
  const island = useGame((s) => s.island);
  const now = useGame((s) => s.now);
  const luckUntil = useGame((s) => s.luckUntil);
  const autoUntil = useGame((s) => s.autoUntil);
  const autoOwned = useGame((s) => s.autoOwned);
  const event = useGame((s) => s.event);
  const inHot = useGame((s) => s.inHotspot);
  const phase = useGame((s) => s.phase);
  const isl = ISLAND_MAP[island];
  const ev = event && event.until > now ? event : null;
  return h(
    "div",
    { className: "pointer-events-none absolute left-0 right-0 top-0 z-20 flex items-start justify-between gap-2 p-1.5 sm:p-3" },
    h(
      "div",
      { className: "pointer-events-auto flex flex-wrap items-center gap-1.5" },
      h(CoinsDisplay),
      h(DiamondsDisplay),
      h(
        "div",
        { className: "txt-o flex items-center gap-1 rounded-full bg-black/35 px-2.5 py-1 text-[11px] font-extrabold text-white sm:text-sm" },
        h("span", null, isl.icon),
        h("span", { className: "max-w-[115px] truncate sm:max-w-none" }, tr(isl.name))
      )
    ),
    h(
      "div",
      { className: "flex max-w-[46%] flex-col items-center gap-0.5" },
      ev &&
        h(
          "div",
          { className: "txt-o anim-pulse rounded-full border-2 border-[#ffe066] bg-[#3a1a6a]/80 px-2.5 py-0.5 text-center text-[11px] font-extrabold text-[#ffe066] sm:px-3 sm:py-1 sm:text-sm" },
          `${EVENTS.find((e) => e.id === ev.id)?.icon} ${t(eventKey(ev.id))} · ${fmtTime(ev.until - now)}`
        ),
      h(
        "div",
        { className: "flex flex-wrap justify-center gap-1" },
        luckUntil > now && h("span", { className: "txt-o rounded-full bg-[#2fb84a]/85 px-2 py-0.5 text-[10px] font-extrabold text-white sm:text-xs" }, `🍀 ×2 ${fmtTime(luckUntil - now)}`),
        !autoOwned && autoUntil > now && h("span", { className: "txt-o rounded-full bg-[#2a7de1]/85 px-2 py-0.5 text-[10px] font-extrabold text-white sm:text-xs" }, `🤖 ${fmtTime(autoUntil - now)}`),
        inHot && (phase === "waiting" || phase === "bite" || phase === "reeling") && h("span", { className: "txt-o rounded-full bg-[#f5a623]/90 px-2 py-0.5 text-[10px] font-extrabold text-white sm:text-xs" }, `✨ ${t("hotspot")}`)
      )
    ),
    h(
      "div",
      { className: "pointer-events-auto flex flex-col items-end gap-1" },
      h(
        "div",
        { className: "flex items-center gap-1.5" },
        h(
          "button",
          {
            className: "btn btn-gray h-9 w-9 rounded-xl text-base sm:h-11 sm:w-11 sm:rounded-2xl sm:text-xl",
            onClick: () => openPanel("settings"),
            "aria-label": t("settings"),
          },
          "⚙️"
        )
      ),
      h(LuckBadge)
    )
  );
}

function SideButtons() {
  useGame((s) => s.now);
  useGame((s) => s.daily);
  const dailyAvailable = dailyStatus().available;
  const bag = useGame((s) => s.bag.length);
  const lvl = useGame((s) => s.bagLevel);
  const quests = useGame((s) => s.quests);
  const isMobile = useGame((s) => s.isMobile);
  const islands = useGame((s) => s.islands);
  const island = useGame((s) => s.island);
  const petsEq = useGame((s) => s.petsEquipped) || [];
  const hasMoon = islands.includes("lunar_crater") || island === "lunar_crater";
  const cap = bagCapacity(lvl);
  const claimable = quests.some((q) => q.done);
  const items = [
    { id: "bag", icon: "🎒", label: t("bag"), badge: `${bag}/${cap}`, full: bag >= cap },
    { id: "shop", icon: "🛒", label: t("shop"), tab: "rods" },
    { id: "map", icon: "🗺️", label: t("map") },
    { id: "collection", icon: "📖", label: t("collection") },
    { id: "quests", icon: "📜", label: t("quests"), badge: claimable ? "!" : undefined },
    { id: "daily", icon: "📅", label: t("dailyShort"), badge: dailyAvailable ? "!" : undefined },
    { id: "shop", icon: "🎁", label: t("bonus"), tab: "boosts", pulse: true },
    ...(hasMoon
      ? [
          {
            id: "lunar",
            icon: "🌕",
            label: t("lunarHub"),
            badge: petsEq.length ? `🐾${petsEq.length}` : "💎",
            lunar: true,
          },
        ]
      : []),
  ];
  return h(
    "div",
    {
      className: cn(
        "absolute left-1.5 z-20 grid gap-1.5",
        isMobile
          ? "top-[48px] grid-cols-3"
          : "top-[56px] grid-cols-3 sm:left-3 sm:top-[76px] sm:grid-cols-2 lg:grid-cols-1"
      ),
    },
    items.map((it, i) =>
      h(
        "button",
        {
          key: i,
          className: cn(
            "btn relative flex-col gap-0 rounded-xl border-[#0b2546] bg-gradient-to-b from-[#3d8ee8] to-[#1d58a8] text-white",
            isMobile ? "h-[42px] w-[42px] border-b-[3px]" : "h-[46px] w-[46px] sm:h-[56px] sm:w-[56px] sm:rounded-2xl",
            it.pulse && "anim-pulse",
            it.full && "from-[#ff8a8a] to-[#e23b3b]",
            it.lunar && "from-[#38bdf8] to-[#1e3a8a] ring-2 ring-[#7dd3fc]"
          ),
          onClick: () => openPanel(it.id, it.tab),
        },
        h("span", { className: isMobile ? "text-lg leading-none" : "text-xl leading-none sm:text-2xl" }, it.icon),
        h("span", { className: "txt-o mt-0.5 max-w-full truncate px-0.5 text-[8px] font-extrabold leading-none sm:text-[9px]" }, it.label),
        it.badge &&
          h(
            "span",
            {
              className: cn(
                "absolute -right-1 -top-1 rounded-full border border-[#0b2546] px-1 text-[8px] font-extrabold leading-3 sm:border-2 sm:text-[10px] sm:leading-4",
                it.badge === "!" ? "anim-pulse bg-[#ff4d6d] text-white" : "bg-[#ffe066] text-[#4a2a00]"
              ),
            },
            it.badge
          )
      )
    )
  );
}

function ActionCluster() {
  const phase = useGame((s) => s.phase);
  const nearNpc = useGame((s) => s.nearNpc);
  const autoOn = useGame((s) => s.autoOn);
  const isMobile = useGame((s) => s.isMobile);
  useGame((s) => s.now);
  const avail = autoAvailable();
  const label = {
    idle: ["🎣", t("actCast")],
    charging: ["💪", t("actRelease")],
    casting: ["🎣", "..."],
    waiting: ["🔄", t("actReelIn")],
    bite: ["❗", t("actHook")],
    reeling: ["🐟", t("actPull")],
    caught: ["🎉", t("actOk")],
    reelback: ["🎣", "..."],
  };
  const [ic, lb] = label[phase] ?? label.idle;
  const hot = phase === "bite" || phase === "reeling";
  const islands = useGame((s) => s.islands);
  const moonUnlocked = islands.includes("lunar_crater");
  const npcLabel =
    nearNpc === "merchant"
      ? "💰 " + t("talkMerchant")
      : nearNpc === "shop"
        ? "🎣 " + t("talkShop")
        : nearNpc === "rocket"
          ? `🚀 ${t("talkRocket")}${moonUnlocked ? "" : ` (${fmtNum(ROCKET_LAUNCH_COST)} 🪙)`}`
          : nearNpc === "earth_rocket"
            ? "🌍 " + t("talkEarthRocket")
            : nearNpc === "boat"
              ? "⛵ " + t("talkBoat")
              : "";
  return h(
    "div",
    { className: "pointer-events-none absolute bottom-2.5 right-2.5 z-20 flex items-end gap-2 sm:bottom-5 sm:right-5" },
    nearNpc &&
      phase === "idle" &&
      h(
        "button",
        {
          className: cn(
            "btn btn-yellow anim-pop pointer-events-auto mb-1",
            isMobile ? "px-3 py-2 text-xs" : "px-4 py-2.5 text-sm sm:text-base"
          ),
          onClick: () => runtime.engine?.interact(),
        },
        npcLabel,
        !isMobile && h("kbd", { className: "ml-1 rounded bg-black/20 px-1.5 text-xs" }, "E")
      ),
    h(
      "div",
      { className: "pointer-events-auto flex flex-col items-end gap-1.5" },
      h(
        "button",
        {
          className: cn(
            "btn rounded-full",
            isMobile ? "px-2.5 py-1 text-[11px]" : "px-3 py-1.5 text-xs sm:text-sm",
            avail ? (autoOn ? "btn-green" : "btn-gray") : "btn-purple"
          ),
          onClick: () => {
            if (!avail) {
              openPanel("shop", "boosts");
              return;
            }
            audio.play("click");
            useGame.setState({ autoOn: !autoOn });
          },
        },
        `🤖 ${t("auto")} ${avail ? (autoOn ? "ON" : "OFF") : "🔒"}`
      ),
      h(
        "button",
        {
          className: cn(
            "btn flex-col gap-0 rounded-full text-white shadow-2xl",
            isMobile
              ? "h-[74px] w-[74px] border-b-[5px]"
              : "h-[86px] w-[86px] border-b-[6px] sm:h-[100px] sm:w-[100px]",
            hot ? "border-[#9a1f1f] bg-gradient-to-b from-[#ff8a5a] to-[#e2333b]" : "border-[#b9700c] bg-gradient-to-b from-[#ffe066] to-[#f5a623]",
            phase === "bite" && "anim-shake"
          ),
          onPointerDown: (e) => {
            e.preventDefault();
            e.currentTarget.setPointerCapture?.(e.pointerId);
            runtime.engine?.press();
          },
          onPointerUp: () => runtime.engine?.release(),
          onPointerCancel: () => runtime.engine?.release(),
          onContextMenu: (e) => e.preventDefault(),
        },
        h("span", { className: isMobile ? "text-3xl leading-none drop-shadow" : "text-4xl leading-none drop-shadow sm:text-[42px]" }, ic),
        h("span", { className: cn("txt-o mt-0.5 font-extrabold uppercase", isMobile ? "text-[10px]" : "text-xs sm:text-sm", hot ? "text-white" : "text-[#4a2a00] [text-shadow:none]") }, lb)
      )
    )
  );
}

function Joystick() {
  const phase = useGame((s) => s.phase);
  const panel = useGame((s) => s.panel);
  const baseRef = useRef(null);
  const knobRef = useRef(null);
  const st = useRef(null);
  const [pos, setPos] = useState(null);
  const hidden = !!panel || !(phase === "idle" || phase === "waiting" || phase === "reelback");
  useEffect(() => {
    if (hidden) {
      st.current = null;
      setPos(null);
      runtime.engine?.setJoy(0, 0);
    }
  }, [hidden]);
  if (hidden) return null;
  const R = 42;
  const move = (x, y) => {
    const s = st.current;
    if (!s) return;
    let dx = x - s.cx, dy = y - s.cy;
    const d = Math.hypot(dx, dy);
    if (d > R) {
      dx = (dx / d) * R;
      dy = (dy / d) * R;
    }
    if (knobRef.current) knobRef.current.style.transform = `translate(${dx}px, ${dy}px)`;
    runtime.engine?.setJoy(dx / R, -dy / R);
  };
  const end = () => {
    st.current = null;
    setPos(null);
    runtime.engine?.setJoy(0, 0);
  };
  return h(
    "div",
    {
      className: "absolute bottom-0 left-0 z-[15] h-[54%] w-[44%]",
      onPointerDown: (e) => {
        e.preventDefault();
        e.currentTarget.setPointerCapture?.(e.pointerId);
        const rect = e.currentTarget.getBoundingClientRect();
        st.current = { id: e.pointerId, cx: e.clientX, cy: e.clientY };
        setPos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
      },
      onPointerMove: (e) => st.current?.id === e.pointerId && move(e.clientX, e.clientY),
      onPointerUp: end,
      onPointerCancel: end,
    },
    h(
      "div",
      {
        ref: baseRef,
        className: cn("absolute h-[96px] w-[96px] -translate-x-1/2 -translate-y-1/2 rounded-full border-[3px] border-white/40 bg-black/25 transition-opacity", pos ? "opacity-100" : "opacity-65"),
        style: pos ? { left: pos.x, top: pos.y } : { left: 72, bottom: -26 },
      },
      h("div", { ref: knobRef, className: "absolute left-1/2 top-1/2 -ml-[22px] -mt-[22px] h-11 w-11 rounded-full border-[3px] border-white/75 bg-white/50 shadow-lg" })
    )
  );
}

function Hint() {
  const phase = useGame((s) => s.phase);
  const caught = useGame((s) => s.stats.caught);
  const earned = useGame((s) => s.stats.earned);
  const bagLen = useGame((s) => s.bag.length);
  const lvl = useGame((s) => s.bagLevel);
  const isMobile = useGame((s) => s.isMobile);
  let text = "";
  if (phase === "idle") {
    if (bagLen >= bagCapacity(lvl)) text = t("bagFull") + " 🎒";
    else if (caught === 0) text = t("hintFirstCast");
    else if (bagLen >= 8 && earned === 0) text = t("hintSell");
  } else if (phase === "waiting") text = t("hintWait");
  if (!text && !(phase === "idle" && caught < 2 && !isMobile)) return null;
  return h(
    "div",
    { className: "pointer-events-none absolute bottom-[132px] left-1/2 z-20 w-[min(92vw,560px)] -translate-x-1/2 text-center sm:bottom-6" },
    text && h("div", { className: "txt-o inline-block rounded-2xl bg-black/35 px-4 py-2 text-sm font-extrabold text-white sm:text-base" }, text),
    phase === "idle" && caught < 2 && !isMobile && h("div", { className: "txt-o mt-1 text-xs font-bold text-white/85" }, t("hintDesktop"))
  );
}

function Toasts() {
  const toasts = useGame((s) => s.toasts);
  return h(
    "div",
    { className: "pointer-events-none absolute left-1/2 top-[96px] z-30 flex w-[min(92vw,420px)] -translate-x-1/2 flex-col items-center gap-1.5 sm:top-[72px]" },
    toasts.map((x) =>
      h(
        "div",
        {
          key: x.id,
          className: "anim-drop txt-o rounded-full border-2 border-white/20 bg-[#0b2546]/85 px-4 py-1.5 text-center text-sm font-extrabold shadow-lg",
          style: { color: x.color ?? "#ffffff" },
        },
        x.text
      )
    )
  );
}

function HUD() {
  const isMobile = useGame((s) => s.isMobile);
  const panel = useGame((s) => s.panel);
  const phase = useGame((s) => s.phase);
  const busy = phase === "bite" || phase === "reeling" || phase === "charging" || phase === "rescue";
  return h(
    React.Fragment,
    null,
    h(TapOverlay),
    h(TopBar),
    !busy && !panel && h(SideButtons),
    !panel && phase !== "rescue" && h(ActionCluster),
    isMobile && h(Joystick),
    h(ChargeMeter),
    h(Minigame),
    h(BitePrompt),
    h(CastLabel),
    h(CatchPopup),
    h(FishRescue),
    !panel && h(Hint),
    h(Toasts),
    h(Panels)
  );
}

function GameCanvas() {
  const ref = useRef(null);
  const saveLoaded = useGame((s) => s.saveLoaded);
  const [error, setError] = useState(false);
  useGame((s) => s.curLang);
  useEffect(() => {
    if (!saveLoaded || !ref.current) return;
    let engine = null;
    try {
      engine = new Engine(ref.current, useGame.getState().isMobile);
      runtime.engine = engine;
    } catch (e) {
      console.error(e);
      setError(true);
      useGame.setState({ engineReady: true });
    }
    return () => {
      engine?.dispose();
      runtime.engine = null;
    };
  }, [saveLoaded]);
  return h(
    React.Fragment,
    null,
    h("div", { ref, className: "absolute inset-0 z-0" }),
    // Пункт 1.6.1.7: Никаких упоминаний WebGL при ошибке инициализации
    error &&
      h(
        "div",
        { className: "absolute inset-0 z-50 flex items-center justify-center bg-[#0e3a66] p-6 text-center text-lg font-bold text-white" },
        t("sceneUnavailable")
      )
  );
}

function StartScreen() {
  const ready = useGame((s) => s.engineReady);
  const isMobile = useGame((s) => s.isMobile);
  const caught = useGame((s) => s.stats.caught);
  const showcase = ["clown", "goldcarp", "aurora", "nebulajelly", "skyserpent", "infinityfish"];
  return h(
    "div",
    { className: "absolute inset-0 z-30 flex flex-col items-center justify-center bg-gradient-to-b from-[#04142a]/30 via-transparent to-[#04142a]/70 p-4" },
    h(
      "div",
      { className: "anim-drop text-center" },
      h("div", { className: "anim-bob mb-1 text-6xl sm:text-7xl" }, "🎣"),
      h("h1", { className: "txt-o2 text-5xl font-extrabold leading-none tracking-tight text-[#ffe066] sm:text-7xl" }, t("title")),
      h("div", { className: "txt-o2 mt-2 text-2xl font-extrabold text-white sm:text-3xl" }, t("subtitle"))
    ),
    h(
      "div",
      { className: "mt-6 flex items-end justify-center gap-1 sm:gap-3" },
      showcase.map((id, i) =>
        h(
          "div",
          { key: id, className: "anim-bob", style: { animationDelay: `${i * 0.25}s` } },
          h(FishIcon, { def: FISH_MAP[id], className: "h-10 w-16 sm:h-14 sm:w-24" })
        )
      )
    ),
    h(
      "div",
      { className: "mt-8 h-24" },
      ready
        ? h("button", { className: "btn btn-green anim-pulse px-12 py-4 text-3xl", onClick: startGame }, `▶ ${t("play")}`)
        : h(
            "div",
            { className: "flex w-64 flex-col items-center gap-2" },
            h("div", { className: "txt-o font-extrabold text-white" }, t("loading")),
            h(
              "div",
              { className: "h-4 w-full overflow-hidden rounded-full border-2 border-[#0b2546] bg-black/30" },
              h("div", { className: "h-full w-2/3 animate-pulse rounded-full bg-gradient-to-r from-[#ffe066] to-[#f5a623]" })
            )
          )
    ),
    h(
      "div",
      { className: "txt-o absolute bottom-4 left-0 right-0 px-4 text-center text-xs font-bold text-white/90 sm:text-sm" },
      isMobile ? t("hintMobile") : t("hintDesktop"),
      caught > 0 && h("div", { className: "mt-1 text-[#ffe066]" }, `🐟 × ${caught}`)
    )
  );
}

function Overlays() {
  const fade = useGame((s) => s.fade);
  const island = useGame((s) => s.island);
  const isSpace = island === "spaceport" || (ISLAND_MAP[island]?.planet ?? 1) === 2;
  return h(
    "div",
    {
      className: `pointer-events-none absolute inset-0 z-50 flex items-center justify-center bg-[#04142a] transition-opacity duration-500 ${fade ? "opacity-100" : "opacity-0"}`,
    },
    fade && h("div", { className: "anim-bob text-7xl" }, isSpace ? "🚀" : "⛵")
  );
}

function App() {
  const mobile = useGame((s) => s.isMobile);
  const banner = useGame((s) => s.bannerShown);
  const started = useGame((s) => s.started);
  const lang = useGame((s) => s.curLang);
  useEffect(() => {
    void boot();
  }, []);
  return h(
    "div",
    {
      className: "game-root fixed inset-0 overflow-hidden bg-[#0e3a66]",
      "data-mobile": mobile ? "" : undefined,
      "data-banner": banner ? "" : undefined,
      onContextMenu: (e) => e.preventDefault(),
    },
    h(GameCanvas),
    started ? h(HUD, { key: lang }) : h(StartScreen, { key: lang }),
    h(Overlays)
  );
}

createRoot(document.getElementById("root")).render(h(App));
